// ampguard.cpp
// -----------------------------------------------------------------------------
// yoRadio – Erősítő + hangfalvédő (SPKRS_RELAY) kiszervezett logika
//
// ÚJ (2026-02): József kérés szerinti viselkedés
//  - BOOT:   PWR_AMP = LOW,  SPKRS_RELAY = LOW,
//            boot után mindkét relé legyen HIGH
//  - STOP:   SPKRS_RELAY = LOW
//  - PLAY:   200..5000 ms (webből állítható) késleltetés után SPKRS_RELAY = HIGH
//  - Screensaver (vagy VOL=0):
//      - SPKRS_RELAY = LOW azonnal
//      - 2s múlva PWR_AMP = LOW
//  - Ébresztés (screensaver feloldás vagy VOL>0):
//      - PWR_AMP = HIGH azonnal
//      - 2s múlva SPKRS_RELAY = HIGH
//
// MEGJEGYZÉS a PWR_AMP szintről:
//  A fenti szabályrendszer explicit HIGH/LOW szinteket kér. Ez alapján a kód úgy
//  kezeli, hogy PWR_AMP:
//    - LOW  = "kikapcsolt/standby"
//    - HIGH = "bekapcsolt"
//  Ha nálad a hardver pont fordítva működik, akkor itt a két AMP_*_LEVEL
//  konstans cseréjével azonnal igazítható.
// -----------------------------------------------------------------------------

#include "ampguard.h"

#include "options.h"
#include "config.h"
#include "Arduino.h"

namespace ampguard {

// --- GPIO szintek (a fenti megjegyzés szerint) ---
// A kért logika szerint: OFF=LOW, ON=HIGH.
static constexpr uint8_t AMP_OFF_LEVEL = LOW;   // erősítő kikapcsolt / standby
static constexpr uint8_t AMP_ON_LEVEL  = HIGH;  // erősítő bekapcsolt

static constexpr uint8_t SPK_OFF_LEVEL = LOW;  // "mute"
static constexpr uint8_t SPK_ON_LEVEL  = HIGH; // "unmute"

// ------------------------------------------------------------
// BELSŐ ÁLLAPOT
// ------------------------------------------------------------

static bool     s_inited = false;
static bool     s_ssActive = false;   // képernyővédő aktív (Display oldalról)
static bool     s_volZero = false;    // volume==0 (bármely UI-ból)
static bool     s_lastPlaying = false;

// időzítések
static uint32_t s_spkUnmuteAt = 0;    // PLAY után késleltetett unmute
static uint32_t s_ampAt = 0;          // screensaver/volume0 -> amp off/on késleltetés
static bool     s_ampTargetOn = false;

// boot szekvencia
static uint32_t s_bootAt = 0;

// forward
static inline bool muteContextActive();
static inline void spkWriteLevel(uint8_t level);
static inline void ampWriteLevel(uint8_t level);

static void processTimers(uint32_t now) {
  // BOOT: 2s múlva mindkét relé HIGH (ha nincs screensaver/vol0)
  if (s_bootAt && (int32_t)(now - s_bootAt) >= 0) {
    s_bootAt = 0;
    if (!muteContextActive()) {
      ampWriteLevel(AMP_ON_LEVEL);
      spkWriteLevel(SPK_ON_LEVEL);
    }
  }

  // PLAY / Wake unmute timer (közös)
  if (s_spkUnmuteAt && (int32_t)(now - s_spkUnmuteAt) >= 0) {
    s_spkUnmuteAt = 0;
    if (!muteContextActive() && !s_volZero) {
      spkWriteLevel(SPK_ON_LEVEL);
    }
  }

  // AMP késleltetett kapcsolás (mute context esetén)
  if (s_ampAt && (int32_t)(now - s_ampAt) >= 0) {
    s_ampAt = 0;
    ampWriteLevel(s_ampTargetOn ? AMP_ON_LEVEL : AMP_OFF_LEVEL);
  }
}

static inline bool ampCtlEnabled() { return config.store.ampCtlEnabled; }
static inline bool spkCtlEnabled() { return config.store.spkCtlEnabled; }

static inline uint16_t clampSpkDelay(uint16_t v) {
  if (v < 200) v = 200;
  if (v > 5000) v = 5000;
  return v;
}

static inline void spkWriteLevel(uint8_t level) {
  if (SPKRS_RELAY == 255) return;
  if (!spkCtlEnabled()) return;
  digitalWrite(SPKRS_RELAY, level);
}

static inline void ampWriteLevel(uint8_t level) {
  if (PWR_AMP == 255) return;
  if (!ampCtlEnabled()) return;
  digitalWrite(PWR_AMP, level);
}

static inline bool muteContextActive() {
  // screensaver vagy VOL=0 ugyanazt a relé-metódust kérte
  return s_ssActive || s_volZero;
}

static void scheduleAmp(bool wantOn, uint32_t delayMs) {
  s_ampTargetOn = wantOn;
  s_ampAt = millis() + delayMs;
}

static void cancelSpkUnmute() { s_spkUnmuteAt = 0; }

// ------------------------------------------------------------

void begin() {
  if (s_inited) return;
  s_inited = true;

#if PWR_AMP != 255
  pinMode(PWR_AMP, OUTPUT);
  // BOOT: PWR_AMP = LOW
  ampWriteLevel(AMP_OFF_LEVEL);
#endif

#if SPKRS_RELAY != 255
  pinMode(SPKRS_RELAY, OUTPUT);
  // BOOT: SPKRS_RELAY = LOW
  spkWriteLevel(SPK_OFF_LEVEL);

  // Ha a vezérlés nincs használatban (ki van kapcsolva webből),
  // akkor ne "safe boot" állapotban maradjunk, hanem engedjük a zenét azonnal.
  // (a kért "indításkori logika fordítottja": erősítő ON + hangfal relé ON)
  if (!config.store.ampCtlEnabled || !config.store.spkCtlEnabled) {
#if PWR_AMP != 255
    ampWriteLevel(AMP_ON_LEVEL);
#endif
#if SPKRS_RELAY != 255
    spkWriteLevel(SPK_ON_LEVEL);
#endif
    // Ne ütemezzünk további automatikát, amíg nincs bekapcsolva a funkció
    return;
  }

#endif

  // BOOT: 2s múlva mindkét relé HIGH
  s_bootAt = millis() + 2000;
  s_spkUnmuteAt = 0;
  s_ampAt = 0;
  s_lastPlaying = false;
  s_ssActive = false;
  s_volZero = false;
}

void reset() {
  // biztonságos reset: BOOT állapot
  s_bootAt = millis() + 2000;
  s_spkUnmuteAt = 0;
  s_ampAt = 0;
  s_lastPlaying = false;
  s_ssActive = false;
  s_volZero = false;
  spkWriteLevel(SPK_OFF_LEVEL);
  ampWriteLevel(AMP_OFF_LEVEL);
}

void forceMute() {
  cancelSpkUnmute();
  spkWriteLevel(SPK_OFF_LEVEL);
}

// ------------------------------------------------------------
// Player oldali: STOP/PLAY + volume0 kezelése
// ------------------------------------------------------------
void updatePlayer(bool isPlaying, uint8_t volume, bool /*muteLock*/) {
  begin();

  // volume==0 -> ugyanaz a metódus, mint screensaver
  const bool newVolZero = (volume == 0);
  if (newVolZero != s_volZero) {
    s_volZero = newVolZero;
    cancelSpkUnmute();

    if (muteContextActive()) {
      // VOL=0 vagy SS: SPK OFF azonnal, AMP OFF 2s múlva
      spkWriteLevel(SPK_OFF_LEVEL);
      scheduleAmp(false, 2000);
    } else {
      // VOL vissza >0 és nincs screensaver:
      //  - AMP ON azonnal
      //  - 2s múlva SPK ON
      s_ampAt = 0; // esetleges korábbi OFF időzítő törlése
      ampWriteLevel(AMP_ON_LEVEL);
      spkWriteLevel(SPK_OFF_LEVEL);
      s_spkUnmuteAt = millis() + 2000;
    }
  }

  // STOP esemény: playing true -> false
  if (s_lastPlaying && !isPlaying) {
    cancelSpkUnmute();
    spkWriteLevel(SPK_OFF_LEVEL);
  }

  // PLAY esemény: false -> true
  if (!s_lastPlaying && isPlaying) {
    cancelSpkUnmute();
    // PLAY után késleltetett unmute (200..5000ms, webből állítható)
    if (!muteContextActive() && !newVolZero) {
      // Lejátszás indul: erősítő ON (azonnal), hangfalrelé csak késleltetve
      s_ampAt = 0; // esetleges korábbi OFF időzítő törlése
      ampWriteLevel(AMP_ON_LEVEL); // PWR_AMP = LOW
      const uint16_t d = clampSpkDelay(config.store.spkUnmuteDelayMs);
      s_spkUnmuteAt = millis() + d;
      spkWriteLevel(SPK_OFF_LEVEL);
    }
  }

  s_lastPlaying = isPlaying;

  processTimers(millis());
}

// ------------------------------------------------------------
// UI/TimeKeeper oldali: screensaver állapot
// ------------------------------------------------------------
void updateUi(bool ssActive, bool /*playingNow*/) {
  begin();

  if (ssActive != s_ssActive) {
    s_ssActive = ssActive;
    cancelSpkUnmute();

    if (muteContextActive()) {
      // SS belépés: SPK OFF azonnal, AMP OFF 2s múlva
      spkWriteLevel(SPK_OFF_LEVEL);
      scheduleAmp(false, 2000);
    } else {
      // SS kilépés:
      //  - AMP ON azonnal
      //  - 2s múlva SPK ON
      s_ampAt = 0; // esetleges korábbi OFF időzítő törlése
      ampWriteLevel(AMP_ON_LEVEL);
      spkWriteLevel(SPK_OFF_LEVEL);
      s_spkUnmuteAt = millis() + 2000;
    }
  }

  processTimers(millis());
}

} // namespace ampguard
