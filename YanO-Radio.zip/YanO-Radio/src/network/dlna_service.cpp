#include "../core/options.h"
#ifdef USE_DLNA

#include "dlna_service.h"
#include "dlna_ssdp.h"
#include "dlna_desc.h"
#include "dlna_index.h"
#include "dlna_worker.h"
#include "../core/network.h"
#include "../core/player.h"

String g_dlnaControlUrl;

static bool s_serviceStarted = false;
static uint32_t s_reqId = 1;
bool g_dlnaReady = false;

bool dlnaInit(const String& rootObjectId, String& err) {

  g_dlnaReady = false;
  g_dlnaControlUrl = "";

  // Megállítjuk a lejátszót, hogy több erőforrás jusson az inicializálásra
  player.sendCommand({PR_STOP, 0});
  vTaskDelay(pdMS_TO_TICKS(100)); // Hagyunk időt a stop folyamatnak

  DlnaSSDP ssdp;
  DlnaDescription desc;
  DlnaIndex idx;

  String descUrl;
  String controlUrl;

  // 1. SSDP Discover - Első kritikus hálózati pont
  if (!ssdp.resolve(nullptr, descUrl)) {
    err = "SSDP discover failed";
    return false;
  }

  // Szünet az SSDP után, mielőtt elindítjuk a HTTP letöltést
  vTaskDelay(pdMS_TO_TICKS(20));

  bool cdOk = false;
  for (int i = 0; i < 3; i++) {
    // 2.resolveControlURL: Ez tölti le a rootDesc.xml-t (A logod alapján itt akadt el)
    if (desc.resolveControlURL(descUrl, controlUrl)) {
      cdOk = true;
      break;
    }

    // Ha nem sikerült, hosszabb szünetet hagyunk a következő próbálkozásig
    vTaskDelay(pdMS_TO_TICKS(500));
  }

  if (!cdOk || !controlUrl.length()) {
    err = "ContentDirectory not found";
    log_i("%s", String("[DLNA] ERROR: ContentDirectory control URL not resolved").c_str());
    return false;
  }

  // XML parsolás után kötelező "lélegzetvétel" az ESP32-S3-nak
  vTaskDelay(pdMS_TO_TICKS(50));

  log_i("[DLNA] ContentDirectory control URL: %s\n", controlUrl.c_str());

  // 3. buildContainerIndex: Itt történik a mappák listázása és a JSON mentése
  if (!idx.buildContainerIndex(controlUrl, rootObjectId)) {
    err = "Root container browse failed";
    return false;
  }

  // Biztos yield a végén, mielőtt visszaadjuk a vezérlést
  vTaskDelay(pdMS_TO_TICKS(20));

  g_dlnaControlUrl = controlUrl;
  g_dlnaReady = true;

  return true;
}

void dlna_service_begin() {
  if (s_serviceStarted) return;
  s_serviceStarted = true;

  dlna_worker_start();
}

uint32_t dlna_next_reqId() {
  uint32_t v = s_reqId++;
  if (v == 0) v = s_reqId++; // 0 ne legyen
  return v;
}

bool dlna_isBusy() {
  return g_dlnaStatus.busy;
}

#endif   // USE_DLNA