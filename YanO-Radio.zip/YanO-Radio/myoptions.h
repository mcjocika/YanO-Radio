// clang-format off
/* https://trip5.github.io/ehRadio_myoptions/generator.html?b=ESP32-S3-DevKitC-1_44Pin&r=72,1,2,4,5,6,76,7,8,31,42,43,54,55,58,60,63,65,77&i=1,2,3,4,15,16,17,28,29,30,31,32,33,34,39,48,49&v=9,10,-1,14,4,5,6,40,41,39,48,47,21,3,18,8,7
   https://github.com/VaraiTamas/yoRadio.git
   Használat előtt olvasd el!!! - Read the before use !!!
*/

#ifndef myoptions_h
#define myoptions_h

// ESP32-S3 processzor támogatás engedélyezése
#ifndef ARDUINO_ESP32S3_DEV
    #define ARDUINO_ESP32S3_DEV
#endif

// #define HEAP_DBG // Memóriafoglalás hibakereső (alapértelmezésben kikapcsolva)

/* --- NYELV ÉS LOKALIZÁCIÓ --- */
#define L10N_LANGUAGE HU // A rendszer nyelve: Magyar
#define NAMEDAYS_FILE HU // Magyar névnapok megjelenítése

// -----------------------------------------------------------------------------
// TFT UI mód
// -----------------------------------------------------------------------------
// Web-skin: a régi (óra/névnap/időjárás/VU/bitrate) TFT elemeket nem rajzoljuk,
// a PLAYER képernyő egyszerű, "webes" jellegű lesz (meta/cím + alsó vezérlősáv).
// A hosszú playlist továbbra is csak rotary hosszú nyomásra jön elő.
#ifndef TFT_WEB_SKIN
  #define TFT_WEB_SKIN 1
#endif

#define USE_BUILTIN_LED false /* Alaplapi LED kikapcsolva */
#define ENABLE_FTP true       /* FTP szerver engedélyezve (fájlok küldéséhez) */

#define SPIRAM_BUFFER true //gyors ram a dln sd kártya

/* -- Arduino OTA (Vezeték nélküli programfeltöltés) -- */
// #define USE_OTA true                 /* OTA frissítés engedélyezése */
// #define OTA_PASS "myotapassword12345"/* Jelszó az OTA frissítéshez */

/* -- HTTP Hitelesítés (Webes belépési jelszó) -- */
// #define HTTP_USER ""                 /* Felhasználónév a webfelülethez */
// #define HTTP_PASS ""                 /* Jelszó a webfelülethez */

/*----- LCD DISPLAY - Kijelző modellek -----*/
// #define DSP_MODEL DSP_ILI9488        // Eredeti nagy kijelző (inaktív)
#define DSP_MODEL DSP_ILI9341           // A te jelenlegi kijelződ (AKTÍV)
// #define DSP_MODEL DSP_ST7796         // Egyéb támogatott típus (inaktív)

/*----- OLED DISPLAY (Ha OLED-re váltanál) -----*/
// #define DSP_MODEL      DSP_SSD1322   // OLED vezérlő (inaktív)

/*----- DISPLAY PIN SETS - Kijelző lábak -----*/
#define TFT_DC          9               // Adat/Parancs választó láb
#define TFT_CS          10              // Kijelző kiválasztó láb (Chip Select)
#define TFT_RST         -1              // Reset láb (Közös reseten)
#define BRIGHTNESS_PIN 14               // Fényerő szabályozó láb (PWM)
#define DSP_INVERT_TITLE false          // Címsor színeinek megfordítása (kikapcsolva)

/* SPI BUSZ (Közös a kijelző és SD kártya számára):
   GPIO 11 - MOSI | GPIO 12 - CLK | GPIO 13 - MISO 
*/
#define SPI_MOSI       11 //t_din
#define SPI_CLK        12 //t_clk
#define SPI_MISO       13 //t_dq, vagy t_out

/*----- Touch ISP (Érintőpanel) -----*/
#define TS_MODEL TS_MODEL_XPT2046       // Érintőpanel típusa
#define TS_CS           3               // Érintőpanel választó lába

// #define TS_MODEL TS_MODEL_FT6X36     // Kapacitív érintőpanel (inaktív)
// #define X_TOUCH_MIRRORING            // Érintés vízszintes tükrözése (inaktív)
// #define Y_TOUCH_MIRRORING            // Érintés függőleges tükrözése (inaktív)

/*----- PCM5102A DAC (Audio kimenet) -----*/
#define I2S_DOUT        6               // Digitális hang adat kimenet
#define I2S_BCLK        4               // Bit órajel
#define I2S_LRC         5               // Bal/Jobb csatorna szinkron órajel

/*----- ENCODER 1 (Fő tekerő) ------*/
#define ENC_BTNR       41 // S2         // Jobbra forgatás
#define ENC_BTNL       40 // S1         // Balra forgatás
#define ENC_BTNB       39 // KEY        // Nyomógomb
// #define ENC_INTERNALPULLUP true      // Belső felhúzó ellenállás (inaktív)

/*----- ENCODER 2 (Másodlagos tekerő) -----*/
// Az eredeti pinjeit a te értékeidre írtam át
//#define ENC2_BTNR      47 // S2
//#define ENC2_BTNL      48 // S1
//#define ENC2_BTNB      21 // KEY
// #define ENC2_INTERNALPULLUP true

/*----- CLOCK MODUL RTC DS3132 (Külső óra modul) -----*/
// #define RTC_SCL                7      // RTC órajel (inaktív)
// #define RTC_SDA                8      // RTC adat (inaktív)
// #define RTC_MODULE DS3231             // RTC típusa (inaktív)

/*----- REMOTE CONTROL (Infra vevő) -----*/
//#define IR_PIN         38               // Infra vevő (távirányító) lába

/*----- SD CARD (Adattárolás) -----*/
#define SDC_CS          1               // SD kártya választó lába
#define SDSPISPEED 16000000             // 16MHz sebesség (a te beállításod)

/*----- Felületi extrák (Maciej Bednarski) -----*/
#define PLAYLIST_SCROLL_MOVING_CURSOR   // Mozgó kurzor a listában
// #define THEME_GRAY                   // Szürkeárnyalatos téma (inaktív)
// #define CLOCKFONT_MONO               // Monospaced óra számok (inaktív)
// #define AM_PM_STYLE                  // 12 órás időkijelzés (inaktív)
// #define CLOCKFONT VT_DIGI_OLD        // Régi digitális óra betűtípus (inaktív)

/*----- Google TTS (Idő bemondása) -----*/
//#define CLOCK_TTS_ENABLED          false 
//#define CLOCK_TTS_LANGUAGE          "HU" 
//#define CLOCK_TTS_INTERVAL_MINUTES 15   

/*----- Időjárás és megjelenítés -----*/
#define WEATHER_FMT_SHORT               // Rövid időjárás sáv
// #define EXT_WEATHER  true            // Részletes időjárás (inaktív)
#define WIND_SPEED_IN_KMH               // Szélsebesség km/h-ban

/*----- VU Meter (Kivezérlésjelző) -----*/
// #define BOOMBOX_STYLE                // Középről kifelé mozgó VU (inaktív)
#define VU_PEAK                         // Csúcsérték jelölése fehér csíkkal

/*----- Csatornaváltás és lista -----*/
//#define DIRECT_CHANNEL_CHANGE           // Azonnali váltás tekeréskor
#define STATIONS_LIST_RETURN_TIME 3     // Visszalépés a főoldalra 3 mp után

/*----- Erősítő vezérlés (PWR_AMP) -----*/
// GPIO 38-as lábat használod az erősítőhöz is
#define PWR_AMP        15

/*----- SPEAKER RELAY (Anti-Pop) -----*/
#define SPKRS_RELAY  16 // Perregésgátló relék - erősitő indulás után 2mp-vel kapcsolanak és fordítva

// Speaker relay unmute késleltetés (ms)
// állítsd 200..500 között ízlés szerint
#define SPKRS_UNMUTE_DELAY_MS 200

/*----- Stabilitás (Andrzej Jaroszuk) -----*/
// Megtartottam a kikommentelt állapotot a te kérésedre, de az opció ott van
//#define ENABLE_STALL_WATCHDOG         // Buffer ürülés figyelő (inaktív)
#define USE_DLNA
#define DLNA_NAME "YoNo-Radio"
#define USE_MR_DLNA             // Ez aktiválja a Media Renderer-t
#define DLNA_AUTOSTART true      // Ez elindítja a szolgáltatást bootoláskor
#define dlnaIDX "all"
#define dlnaHost ""
#define USE_SSDP
#define SSDP_NAME "YoNo-Radio"
#define SSDP_MODEL_NAME "YoNo-Radio-V2" //ipcím/description.xml - ez vissza adja hogy megy-e a dlne funkcio
#endif // myoptions_h