#pragma once
#include <Arduino.h>

// Web-szerű TFT UI gomb azonosítók (touch hitTest-hez és WEBUIBTN eventhez)
// FONTOS: ezt a fejlécet úgy tartjuk minimálisnak, hogy a core modulok (pl. controls.cpp)
// is be tudják húzni a teljes widgets grafikus stack (Canvas/Adafruit_GFX) nélkül.
enum class WebUiBtn : uint8_t {
  NONE = 0,
  RADIO,
  SD,
  DLNA,
  EQ,
  SETTINGS,
  PREV,
  PLAYPAUSE,
  STOP,
  NEXT
};
