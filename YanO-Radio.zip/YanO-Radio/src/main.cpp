#include "Arduino.h"
#include "clock_tts/clock_tts.h" 
#include "core/options.h"
#include "core/config.h"
#include "pluginsManager/pluginsManager.h"
#include "core/telnet.h"
#include "core/player.h"
#ifdef USE_DLNA_RENDERER
  #include "network/dlna_renderer.h"
#endif
#ifdef USE_SOAP_DLNA
  #include "network/soapdlna_service.h"
#endif
#include "core/display.h"
#include "core/network.h"
#include "core/netserver.h"
#include "core/controls.h"
#include "core/oled_clock.h"
// #include "core/mqtt.h"
#include "core/optionschecker.h"
#include "core/timekeeper.h"
OledClock oledClock;
#ifdef USE_NEXTION
    #include "displays/nextion.h"
#endif
#include "core/audiohandlers.h" //"audio_change"
#ifdef USE_DLNA                 // DLNA mod
    #include "network/dlna_service.h"
#endif
#if USE_OTA
    #if ESP_ARDUINO_VERSION >= ESP_ARDUINO_VERSION_VAL(3, 0, 0)
        #include <NetworkUdp.h>
    #else
        #include <WiFiUdp.h>
    #endif
    #include <ArduinoOTA.h>
#endif

#if DSP_HSPI || TS_HSPI || VS_HSPI
SPIClass SPI2(HSPI);
#endif

extern __attribute__((weak)) void yoradio_on_setup();

#if USE_OTA
void setupOTA() {
    if (strlen(config.store.mdnsname) > 0) ArduinoOTA.setHostname(config.store.mdnsname);
    #ifdef OTA_PASS
    ArduinoOTA.setPassword(OTA_PASS);
    #endif
    ArduinoOTA
        .onStart([]() {
            player.sendCommand({PR_STOP, 0});
            display.putRequest(NEWMODE, UPDATING);
            telnet.printf("Start OTA updating %s\r\n", ArduinoOTA.getCommand() == U_FLASH ? "firmware" : "filesystem");
        })
        .onEnd([]() {
            telnet.printf("\nEnd OTA update, Rebooting...\r\n");
            ESP.restart();
        })
        .onProgress([](unsigned int progress, unsigned int total) { telnet.printf("Progress OTA: %u%%\r", (progress / (total / 100))); })
        .onError([](ota_error_t error) {
            telnet.printf("Error[%u]: ", error);
            if (error == OTA_AUTH_ERROR) {
                telnet.printf("Auth Failed\r\n");
            } else if (error == OTA_BEGIN_ERROR) {
                telnet.printf("Begin Failed\r\n");
            } else if (error == OTA_CONNECT_ERROR) {
                telnet.printf("Connect Failed\r\n");
            } else if (error == OTA_RECEIVE_ERROR) {
                telnet.printf("Receive Failed\r\n");
            } else if (error == OTA_END_ERROR) {
                telnet.printf("End Failed\r\n");
            }
        });
    ArduinoOTA.begin();
}
#endif

void setup() {
	// 1. AZONNALI KIKAPCSOLÁS (Még a Serial.begin előtt!)
    // A 16-os láb kényszerítése LOW állapotba
    pinMode(16, OUTPUT);
    digitalWrite(16, LOW); 
    
    // Ha az erősítő (15) is pattan, azt is tartsuk LOW-n
    pinMode(15, OUTPUT);
    digitalWrite(15, LOW);
    Serial.begin(115200);
    if (REAL_LEDBUILTIN != 255) pinMode(REAL_LEDBUILTIN, OUTPUT);
    if (yoradio_on_setup) yoradio_on_setup();
    pm.on_setup(); // pluginsManager
    config.init();

    // Kérés: induláskor mindig a RÁDIÓ (WEB) mód legyen az alapértelmezett,
    // és az utolsó állomás automatikusan induljon el.
#ifdef USE_DLNA
    config.store.playlistSource = PL_SRC_WEB;
#endif
    if (config.getMode() != PM_WEB) {
        config.changeMode(PM_WEB);
    }

    display.init();
    player.init();
    network.begin();
    if (network.status != CONNECTED && network.status != SDREADY) {
        netserver.begin();
        initControls();
        display.putRequest(DSP_START);
        while (!display.ready()) delay(10);
        return;
    }
    if (SDC_CS != 255) {
        display.putRequest(WAITFORSD, 0);
        log_i("%s", String("##[BOOT]#\tSD search\t").c_str());
    }
    config.initPlaylistMode();
    netserver.begin();
    telnet.begin();
    initControls();
    display.putRequest(DSP_START);
    while (!display.ready()) delay(10);
#if USE_OTA
    setupOTA();
#endif
    if (config.getMode() == PM_SDCARD) player.initHeaders(config.station.url);
    player.lockOutput = false;
    // Autoplay: mindig induljon a legutolsó állomás/fájl
    player.sendCommand({PR_PLAY, config.lastStation()});

#ifdef USE_DLNA_RENDERER
    // Start DLNA MediaRenderer (Cast target). Uses separate port (9000).
    dlna_renderer::begin();
#endif
#if CLOCK_TTS_ENABLED
    clock_tts_setup(); // Módosítás: plussz sor. "clock_tts"
#endif
    if (psramFound()) {
        log_i("%s", String("✅ PSRAM elérhető!").c_str());
    } else {
        log_i("%s", String("❌ PSRAM nem található!").c_str());
    }
    Audio::audio_info_callback = my_audio_info; // "audio_change" audiohandlers.h ban kezelve.
    log_i("Total heap : %lu\n", ESP.getHeapSize());
    log_i("Free heap  : %lu\n", ESP.getFreeHeap());
    log_i("Total PSRAM: %lu\n", ESP.getPsramSize());
    log_i("Free PSRAM : %lu\n", ESP.getFreePsram());
    pm.on_end_setup();
	oledClock.begin();
}

void loop() {
    timekeeper.loop1();
    telnet.loop();

#ifdef USE_SOAP_DLNA
    // Keep SoapDLNA ready (multicast join can require WiFi up).
    static uint32_t s_soapTick = 0;
    if (millis() - s_soapTick > 5000) {
        s_soapTick = millis();
        soapdlna::begin();
    }
#endif

#ifdef USE_DLNA_RENDERER
    // Renderer discovery sometimes fails if started before WiFi is fully ready.
    // Retry periodically while connected.
    static uint32_t s_rndTick = 0;
    if (!dlna_renderer::isRunning() && (millis() - s_rndTick > 5000)) {
        s_rndTick = millis();
        dlna_renderer::begin();
    }
#endif
    if (network.status == CONNECTED || network.status == SDREADY) {
        player.loop();
#if USE_OTA
        ArduinoOTA.handle();
#endif
    }
    loopControls();
#ifdef NETSERVER_LOOP1
    netserver.loop();
#endif
#if CLOCK_TTS_ENABLED
    clock_tts_loop(); // Módosítás: plussz sor.  "clock_tts"
#endif
oledClock.update();
}
