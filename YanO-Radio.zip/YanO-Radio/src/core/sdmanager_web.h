#pragma once

#include <Arduino.h>

#ifdef USE_SD

// Nem tudjuk, hogy nálad AsyncWebServer.h vagy ESPAsyncWebServer.h a fájlnév,
// ezért itt NEM include-oljuk, csak előre deklaráljuk az osztályt.
class AsyncWebServer;

// Előre deklarációk – hogy a függvény aláírás leforduljon
class Player;
class Config;
class NetServer;

// SD kártya HTTP végpontok (listázás, feltöltés, build, törlés, módváltás)
class SdManagerWeb {
public:
  // Itt csak a típust használjuk, a valódi definíció a .cpp-ben lesz ismert.
  static void registerRoutes(AsyncWebServer& webserver);
};

#endif // USE_SD