#include <Arduino.h>

// This file provides a Hungarian-capable Print::write() override for TFT/LCD
// builds. It renders characters using the project's built-in 5x7 bitmap font
// (hu_font5x7) that contains Hungarian accented glyphs at the expected code
// positions used by utf8To() conversions.

// IMPORTANT: commongfx.h depends on display-driver typedefs (yoDisplay) and
// build options (DSP_MODEL, DSP_LCD, etc.) which are provided via dspcore/options.
// Include them first to avoid accidental compilation under the wrong branches.
#include "../../core/options.h"
#include "../dspcore.h"

#include "commongfx.h"

// Enable for *all* TFT/LCD builds (including ILI9225). The previous exclusion
// caused HU glyphs to be missing on the main TFT screen for ILI9225 users.
#if defined(DSP_LCD) && (L10N_LANGUAGE==HU)

static inline void drawChar5x7_bg(DspCore &d, int16_t x, int16_t y, uint8_t c,
                                 uint16_t fg, uint16_t bg, uint8_t size) {
  // Background fill for the full character cell (5x7 + 1px spacing) scaled.
  const int16_t cellW = 6 * (int16_t)size;
  const int16_t cellH = 8 * (int16_t)size;
  d.fillRect(x, y, cellW, cellH, bg);

  // Draw glyph pixels.
  for (uint8_t col = 0; col < 5; col++) {
    uint8_t line = pgm_read_byte(hu_font5x7 + ((uint16_t)c * 5u) + col);
    for (uint8_t row = 0; row < 7; row++) {
      if (line & 0x01) {
        if (size == 1) {
          d.drawPixel(x + col, y + row, fg);
        } else {
          d.fillRect(x + (int16_t)col * size, y + (int16_t)row * size, size, size, fg);
        }
      }
      line >>= 1;
    }
  }
}

size_t DspCore::write(uint8_t c) {
  // Match Adafruit_GFX write() behavior (newline, carriage return, wrapping).
  if (c == '\n') {
    cursor_x = 0;
    cursor_y += (int16_t)textsize_y * 8;
    return 1;
  }
  if (c == '\r') return 1;

  const int16_t charW = (int16_t)textsize_x * 6;
  const int16_t charH = (int16_t)textsize_y * 8;

  if (wrap && ((cursor_x + charW) > (int16_t)width())) {
    cursor_x = 0;
    cursor_y += charH;
  }

  drawChar5x7_bg(*this, cursor_x, cursor_y, c, textcolor, textbgcolor, textsize_x);
  cursor_x += charW;
  return 1;
}

#endif
