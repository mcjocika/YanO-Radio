//v0.9.693 Módosítva "nameday"
#include "options.h"
#include "Arduino.h"
#include <SPIFFS.h>
#include <Update.h>
#include "config.h"
#include "netserver.h"
#include "player.h"
#include "telnet.h"
#include "display.h"
#include "network.h"
#include <WiFi.h>
#include "mqtt.h"
#include "controls.h"
#include "commandhandler.h"
#include "timekeeper.h"
#include "../displays/dspcore.h"
#include "../displays/widgets/widgetsconfig.h"  //BitrateFormat
#include <SD.h>
#include <SPI.h>
#ifdef USE_DLNA  //DLNA mod
  #include "../network/dlna_index.h"
  #include "../network/dlna_service.h"
#endif
#ifdef USE_DLNA_RENDERER
  #include "../network/dlna_renderer.h"
  #include <esp_system.h>
#endif

#ifdef USE_SOAP_DLNA
  #include "../network/soapdlna_service.h"
#endif

#if DSP_MODEL == DSP_DUMMY
  #define DUMMYDISPLAY
#endif

#ifdef USE_SD
  #include "sdmanager.h"
#endif
#ifndef MIN_MALLOC
  #define MIN_MALLOC 24112
#endif
#ifndef NSQ_SEND_DELAY
  //#define NSQ_SEND_DELAY       portMAX_DELAY
  #define NSQ_SEND_DELAY pdMS_TO_TICKS(300)
#endif
#ifndef NS_QUEUE_TICKS
  //#define NS_QUEUE_TICKS pdMS_TO_TICKS(2)
  #define NS_QUEUE_TICKS 0
#endif

#ifdef DEBUG_V
  #define DBGVB(...) do { \
    char buf[200]; \
   snprintf(buf, sizeof(buf), __VA_ARGS__); \
    ESP_LOGI(TAG_NET, "%s", buf); \
 } while(0)
#else
  #define DBGVB(...)
#endif

#include "esp_log.h"
static const char* TAG_NET = "netserver";
static bool g_nsPendingValid = false;
static nsRequestParams_t g_nsPending;

#ifndef NS_DEBUG
  #define NS_DEBUG 1
#endif

#if NS_DEBUG
  #define LOGI(fmt, ...) ESP_LOGI(TAG_NET, fmt, ##__VA_ARGS__)
  #define LOGW(fmt, ...) ESP_LOGW(TAG_NET, fmt, ##__VA_ARGS__)
  #define LOGE(fmt, ...) ESP_LOGE(TAG_NET, fmt, ##__VA_ARGS__)
#else
  #define LOGI(...)
  #define LOGW(...)
  #define LOGE(...)
#endif

#ifdef USE_DLNA_RENDERER
// DLNA/Windows helper: start URL only after previous playback is fully stopped.
// Windows often sends Stop -> SetAVTransportURI -> Play quickly; without a short stop/wait,
// the first start may be silent while the old stream is still tearing down.

// DLNA renderer state tracking for Windows control points.
// Windows often polls GetTransportInfo/GetPositionInfo immediately after Play and may show
// "Unexpected device error" if the renderer reports STOPPED while it is still starting.
// We keep a small internal state machine to report TRANSITIONING during startup.
enum DlnaAvtState : uint8_t {
  DLNA_AVT_NO_MEDIA = 0,
  DLNA_AVT_STOPPED = 1,
  DLNA_AVT_TRANSITIONING = 2,
  DLNA_AVT_PLAYING = 3,
  DLNA_AVT_PAUSED = 4
};

static String s_dlnaAvtUri;
static String s_dlnaAvtTitle;
static volatile uint8_t  s_dlnaAvtState = DLNA_AVT_NO_MEDIA;
static volatile uint32_t s_dlnaAvtStateMs = 0;
static volatile bool s_dlnaPlayRequested = false; // Windows may send Play before SetAVTransportURI
static volatile bool s_dlnaIsWindowsCast = false; // Microsoft/MDEServer heuristic


static inline void dlnaSetAvtState(uint8_t st) {
  s_dlnaAvtState = st;
  s_dlnaAvtStateMs = millis();
}
struct DlnaStartJob {
  char uri[768];
  char title[192];
};

static TaskHandle_t s_dlnaStartTask = nullptr;
static portMUX_TYPE s_dlnaStartMux = portMUX_INITIALIZER_UNLOCKED;
static volatile bool s_dlnaStartHasNext = false;
static DlnaStartJob s_dlnaStartNextJob;

static void dlnaStartTask(void* pv) {
  DlnaStartJob* job = static_cast<DlnaStartJob*>(pv);

  // Handle rapid Windows flows (Next/Previous or quick URI updates):
  // if a new URI arrives while a start task is already running, we keep the latest
  // request and restart this task loop once the current attempt completes.
  for (;;) {

    // Parse host:port from http://host:port/path (Windows uses a local MDEServer with an ephemeral port).
    String uriStr(job->uri);
    String host;
    uint16_t port = 80;

    int p = uriStr.indexOf("://");
    int h0 = (p >= 0) ? (p + 3) : 0;
    int slash = uriStr.indexOf('/', h0);
    String hostport = (slash >= 0) ? uriStr.substring(h0, slash) : uriStr.substring(h0);
    int colon = hostport.indexOf(':');
    if (colon >= 0) {
      host = hostport.substring(0, colon);
      port = (uint16_t)hostport.substring(colon + 1).toInt();
    } else {
      host = hostport;
    }
    host.trim();
    if (host.length() == 0) {
      dlnaSetAvtState(DLNA_AVT_STOPPED);
      // Nothing to do for this iteration; fall through to the pending-check logic.
    }

    // Mark as transitioning during startup; Windows polls immediately after Play.
    dlnaSetAvtState(DLNA_AVT_TRANSITIONING);

    // 1) Wait until the PC's MDEServer is accepting TCP connections.
    // On the first Play, Windows may set the URI before the server is ready; an immediate connect can time out.
    bool serverReady = false;
    const uint32_t probeDeadlineMs = millis() + 9000;  // up to 9s
    if (host.length()) {
      while (!serverReady && (int32_t)(millis() - probeDeadlineMs) < 0) {
        WiFiClient probe;
        probe.setTimeout(1);
        if (probe.connect(host.c_str(), port, 500)) {
          serverReady = true;
          probe.stop();
          break;
        }
        vTaskDelay(pdMS_TO_TICKS(250));
      }
    }

    // 2) Stop current playback only when we are ready to start (minimize silent gaps).
    // We may already have stopped earlier at SetAVTransportURI; this is idempotent.
    if (player.isRunning()) {
      player.sendCommand({PR_STOP, 0});
      const TickType_t t0 = xTaskGetTickCount();
      while (player.isRunning() && (xTaskGetTickCount() - t0) < pdMS_TO_TICKS(2500)) {
        vTaskDelay(pdMS_TO_TICKS(20));
      }
      // Extra settle time for TCP/I2S resources to release.
      vTaskDelay(pdMS_TO_TICKS(150));
    }

    // If the server was not ready within the deadline, try starting anyway once; do not loop forever.
    if (job->title[0]) player.playUrl(job->uri, job->title);
    else player.playUrl(job->uri, nullptr);

    // Give player a short moment to enter RUNNING; Windows may poll immediately after Play.
    const TickType_t t1 = xTaskGetTickCount();
    while (!player.isRunning() && (xTaskGetTickCount() - t1) < pdMS_TO_TICKS(1500)) {
      vTaskDelay(pdMS_TO_TICKS(30));
    }

    // One quick retry helps when the very first connect races the PC server startup.
    if (!player.isRunning()) {
      vTaskDelay(pdMS_TO_TICKS(400));
      if (job->title[0]) player.playUrl(job->uri, job->title);
      else player.playUrl(job->uri, nullptr);

      const TickType_t t2 = xTaskGetTickCount();
      while (!player.isRunning() && (xTaskGetTickCount() - t2) < pdMS_TO_TICKS(1500)) {
        vTaskDelay(pdMS_TO_TICKS(30));
      }
    }

    if (player.isRunning()) dlnaSetAvtState(DLNA_AVT_PLAYING);
    else dlnaSetAvtState(s_dlnaAvtUri.length() ? DLNA_AVT_STOPPED : DLNA_AVT_NO_MEDIA);

    // If a new start request arrived while we were working, restart the loop with the latest URI.
    bool hasNext = false;
    portENTER_CRITICAL(&s_dlnaStartMux);
    if (s_dlnaStartHasNext) {
      memcpy(job, &s_dlnaStartNextJob, sizeof(DlnaStartJob));
      s_dlnaStartHasNext = false;
      hasNext = true;
    }
    portEXIT_CRITICAL(&s_dlnaStartMux);
    if (hasNext) continue;
    break;
  }

  delete job;
  s_dlnaStartTask = nullptr;
  vTaskDelete(nullptr);
}

static void scheduleDlnaStart(const String& uri, const String& title) {
  if (!uri.length()) return;

  // If a start task is already running, keep only the latest request.
  if (s_dlnaStartTask) {
    portENTER_CRITICAL(&s_dlnaStartMux);
    memset(&s_dlnaStartNextJob, 0, sizeof(s_dlnaStartNextJob));
    strlcpy(s_dlnaStartNextJob.uri, uri.c_str(), sizeof(s_dlnaStartNextJob.uri));
    if (title.length()) strlcpy(s_dlnaStartNextJob.title, title.c_str(), sizeof(s_dlnaStartNextJob.title));
    s_dlnaStartHasNext = true;
    portEXIT_CRITICAL(&s_dlnaStartMux);
    return;
  }

  DlnaStartJob* job = new DlnaStartJob();
  memset(job, 0, sizeof(DlnaStartJob));
  strlcpy(job->uri, uri.c_str(), sizeof(job->uri));
  if (title.length()) strlcpy(job->title, title.c_str(), sizeof(job->title));

  xTaskCreatePinnedToCore(dlnaStartTask, "dlnaStart", 4096, job, 1, &s_dlnaStartTask, 0);
}
#endif


#ifdef DEBUG_V
  #define DBGVB(...) do { \
    char buf[200]; \
    snprintf(buf, sizeof(buf), __VA_ARGS__); \
    LOGI("%s", buf); \
  } while(0)
#else
  #define DBGVB(...)
#endif

//#define CORS_DEBUG //Enable CORS policy: 'Access-Control-Allow-Origin' (for testing)

NetServer netserver;

AsyncWebServer webserver(80);
AsyncWebSocket websocket("/ws");

void handleUpload(AsyncWebServerRequest *request, String filename, size_t index, uint8_t *data, size_t len, bool final);
void handleIndex(AsyncWebServerRequest *request);
void handleNotFound(AsyncWebServerRequest *request);
void onWsEvent(AsyncWebSocket *server, AsyncWebSocketClient *client, AwsEventType type, void *arg, uint8_t *data, size_t len);

bool shouldReboot = false;
#ifdef MQTT_ROOT_TOPIC
//Ticker mqttplaylistticker;
bool mqttplaylistblock = false;
void mqttplaylistSend() {
  mqttplaylistblock = true;
  //  mqttplaylistticker.detach();
  mqttPublishPlaylist();
  mqttplaylistblock = false;
}
#endif

char *updateError() {
  sprintf(netserver.nsBuf, "Update failed with error (%d)<br /> %s", (int)Update.getError(), Update.errorString());
  return netserver.nsBuf;
}
//////innen
bool NetServer::begin(bool quiet) {
  if (network.status == SDREADY) {
	   LOGW("begin(): network.status==SDREADY, but continuing init (FIX)");
   // return true;
  }
  if (!quiet) {
    log_i("%s", String("##[BOOT]#\tnetserver.begin\t").c_str());
  }
  importRequest = IMDONE;
  irRecordEnable = false;
  playerBufMax = psramInit() ? 300000 : 1600 * config.store.abuff;
  nsQueue = xQueueCreate(80, sizeof(nsRequestParams_t));
  while (nsQueue == NULL) {
    ;
  }
  // ---- flush 1 pending request, ha volt olyan requestOnChange hívás ami túl korán jött ----
if (g_nsPendingValid) {
  BaseType_t ok = xQueueSend(nsQueue, &g_nsPending, 0);
  if (ok == pdTRUE) {
    LOGW("begin(): flushed pending type=%d clientId=%d", (int)g_nsPending.type, (int)g_nsPending.clientId);
  } else {
    LOGE("begin(): flush pending FAILED type=%d clientId=%d", (int)g_nsPending.type, (int)g_nsPending.clientId);
  }
  g_nsPendingValid = false;
}

  webserver.on("/", HTTP_ANY, handleIndex);

#ifdef USE_DLNA_RENDERER
  // Windows-friendly UPnP/DLNA device description override.
  // The MediaRenderer services themselves are still served by tiny_dlna on port 9000,
  // but we publish a richer device.xml on port 80 that points back to the 9000 services via URLBase.
  webserver.on("/device.xml", HTTP_GET, [](AsyncWebServerRequest *request) {
    const String ip = WiFi.localIP().toString();
    const String urlBase = "http://" + ip + ":9000";

    // Build a stable UDN from MAC (matches renderer strategy, without depending on tiny_dlna API).
    char udnBuf[64];
    {
      const uint64_t mac = ESP.getEfuseMac();
      const uint32_t m1 = (uint32_t)(mac & 0xFFFFFFFFULL);
      const uint32_t m2 = (uint32_t)((mac >> 32) & 0xFFFFFFFFULL);
      snprintf(udnBuf, sizeof(udnBuf),
               "uuid:%08x-%04x-%04x-%04x-%04x%08x",
               (unsigned)m1,
               (unsigned)((m2 >> 16) & 0xFFFF),
               (unsigned)(m2 & 0xFFFF),
               (unsigned)((m1 >> 16) & 0xFFFF),
               (unsigned)(m1 & 0xFFFF),
               (unsigned)m2);
    }
    const String udn = String(udnBuf);

    // Friendly name: prefer configured mDNS name if set.
    String fn;
    if (config.store.mdnsname[0]) fn = String(config.store.mdnsname);
    else fn = "YanO-Radio-Player";

    String xml;
    xml.reserve(2200);
    xml += "<?xml version=\"1.0\"?>\n";
    xml += "<root xmlns=\"urn:schemas-upnp-org:device-1-0\" ";
    xml += "xmlns:dlna=\"urn:schemas-dlna-org:device-1-0\" ";
    xml += "xmlns:pnpx=\"http://schemas.microsoft.com/windows/pnpx/2005/11\" ";
    xml += "xmlns:df=\"http://schemas.microsoft.com/windows/2008/09/devicefoundation\">\n";
    xml += "  <specVersion><major>1</major><minor>0</minor></specVersion>\n";
    xml += "  <URLBase>" + urlBase + "</URLBase>\n";
    xml += "  <device>\n";
    xml += "    <deviceType>urn:schemas-upnp-org:device:MediaRenderer:1</deviceType>\n";
    xml += "    <friendlyName>" + fn + "</friendlyName>\n";
    xml += "    <manufacturer>mcjocika</manufacturer>\n";
    xml += "    <manufacturerURL>" + urlBase + "</manufacturerURL>\n";
    xml += "    <modelDescription>YoRadio DLNA MediaRenderer</modelDescription>\n";
    xml += "    <modelName>YoRadio</modelName>\n";
    xml += "    <modelURL>" + urlBase + "</modelURL>\n";
    xml += "    <modelNumber>1.0</modelNumber>\n";
    xml += "    <serialNumber>1.0</serialNumber>\n";
    xml += "    <UDN>" + udn + "</UDN>\n";
    xml += "    <pnpx:X_compatibleId>MS_DigitalMediaDeviceClass_DMR_V001</pnpx:X_compatibleId>\n";
    xml += "    <pnpx:X_deviceCategory>MediaDevices</pnpx:X_deviceCategory>\n";
    xml += "    <df:X_deviceCategory>Multimedia.DMR</df:X_deviceCategory>\n";
    xml += "    <df:X_modelId>YanO Digital Media Renderer</df:X_modelId>\n";
    xml += "    <dlna:X_DLNADOC>DMR-1.50</dlna:X_DLNADOC>\n";
    xml += "    <iconList>\n";
    xml += "      <icon><mimetype>image/png</mimetype><width>48</width><height>48</height><depth>24</depth><url>/icon.png</url></icon>\n";
    xml += "      <icon><mimetype>image/png</mimetype><width>128</width><height>128</height><depth>24</depth><url>/icon128.png</url></icon>\n";
    xml += "      <icon><mimetype>image/png</mimetype><width>512</width><height>512</height><depth>24</depth><url>/icon512.png</url></icon>\n";
    xml += "    </iconList>\n";
    xml += "    <serviceList>\n";
    // AVTransport control: Windows relies on GetPositionInfo, which some tiny_dlna builds do not implement.
    // Route control to the main webserver (port 80) where we can provide missing actions and proxy the rest.
    // Keep SCPDURL and eventSubURL on URLBase (9000) where tiny_dlna serves them.
    xml += "      <service><serviceType>urn:schemas-upnp-org:service:AVTransport:1</serviceType><serviceId>urn:upnp-org:serviceId:AVTransport</serviceId><SCPDURL>/AVT/service.xml</SCPDURL><controlURL>http://" + ip + "/AVT/control</controlURL><eventSubURL>http://" + ip + "/AVT/event</eventSubURL></service>\n";
    // ConnectionManager control is handled by the main webserver (port 80) to ensure Windows gets a non-empty Sink.
    // Keep SCPDURL and eventSubURL on URLBase (9000) where tiny_dlna serves them.
    xml += "      <service><serviceType>urn:schemas-upnp-org:service:ConnectionManager:1</serviceType><serviceId>urn:upnp-org:serviceId:ConnectionManager</serviceId><SCPDURL>/CM/service.xml</SCPDURL><controlURL>http://" + ip + "/CM/control</controlURL><eventSubURL>http://" + ip + "/CM/event</eventSubURL></service>\n";
    // RenderingControl: Windows may use a different XML prefix (m:) than some tiny_dlna SOAP parsers expect.
    // Route control to the main webserver (port 80) where we accept Windows' SOAP and proxy if needed.
    xml += "      <service><serviceType>urn:schemas-upnp-org:service:RenderingControl:1</serviceType><serviceId>urn:upnp-org:serviceId:RenderingControl</serviceId><SCPDURL>/RC/service.xml</SCPDURL><controlURL>http://" + ip + "/RC/control</controlURL><eventSubURL>http://" + ip + "/RC/event</eventSubURL></service>\n";
    xml += "    </serviceList>\n";
    xml += "  </device>\n";
    xml += "</root>\n";

    AsyncWebServerResponse *r = request->beginResponse(200, "application/xml", xml);
    r->addHeader("Cache-Control", "max-age=1800");
    request->send(r);
  });

  // Provide tiny placeholder icons so Windows clients don't spam 404s.
  // (The UI may later replace these with real images served from FS.)
  static const uint8_t kDlnaIconPng[] PROGMEM = {
      0x89,0x50,0x4E,0x47,0x0D,0x0A,0x1A,0x0A,0x00,0x00,0x00,0x0D,0x49,0x48,0x44,0x52,
      0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x01,0x08,0x06,0x00,0x00,0x00,0x1F,0x15,0xC4,
      0x89,0x00,0x00,0x00,0x0A,0x49,0x44,0x41,0x54,0x78,0x9C,0x63,0x00,0x01,0x00,0x00,
      0x05,0x00,0x01,0x0D,0x0A,0x2D,0xB4,0x00,0x00,0x00,0x00,0x49,0x45,0x4E,0x44,0xAE,
      0x42,0x60,0x82
  };
  auto sendDlnaIcon = [=](AsyncWebServerRequest *request) {
    AsyncWebServerResponse *r = request->beginResponse_P(200, "image/png", kDlnaIconPng, sizeof(kDlnaIconPng));
    r->addHeader("Cache-Control", "max-age=86400");
    request->send(r);
  };
  webserver.on("/icon.png", HTTP_GET, sendDlnaIcon);
  webserver.on("/icon128.png", HTTP_GET, sendDlnaIcon);
  webserver.on("/icon512.png", HTTP_GET, sendDlnaIcon);

  // ConnectionManager event subscription endpoint for Windows compatibility.
  // Some Windows DLNA control points abort if they cannot SUBSCRIBE to CM/event.
  // AsyncWebServer does not recognize the SUBSCRIBE method, leaving request->method() as HTTP_ANY,
  // so we match HTTP_ANY and respond with the mandatory SID/TIMEOUT headers.
  webserver.on("/CM/event", HTTP_ANY, [](AsyncWebServerRequest *request) {
    String sid;
    if (request->hasHeader("SID")) sid = request->getHeader("SID")->value();
    if (!sid.length()) {
      sid = "uuid:" + String((uint32_t)esp_random(), HEX);
    }
    String timeout = "Second-1800";
    if (request->hasHeader("TIMEOUT")) {
      String t = request->getHeader("TIMEOUT")->value();
      if (t.length()) timeout = t;
    }
    AsyncWebServerResponse *r = request->beginResponse(200, "text/plain", "");
    r->addHeader("SID", sid);
    r->addHeader("TIMEOUT", timeout);
    r->addHeader("Ext", "");
    r->addHeader("Connection", "close");
    request->send(r);
  });
  // AVTransport event endpoint (port 80): Windows subscribes here. We acknowledge subscriptions to avoid
  // relying on tiny_dlna's notifier (which may not honor CALLBACK port on some builds).
  webserver.on("/AVT/event", HTTP_ANY, [](AsyncWebServerRequest *request) {
    String sid;
    if (request->hasHeader("SID")) sid = request->getHeader("SID")->value();
    if (!sid.length()) {
      sid = "uuid:" + String((uint32_t)esp_random(), HEX);
    }
    String timeout = "Second-1800";
    if (request->hasHeader("TIMEOUT")) {
      String t = request->getHeader("TIMEOUT")->value();
      if (t.length()) timeout = t;
    }
    AsyncWebServerResponse *r = request->beginResponse(200, "text/plain", "");
    r->addHeader("SID", sid);
    r->addHeader("TIMEOUT", timeout);
    r->addHeader("Ext", "");
    r->addHeader("Connection", "close");
    request->send(r);
  });

  // RenderingControl event endpoint (port 80): acknowledge subscriptions for Windows compatibility.
  webserver.on("/RC/event", HTTP_ANY, [](AsyncWebServerRequest *request) {
    String sid;
    if (request->hasHeader("SID")) sid = request->getHeader("SID")->value();
    if (!sid.length()) {
      sid = "uuid:" + String((uint32_t)esp_random(), HEX);
    }
    String timeout = "Second-1800";
    if (request->hasHeader("TIMEOUT")) {
      String t = request->getHeader("TIMEOUT")->value();
      if (t.length()) timeout = t;
    }
    AsyncWebServerResponse *r = request->beginResponse(200, "text/plain", "");
    r->addHeader("SID", sid);
    r->addHeader("TIMEOUT", timeout);
    r->addHeader("Ext", "");
    r->addHeader("Connection", "close");
    request->send(r);
  });



  // Minimal ConnectionManager control implementation (SOAP POST) for Windows compatibility.
  // tiny_dlna in this project replies with an empty <Sink>, which Windows often rejects.
  // BubbleUPnP works regardless, but Windows "Play To" needs a non-empty Sink list.
  webserver.on(
      "/CM/control", HTTP_POST,
      [](AsyncWebServerRequest *request) {
        // Body is handled in the body callback below.
      },
      nullptr,
      [](AsyncWebServerRequest *request, uint8_t *data, size_t len, size_t index, size_t total) {
        static String body;
        // Keep last Windows "PrepareForConnection" protocol info so GetCurrentConnectionInfo can return something non-empty.
        static String lastProtocolInfo;
        if (index == 0) body = "";
        body.reserve(total + 16);
        // Append raw bytes safely (body is XML text, not null-terminated).
        body.concat((const char*)data, len);
        if (index + len < total) return;

        String action;
        if (request->hasHeader("SOAPACTION")) {
          action = request->getHeader("SOAPACTION")->value();
        }
        action.toUpperCase();


	        // IMPORTANT: Some control points (BubbleUPnP / Hi-Fi Cast "Audio Cast") choose the *highest fidelity*
	        // format from Sink protocol info. If we advertise WAV, they often transcode to WAV (large bandwidth)
	        // which can cause stalls/stop loops on some networks/devices.
	        // Windows "Cast to device" is fine with MP3/AAC and still needs a non-empty Sink.
	        // So: advertise WAV *only* to Microsoft control points.
	        String ua;
	        if (request->hasHeader("User-Agent")) ua = request->getHeader("User-Agent")->value();
	        const bool isMicrosoft = (ua.indexOf("Microsoft") >= 0) || (ua.indexOf("Windows") >= 0);

	        String sink =
	            "http-get:*:audio/mpeg:DLNA.ORG_PN=MP3;DLNA.ORG_OP=01;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000,"
	            "http-get:*:audio/mpeg:*,"
	            "http-get:*:audio/aac:DLNA.ORG_PN=AAC_ISO;DLNA.ORG_OP=01;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000,"
	            "http-get:*:audio/aac:*,"
	            "http-get:*:audio/flac:*,"
	            "http-get:*:audio/ogg:*,"
	            "http-get:*:application/ogg:*,"
	            "http-get:*:audio/opus:*,"
	            "http-get:*:audio/vorbis:*";
	        if (isMicrosoft) {
	          sink += ",http-get:*:audio/wav:*,http-get:*:audio/x-wav:*";
	        }

        auto sendSoap = [&](const String &innerBody) {
          String resp;
          resp.reserve(512 + innerBody.length());
          resp += "<?xml version=\"1.0\"?>";
          resp += "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">";
          resp += "<s:Body>";
          resp += innerBody;
          resp += "</s:Body></s:Envelope>";
          AsyncWebServerResponse *r = request->beginResponse(200, "text/xml", resp);
          r->addHeader("Ext", "");
          r->addHeader("Connection", "close");
          request->send(r);
        };

        if (action.indexOf("#GETPROTOCOLINFO") >= 0) {
          sendSoap("<u:GetProtocolInfoResponse xmlns:u=\"urn:schemas-upnp-org:service:ConnectionManager:1\">"
                   "<Source></Source>"
                   "<Sink>" + sink + "</Sink>"
                   "</u:GetProtocolInfoResponse>");
          return;
        }

        if (action.indexOf("#GETCURRENTCONNECTIONIDS") >= 0) {
          sendSoap("<u:GetCurrentConnectionIDsResponse xmlns:u=\"urn:schemas-upnp-org:service:ConnectionManager:1\">"
                   "<ConnectionIDs>0</ConnectionIDs>"
                   "</u:GetCurrentConnectionIDsResponse>");
          return;
        }

        if (action.indexOf("#GETCURRENTCONNECTIONINFO") >= 0) {
          const String proto = (lastProtocolInfo.length() ? lastProtocolInfo : String("http-get:*:audio/mpeg:*"));
          sendSoap("<u:GetCurrentConnectionInfoResponse xmlns:u=\"urn:schemas-upnp-org:service:ConnectionManager:1\">"
                   "<RcsID>0</RcsID><AVTransportID>0</AVTransportID><ProtocolInfo>" + proto + "</ProtocolInfo><PeerConnectionManager></PeerConnectionManager><PeerConnectionID>-1</PeerConnectionID><Direction>Input</Direction><Status>OK</Status>"
                   "</u:GetCurrentConnectionInfoResponse>");
          return;
        }

        // Windows "Cast to device" frequently calls PrepareForConnection before SetAVTransportURI.
        // Provide a minimal, standards-compliant response so Windows continues.
        if (action.indexOf("#PREPAREFORCONNECTION") >= 0) {
          // Try to capture RemoteProtocolInfo from request body for later GetCurrentConnectionInfo.
          int a = body.indexOf("<RemoteProtocolInfo>");
          int b = body.indexOf("</RemoteProtocolInfo>");
          if (a >= 0 && b > a) {
            a += String("<RemoteProtocolInfo>").length();
            lastProtocolInfo = body.substring(a, b);
          } else {
            // Fallback to a generic but valid protocol.
            lastProtocolInfo = String("http-get:*:audio/mpeg:*");
          }

          sendSoap("<u:PrepareForConnectionResponse xmlns:u=\"urn:schemas-upnp-org:service:ConnectionManager:1\">"
                   "<ConnectionID>0</ConnectionID><AVTransportID>0</AVTransportID><RcsID>0</RcsID>"
                   "</u:PrepareForConnectionResponse>");
          return;
        }

        // Windows may call ConnectionComplete after a failed attempt; acknowledge it.
        if (action.indexOf("#CONNECTIONCOMPLETE") >= 0) {
          sendSoap("<u:ConnectionCompleteResponse xmlns:u=\"urn:schemas-upnp-org:service:ConnectionManager:1\"></u:ConnectionCompleteResponse>");
          return;
        }

        sendSoap("<s:Fault><faultcode>s:Client</faultcode><faultstring>UPnPError</faultstring>"
                 "<detail><UPnPError xmlns=\"urn:schemas-upnp-org:control-1-0\">"
                 "<errorCode>401</errorCode><errorDescription>Invalid Action</errorDescription>"
                 "</UPnPError></detail></s:Fault>");
      });

  // RenderingControl control shim (Windows compatibility).
  // Some clients (notably Windows) use the "m:" prefix in the SOAP body, while some tiny_dlna SOAP parsers
  // only recognize "u:". We implement the common RC actions locally and proxy unknown ones to tiny_dlna.
  webserver.on(
      "/RC/control", HTTP_POST,
      [](AsyncWebServerRequest *request) {
        // Body is handled in the body callback below.
      },
      nullptr,
      [](AsyncWebServerRequest *request, uint8_t *data, size_t len, size_t index, size_t total) {
        static String body;
        if (index == 0) body = "";
        body.reserve(total + 16);
        body += String((const char *)data).substring(0, len);
        if (index + len < total) return;

        String action;
        String soapActionHeader;
        if (request->hasHeader("SOAPACTION")) {
          soapActionHeader = request->getHeader("SOAPACTION")->value();
          action = soapActionHeader;
        } else if (request->hasHeader("SOAPAction")) {
          soapActionHeader = request->getHeader("SOAPAction")->value();
          action = soapActionHeader;
        }
        action.toUpperCase();

        auto sendSoap = [&](const String &innerBody) {
          String resp;
          resp.reserve(512 + innerBody.length());
          resp += "<?xml version=\"1.0\"?>";
          resp += "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">";
          resp += "<s:Body>";
          resp += innerBody;
          resp += "</s:Body></s:Envelope>";
          AsyncWebServerResponse *r = request->beginResponse(200, "text/xml", resp);
          r->addHeader("Ext", "");
          r->addHeader("Connection", "close");
          request->send(r);
        };

        // Windows SOAP often adds attributes to tags, e.g.
        // <DesiredVolume xmlns:dt="..." dt:dt="ui2">15</DesiredVolume>
        // so we must accept "<TAG ...>" not only "<TAG>".
        auto extractTagValue = [&](const String &tag) -> String {
          const String openPrefix = "<" + tag;
          int pos = 0;
          for (;;) {
            int a = body.indexOf(openPrefix, pos);
            if (a < 0) return "";
            const int next = a + openPrefix.length();
            // Ensure exact tag match (avoid matching e.g. CurrentURI vs CurrentURIMetaData).
            const char c = (next < (int)body.length()) ? body[next] : '\0';
            if (c == '>' || c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '/') {
              int gt = body.indexOf('>', next);
              if (gt < 0) return "";
              gt += 1;
              const String close = "</" + tag + ">";
              int b = body.indexOf(close, gt);
              if (b < 0) return "";
              String v = body.substring(gt, b);
              v.trim();
              return v;
            }
            pos = next;
          }
        };

        auto parseIntTag = [&](const String &tag) -> int {
          const String v = extractTagValue(tag);
          if (!v.length()) return -1;
          return v.toInt();
        };

        // Common Windows RC actions
        if (action.indexOf("#GETMUTE") >= 0) {
          // 0 = not muted
          sendSoap("<u:GetMuteResponse xmlns:u=\"urn:schemas-upnp-org:service:RenderingControl:1\">"
                   "<CurrentMute>0</CurrentMute>"
                   "</u:GetMuteResponse>");
          return;
        }

        if (action.indexOf("#SETMUTE") >= 0) {
          static int s_lastNonZeroVol = -1;
          int v = parseIntTag("DesiredMute");
          if (v > 0) {
            // Remember last non-zero volume for unmute.
            if ((int)config.store.volume > 0) s_lastNonZeroVol = (int)config.store.volume;
            config.store.volume = 0;
            player.setVol(0);
          } else {
            int restore = (s_lastNonZeroVol > 0) ? s_lastNonZeroVol : (int)config.store.volume;
            if (restore <= 0) restore = 8; // sensible default
            config.store.volume = restore;
            player.setVol(restore);
          }
          sendSoap("<u:SetMuteResponse xmlns:u=\"urn:schemas-upnp-org:service:RenderingControl:1\"></u:SetMuteResponse>");
          return;
        }

        if (action.indexOf("#GETVOLUME") >= 0) {
          int v = (int)config.store.volume;
          if (v < 0) v = 0;
          if (v > 100) v = 100;
          sendSoap("<u:GetVolumeResponse xmlns:u=\"urn:schemas-upnp-org:service:RenderingControl:1\">"
                   "<CurrentVolume>" + String(v) + "</CurrentVolume>"
                   "</u:GetVolumeResponse>");
          return;
        }

        if (action.indexOf("#SETVOLUME") >= 0) {
          int v = parseIntTag("DesiredVolume");
          if (v < 0) v = 0;
          if (v > 100) v = 100;
          // Keep internal state in sync so Windows slider doesn't snap back.
          config.store.volume = v;
          player.setVol(v);
          sendSoap("<u:SetVolumeResponse xmlns:u=\"urn:schemas-upnp-org:service:RenderingControl:1\"></u:SetVolumeResponse>");
          return;
        }

        // Proxy unknown RenderingControl actions to tiny_dlna on port 9000.
        // Rewrite common prefix differences (m: -> u:) to satisfy simplistic SOAP parsers.
        String proxBody = body;
        proxBody.replace("<m:", "<u:");
        proxBody.replace("</m:", "</u:");
        proxBody.replace("xmlns:m=\"urn:schemas-upnp-org:service:RenderingControl:1\"", "xmlns:u=\"urn:schemas-upnp-org:service:RenderingControl:1\"");

        WiFiClient client;
        client.setTimeout(2);
        const String selfIp = WiFi.localIP().toString();
        if (!client.connect(selfIp.c_str(), 9000)) {
          sendSoap("<s:Fault><faultcode>s:Server</faultcode><faultstring>UPnPError</faultstring>"
                   "<detail><UPnPError xmlns=\"urn:schemas-upnp-org:control-1-0\">"
                   "<errorCode>501</errorCode><errorDescription>Action Failed</errorDescription>"
                   "</UPnPError></detail></s:Fault>");
          return;
        }

        String req;
        req.reserve(proxBody.length() + 256);
        req += "POST /RC/control HTTP/1.1\r\n";
        req += "Host: " + selfIp + ":9000\r\n";
        req += "Content-Type: text/xml; charset=\"utf-8\"\r\n";
        if (soapActionHeader.length()) {
          req += "SOAPAction: " + soapActionHeader + "\r\n";
        }
        req += "Content-Length: " + String(proxBody.length()) + "\r\n";
        req += "Connection: close\r\n\r\n";
        req += proxBody;
        client.print(req);

        String statusLine = client.readStringUntil('\n');
        statusLine.trim();
        int statusCode = 200;
        if (statusLine.startsWith("HTTP/")) {
          int sp = statusLine.indexOf(' ');
          if (sp > 0) {
            int sp2 = statusLine.indexOf(' ', sp + 1);
            String code = (sp2 > sp) ? statusLine.substring(sp + 1, sp2) : statusLine.substring(sp + 1);
            statusCode = code.toInt();
            if (statusCode <= 0) statusCode = 200;
          }
        }

        int contentLen = -1;
        String contentType = "text/xml";
        for (;;) {
          String line = client.readStringUntil('\n');
          line.trim();
          if (line.length() == 0) break;
          String u = line;
          u.toUpperCase();
          if (u.startsWith("CONTENT-LENGTH:")) {
            contentLen = line.substring(String("Content-Length:").length()).toInt();
          } else if (u.startsWith("CONTENT-TYPE:")) {
            contentType = line.substring(String("Content-Type:").length());
            contentType.trim();
          }
        }

        String respBody;
        if (contentLen >= 0) {
          respBody.reserve(contentLen + 8);
          while (contentLen > 0 && client.connected()) {
            uint8_t buf[256];
            size_t want = (contentLen > (int)sizeof(buf)) ? sizeof(buf) : (size_t)contentLen;
            int n = client.readBytes((char*)buf, want);
            if (n <= 0) break;
            respBody.concat((const char*)buf, (unsigned)n);
            contentLen -= n;
          }
        } else {
          while (client.connected()) {
            String chunk = client.readString();
            if (!chunk.length()) break;
            respBody += chunk;
          }
        }
        client.stop();

        AsyncWebServerResponse *r = request->beginResponse(statusCode, contentType, respBody);
        r->addHeader("Ext", "");
        r->addHeader("Connection", "close");
        request->send(r);
      });

  // AVTransport control proxy with Windows GetPositionInfo support.
  // Windows "Cast to device" polls GetPositionInfo early; if the renderer replies "Invalid Action",
  // Windows aborts before SetAVTransportURI. Some tiny_dlna versions omit this action.
  // We implement GetPositionInfo here and proxy all other AVTransport actions to tiny_dlna on port 9000.
  webserver.on(
      "/AVT/control", HTTP_POST,
      [](AsyncWebServerRequest *request) {
        // Body is handled in the body callback below.
      },
      nullptr,
      [](AsyncWebServerRequest *request, uint8_t *data, size_t len, size_t index, size_t total) {
        static String body;
        // Track last DLNA URI set by the control point (Windows).
        // Some Windows flows abort if Play returns a SOAP Fault; handling SetAVTransportURI/Play here
        // makes playback robust without depending on tiny_dlna's AVTransport implementation.
        if (index == 0) body = "";
        body.reserve(total + 16);
        body += String((const char *)data).substring(0, len);
        if (index + len < total) return;

        String action;
        String soapActionHeader;
        if (request->hasHeader("SOAPACTION")) {
          soapActionHeader = request->getHeader("SOAPACTION")->value();
          action = soapActionHeader;
        } else if (request->hasHeader("SOAPAction")) {
          soapActionHeader = request->getHeader("SOAPAction")->value();
          action = soapActionHeader;
        }
        action.toUpperCase();

        auto sendSoap = [&](const String &innerBody) {
          String resp;
          resp.reserve(512 + innerBody.length());
          resp += "<?xml version=\"1.0\"?>";
          resp += "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">";
          resp += "<s:Body>";
          resp += innerBody;
          resp += "</s:Body></s:Envelope>";
          AsyncWebServerResponse *r = request->beginResponse(200, "text/xml", resp);
          r->addHeader("Ext", "");
          r->addHeader("Connection", "close");
          request->send(r);
        };

        // Implement Windows-critical AVTransport action.
        if (action.indexOf("#GETPOSITIONINFO") >= 0) {
          // For streams we do not know duration/position. Return stable zero values.
          const bool hasMedia = s_dlnaAvtUri.length() > 0;
          const bool playing = player.isRunning() || (s_dlnaAvtState == DLNA_AVT_PLAYING);
          const String track = (hasMedia || playing) ? "1" : "0";
          sendSoap("<u:GetPositionInfoResponse xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">"
                   "<Track>" + track + "</Track>"
                   "<TrackDuration>00:00:00</TrackDuration>"
                   "<TrackMetaData></TrackMetaData>"
                   "<TrackURI></TrackURI>"
                   "<RelTime>00:00:00</RelTime>"
                   "<AbsTime>00:00:00</AbsTime>"
                   "<RelCount>0</RelCount>"
                   "<AbsCount>0</AbsCount>"
                   "</u:GetPositionInfoResponse>");
          return;
        }

        // Windows will typically send: Stop -> SetAVTransportURI -> Play
        // We accept SetAVTransportURI/Play here to avoid tiny_dlna SOAP Faults that make Windows abort.
        if (action.indexOf("#SETAVTRANSPORTURI") >= 0) {
          // Accept attributes in the opening tag, e.g.
          // <CurrentURI xmlns:dt="..." dt:dt="string">http://...</CurrentURI>
          auto extractTagValue = [&](const String &tag) -> String {
            const String openPrefix = "<" + tag;
            int pos = 0;
            for (;;) {
              int a = body.indexOf(openPrefix, pos);
              if (a < 0) return "";
              const int next = a + openPrefix.length();
              const char c = (next < (int)body.length()) ? body[next] : '\0';
              if (c == '>' || c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '/') {
                int gt = body.indexOf('>', next);
                if (gt < 0) return "";
                gt += 1;
                const String close = "</" + tag + ">";
                int b = body.indexOf(close, gt);
                if (b < 0) return "";
                String v = body.substring(gt, b);
                v.trim();
                return v;
              }
              pos = next;
            }
          };

          const String uri = extractTagValue("CurrentURI");
          // Heuristic: Windows "Cast to device" uses a local MDEServer URL and a Microsoft User-Agent.
          String uaAvt;
          if (request->hasHeader("User-Agent")) uaAvt = request->getHeader("User-Agent")->value();
          const bool isMicrosoftCp = (uaAvt.indexOf("Microsoft") >= 0) || (uaAvt.indexOf("Windows") >= 0);
          const bool isMdeServer = (uri.indexOf("/MDEServer/") >= 0);
          const bool isWindowsCast = isMicrosoftCp || isMdeServer;
          s_dlnaIsWindowsCast = isWindowsCast;

          if (uri.length()) {
            s_dlnaAvtUri = uri;
            // For Windows Cast (and for rare cases where Play arrives before URI), auto-start on URI arrival.
            // For other control points (BubbleUPnP / Hi-Fi Cast), wait for Play to avoid double-start loops.
            if (isWindowsCast || s_dlnaPlayRequested) {
              if (player.isRunning()) {
                player.sendCommand({PR_STOP, 0});
              }
              dlnaSetAvtState(DLNA_AVT_TRANSITIONING);
            } else {
              dlnaSetAvtState(DLNA_AVT_STOPPED);
            }
          }
          // Extract a user-friendly "Artist - Title" from Windows DIDL-Lite metadata.
          // Windows embeds DIDL-Lite XML escaped inside <CurrentURIMetaData> (e.g. &lt;dc:title&gt;...).
          s_dlnaAvtTitle = "";
          const String metaEsc = extractTagValue("CurrentURIMetaData");
          if (metaEsc.length()) {
            String meta = metaEsc;
            // Minimal XML entity unescape (enough for DIDL-Lite text).
            meta.replace("&lt;", "<");
            meta.replace("&gt;", ">");
            meta.replace("&quot;", "\"");
            meta.replace("&apos;", "'");
            meta.replace("&#39;", "'");
            meta.replace("&amp;", "&");

            auto extractFromXml = [&](const String &xml, const String &tag) -> String {
              const String openPrefix = "<" + tag;
              int pos2 = 0;
              for (;;) {
                int a2 = xml.indexOf(openPrefix, pos2);
                if (a2 < 0) return "";
                int gt2 = xml.indexOf('>', a2 + openPrefix.length());
                if (gt2 < 0) return "";
                gt2 += 1;
                const String close2 = "</" + tag + ">";
                int b2 = xml.indexOf(close2, gt2);
                if (b2 < 0) return "";
                String v2 = xml.substring(gt2, b2);
                v2.trim();
                return v2;
              }
            };

            String t = extractFromXml(meta, "dc:title");
            String a = extractFromXml(meta, "dc:creator");
            if (!a.length()) a = extractFromXml(meta, "upnp:artist");

            if (t.length() && a.length()) {
              if (t.indexOf(a) >= 0 || t.indexOf(" - ") >= 0) s_dlnaAvtTitle = t;
              else s_dlnaAvtTitle = a + " - " + t;
            } else if (t.length()) {
              s_dlnaAvtTitle = t;
            }
          }

          // Fallback: some controllers may provide a plain <dc:title> outside DIDL-Lite.
          if (!s_dlnaAvtTitle.length()) {
            const String title = extractTagValue("dc:title");
            if (title.length()) s_dlnaAvtTitle = title;
          }
                    // Start logic:
          // - Windows Cast: start immediately on URI arrival (Windows may not send Play on Next/Prev).
          // - Other control points: start only after Play, unless Play was already requested.
          if (s_dlnaAvtUri.length()) {
            if (s_dlnaIsWindowsCast || s_dlnaPlayRequested) {
              scheduleDlnaStart(s_dlnaAvtUri, s_dlnaAvtTitle);
              s_dlnaPlayRequested = false;
            }
          }
          sendSoap("<u:SetAVTransportURIResponse xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\"></u:SetAVTransportURIResponse>");
          return;
        }

        if (action.indexOf("#PLAY") >= 0) {
          // Some control points send Play before SetAVTransportURI. Remember the intent.
          s_dlnaPlayRequested = true;

          // If Windows Cast already triggered an auto-start on SetAVTransportURI, don't restart here.
          if (s_dlnaIsWindowsCast && s_dlnaStartTask) {
            s_dlnaPlayRequested = false;
            sendSoap("<u:PlayResponse xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\"></u:PlayResponse>");
            return;
          }

          if (s_dlnaAvtUri.length()) {
            dlnaSetAvtState(DLNA_AVT_TRANSITIONING);
            scheduleDlnaStart(s_dlnaAvtUri, s_dlnaAvtTitle);
            s_dlnaPlayRequested = false;
          }
          sendSoap("<u:PlayResponse xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\"></u:PlayResponse>");
          return;
        }

// Windows issues Stop during handshake; tiny_dlna may respond with a SOAP Fault which makes Windows abort.
// Treat Stop/Pause as idempotent no-ops and always return a successful response.
if (action.indexOf("#STOP") >= 0) {
  s_dlnaPlayRequested = false;
  player.sendCommand({PR_STOP, 0});
  // Windows likes keeping the last URI so it can Play again without re-setting it.
  // For other control points, clear URI to avoid stale state when switching apps.
  if (!s_dlnaIsWindowsCast) {
    s_dlnaAvtUri = "";
    s_dlnaAvtTitle = "";
    dlnaSetAvtState(DLNA_AVT_NO_MEDIA);
  } else {
    if (s_dlnaAvtUri.length()) dlnaSetAvtState(DLNA_AVT_STOPPED);
    else dlnaSetAvtState(DLNA_AVT_NO_MEDIA);
  }
  sendSoap("<u:StopResponse xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\"></u:StopResponse>");
  return;
}
if (action.indexOf("#PAUSE") >= 0) {
  s_dlnaPlayRequested = false;
  player.sendCommand({PR_STOP, 0});
  if (!s_dlnaIsWindowsCast) {
    s_dlnaAvtUri = "";
    s_dlnaAvtTitle = "";
    dlnaSetAvtState(DLNA_AVT_NO_MEDIA);
  } else {
    if (s_dlnaAvtUri.length()) dlnaSetAvtState(DLNA_AVT_PAUSED);
    else dlnaSetAvtState(DLNA_AVT_NO_MEDIA);
  }
  sendSoap("<u:PauseResponse xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\"></u:PauseResponse>");
  return;
}


// Windows "next/previous" buttons may be used for local playlists.
// We don't maintain an internal queue, but we must not fail these actions.
// Mark Play as requested so that the next SetAVTransportURI will auto-start.
if (action.indexOf("#NEXT") >= 0) {
  s_dlnaPlayRequested = true;
  dlnaSetAvtState(DLNA_AVT_TRANSITIONING);
  sendSoap("<u:NextResponse xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\"></u:NextResponse>");
  return;
}
if (action.indexOf("#PREVIOUS") >= 0) {
  s_dlnaPlayRequested = true;
  dlnaSetAvtState(DLNA_AVT_TRANSITIONING);
  sendSoap("<u:PreviousResponse xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\"></u:PreviousResponse>");
  return;
}


// Windows polls these query actions frequently during "Cast to device" handshake.
// Returning a SOAP Fault (even with HTTP 200) makes Windows abort.
if (action.indexOf("#GETTRANSPORTINFO") >= 0) {
  const bool running = player.isRunning();
  uint8_t st = s_dlnaAvtState;
  if (running) st = DLNA_AVT_PLAYING;

  // Give startup a grace window where we report TRANSITIONING even if the player hasn't become RUNNING yet.
  if (!running && st == DLNA_AVT_TRANSITIONING) {
    const uint32_t age = (uint32_t)(millis() - s_dlnaAvtStateMs);
    if (age > 6000) st = s_dlnaAvtUri.length() ? DLNA_AVT_STOPPED : DLNA_AVT_NO_MEDIA;
  }

  String state;
  switch (st) {
    case DLNA_AVT_PLAYING:       state = "PLAYING"; break;
    case DLNA_AVT_TRANSITIONING: state = "TRANSITIONING"; break;
    case DLNA_AVT_PAUSED:        state = "PAUSED_PLAYBACK"; break;
    case DLNA_AVT_STOPPED:       state = "STOPPED"; break;
    default:                     state = "NO_MEDIA_PRESENT"; break;
  }

  sendSoap("<u:GetTransportInfoResponse xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">"
           "<CurrentTransportState>" + state + "</CurrentTransportState>"
           "<CurrentTransportStatus>OK</CurrentTransportStatus>"
           "<CurrentSpeed>1</CurrentSpeed>"
           "</u:GetTransportInfoResponse>");
  return;
}

if (action.indexOf("#GETMEDIAINFO") >= 0) {
  const bool hasUri = s_dlnaAvtUri.length() > 0;
  sendSoap("<u:GetMediaInfoResponse xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">"
           "<NrTracks>" + String(hasUri ? 1 : 0) + "</NrTracks>"
           "<MediaDuration></MediaDuration>"
           "<CurrentURI>" + (hasUri ? s_dlnaAvtUri : String("")) + "</CurrentURI>"
           "<CurrentURIMetaData></CurrentURIMetaData>"
           "<NextURI>NOT_IMPLEMENTED</NextURI>"
           "<NextURIMetaData>NOT_IMPLEMENTED</NextURIMetaData>"
           "<PlayMedium>NETWORK</PlayMedium>"
           "<RecordMedium>NONE</RecordMedium>"
           "<WriteStatus>NOT_IMPLEMENTED</WriteStatus>"
           "</u:GetMediaInfoResponse>");
  return;
}

if (action.indexOf("#GETTRANSPORTSETTINGS") >= 0) {
  sendSoap("<u:GetTransportSettingsResponse xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">"
           "<PlayMode>NORMAL</PlayMode>"
           "<RecQualityMode>NOT_IMPLEMENTED</RecQualityMode>"
           "</u:GetTransportSettingsResponse>");
  return;
}

if (action.indexOf("#GETDEVICECAPABILITIES") >= 0) {
  sendSoap("<u:GetDeviceCapabilitiesResponse xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">"
           "<PlayMedia>NETWORK</PlayMedia>"
           "<RecMedia>NOT_IMPLEMENTED</RecMedia>"
           "<RecQualityModes>NOT_IMPLEMENTED</RecQualityModes>"
           "</u:GetDeviceCapabilitiesResponse>");
  return;
}

if (action.indexOf("#GETCURRENTTRANSPORTACTIONS") >= 0) {
  const bool running = player.isRunning();
  uint8_t st = s_dlnaAvtState;
  if (running) st = DLNA_AVT_PLAYING;

  String acts;
  if (st == DLNA_AVT_PLAYING || st == DLNA_AVT_TRANSITIONING) acts = "Stop,Pause,SetAVTransportURI";
  else if (st == DLNA_AVT_PAUSED) acts = "Play,Stop,SetAVTransportURI";
  else if (s_dlnaAvtUri.length()) acts = "Play,Stop,SetAVTransportURI";
  else acts = "SetAVTransportURI";

  sendSoap("<u:GetCurrentTransportActionsResponse xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">"
           "<Actions>" + acts + "</Actions>"
           "</u:GetCurrentTransportActionsResponse>");
  return;
}


// Proxy everything else to tiny_dlna on port 9000.
        WiFiClient client;
        client.setTimeout(2);
        const String selfIp = WiFi.localIP().toString();
        if (!client.connect(selfIp.c_str(), 9000)) {
          sendSoap("<s:Fault><faultcode>s:Server</faultcode><faultstring>UPnPError</faultstring>"
                   "<detail><UPnPError xmlns=\"urn:schemas-upnp-org:control-1-0\">"
                   "<errorCode>501</errorCode><errorDescription>Action Failed</errorDescription>"
                   "</UPnPError></detail></s:Fault>");
          return;
        }

        // Send the proxied HTTP request.
        String req;
        req.reserve(body.length() + 256);
        req += "POST /AVT/control HTTP/1.1\r\n";
        req += "Host: " + selfIp + ":9000\r\n";
        req += "Content-Type: text/xml; charset=\"utf-8\"\r\n";
        if (soapActionHeader.length()) {
          req += "SOAPAction: " + soapActionHeader + "\r\n";
        }
        req += "Content-Length: " + String(body.length()) + "\r\n";
        req += "Connection: close\r\n\r\n";
        req += body;
        client.print(req);

        // Read status line.
        String statusLine = client.readStringUntil('\n');
        statusLine.trim();
        int statusCode = 200;
        if (statusLine.startsWith("HTTP/")) {
          int sp = statusLine.indexOf(' ');
          if (sp > 0) {
            int sp2 = statusLine.indexOf(' ', sp + 1);
            String code = (sp2 > sp) ? statusLine.substring(sp + 1, sp2) : statusLine.substring(sp + 1);
            statusCode = code.toInt();
            if (statusCode <= 0) statusCode = 200;
          }
        }

        // Read headers.
        int contentLen = -1;
        String contentType = "text/xml";
        for (;;) {
          String line = client.readStringUntil('\n');
          line.trim();
          if (line.length() == 0) break;
          String u = line;
          u.toUpperCase();
          if (u.startsWith("CONTENT-LENGTH:")) {
            contentLen = line.substring(String("Content-Length:").length()).toInt();
          } else if (u.startsWith("CONTENT-TYPE:")) {
            contentType = line.substring(String("Content-Type:").length());
            contentType.trim();
          }
        }

        // Read body.
        String respBody;
        if (contentLen >= 0) {
          respBody.reserve(contentLen + 8);
          while (contentLen > 0 && client.connected()) {
            uint8_t buf[256];
            size_t want = (contentLen > (int)sizeof(buf)) ? sizeof(buf) : (size_t)contentLen;
            int n = client.readBytes((char*)buf, want);
            if (n <= 0) break;
            respBody.concat((const char*)buf, (unsigned)n);
            contentLen -= n;
          }
        } else {
          // No length: read until close.
          while (client.connected()) {
            String chunk = client.readString();
            if (!chunk.length()) break;
            respBody += chunk;
          }
        }
        client.stop();

        AsyncWebServerResponse *r = request->beginResponse(statusCode, contentType, respBody);
        r->addHeader("Ext", "");
        r->addHeader("Connection", "close");
        request->send(r);
      });
#endif


  // --------------------------------------------------------
  // 1. SD KÁRTYA LISTÁZÁS
  // --------------------------------------------------------
  webserver.on("/sd/list", HTTP_GET, [](AsyncWebServerRequest *request){
    String path = "/";
    if (request->hasParam("dir")) path = request->getParam("dir")->value();
    if (!path.startsWith("/")) path = "/" + path;

    String json = "[";
    File root = sdman.open(path, "r");
    if (!root) { sdman.start(); root = sdman.open(path, "r"); }

    if (root && root.isDirectory()) {
        File file = root.openNextFile();
        bool first = true;
        while (file) {
            String fileName = String(file.name());
            if (fileName.lastIndexOf('/') >= 0) fileName = fileName.substring(fileName.lastIndexOf('/') + 1);
            if (!fileName.startsWith(".")) { 
                if (!first) json += ",";
                json += "{\"name\":\"" + fileName + "\",\"type\":\"" + String(file.isDirectory() ? "dir" : "file") + "\"}";
                first = false;
            }
            file = root.openNextFile();
        }
        root.close();
    }
    json += "]";
    request->send(200, "application/json", json);
  });

  // --------------------------------------------------------
  // 2. FÁJL FELTÖLTÉS - EXTRA VÉDELEMMEL
  // --------------------------------------------------------
  webserver.on("/edit", HTTP_POST, [](AsyncWebServerRequest *request){
    request->send(200, "text/plain", "OK");
  }, [](AsyncWebServerRequest *request, String filename, size_t index, uint8_t *data, size_t len, bool final){
    if(!index){
      player.sendCommand({PR_STOP, 0}); 
      config.newConfigMode = PM_WEB; 
      vTaskDelay(300); 
      
      log_i("[SD] Feltöltés kezdete: %s\n", filename.c_str());
      sdman.start();

      if(!filename.startsWith("/")) filename = "/" + filename;
      
      if (filename.endsWith("playlistsd.csv")) {
          if (!sdman.exists("/data")) sdman.mkdir("/data");
          filename = "/data/playlistsd.csv";
      }

      request->_tempFile = sdman.open(filename, "w", true);
    }
    
    if(request->_tempFile) request->_tempFile.write(data, len);
    
    if(final){
      if(request->_tempFile) request->_tempFile.close();
      LOGI("[SD] Feltöltés kész.");

      xTaskCreate([](void*){ 
        vTaskDelay(500);
        if (!sdman.exists("/data")) sdman.mkdir("/data");
        sdman.indexSDPlaylist(); 
        vTaskDelete(NULL); 
      }, "sd_idx", 4096, NULL, 1, NULL);
    }
  });

  // --------------------------------------------------------
  // 3. LEJÁTSZÁSI LISTA ÉPÍTÉSE
  // --------------------------------------------------------
  webserver.on("/sd/build", HTTP_GET, [](AsyncWebServerRequest *request){
    player.sendCommand({PR_STOP, 0});
    xTaskCreate([](void*){ 
        vTaskDelay(500); 
        sdman.start();
        if (!sdman.exists("/data")) sdman.mkdir("/data");
        sdman.indexSDPlaylist(); 
        vTaskDelete(NULL); 
    }, "sd_bld", 4096, NULL, 1, NULL);
    request->send(200, "text/plain", "Építés indítva...");
  });

  // --------------------------------------------------------
  // 4. FÁJL TÖRLÉSE (ÚJ!)
  // --------------------------------------------------------
  webserver.on("/sd_delete", HTTP_GET, [](AsyncWebServerRequest *request){
    if(request->hasParam("filename")) {
      String fn = request->getParam("filename")->value();
      
      log_i("[SD] Torles: %s\n", fn.c_str());
      player.sendCommand({PR_STOP, 0}); // Megallitjuk a lejatszot
      vTaskDelay(200);

      if(sdman.remove(fn)) {
         // Torles utan hatterben ujraindexelunk, hogy eltunjon a listabol
         xTaskCreate([](void*){ 
            vTaskDelay(500); 
            sdman.indexSDPlaylist(); 
            vTaskDelete(NULL); 
         }, "sd_del_idx", 3072, NULL, 1, NULL);
         
         request->send(200, "text/plain", "Sikeres torles");
      } else { 
         request->send(500, "text/plain", "Hiba: Nem sikerult torolni!"); 
      }
    } else {
      request->send(400, "text/plain", "Hianyzik a filenev!");
    }
  });

  // --------------------------------------------------------
  // 5. MÓDVÁLTÁS
  // --------------------------------------------------------
  webserver.on("/playlist/sd", HTTP_GET, [](AsyncWebServerRequest *request){
  LOGI("[HTTP] /playlist/sd");

  player.sendCommand({PR_STOP, 0});
  vTaskDelay(200 / portTICK_PERIOD_MS);

  config.newConfigMode = PM_SDCARD;
  LOGI("[HTTP] queue CHANGEMODE -> SD");

  netserver.requestOnChange(CHANGEMODE, 0);
  request->send(200, "text/plain", "OK");
});

  // Visszaváltás Rádióra
  webserver.on("/playlist/web_radio", HTTP_GET, [](AsyncWebServerRequest *request){
  LOGI("[HTTP] /playlist/web_radio");

  // Stop
  player.sendCommand({PR_STOP, 0});
  vTaskDelay(200 / portTICK_PERIOD_MS);

  // Módváltás csak így:
  config.newConfigMode = PM_WEB;
  netserver.requestOnChange(CHANGEMODE, 0);

  request->send(200, "text/plain", "OK");
});

  // --------------------------------------------------------
  // 6. DLNA MODUL (Belső YoRadio funkciók, az eredeti kódod alapján)
  // --------------------------------------------------------
#ifdef USE_DLNA
  extern String g_dlnaControlUrl;

  webserver.on("/dlna/init", HTTP_GET, [](AsyncWebServerRequest *request) {
    if (dlna_isBusy()) {
      request->send(429, "application/json", "{\"queued\":false,\"busy\":true}");
      return;
    }
    config.resumeAfterModeChange = player.isRunning();
    if (config.resumeAfterModeChange) {
      player.sendCommand({PR_STOP, 0});
    }
    DlnaJob j{};
    j.type = DJ_INIT;
    j.reqId = dlna_next_reqId();
    dlna_worker_enqueue(j);
    request->send(202, "application/json", "{\"queued\":true}");
  });

  webserver.on("/dlna/list", HTTP_GET, [](AsyncWebServerRequest *request) {
    if (!request->hasParam("objectId")) {
      request->send(400, "application/json", "{\"ok\":false,\"error\":\"Missing objectId\"}");
      return;
    }
    if (!g_dlnaControlUrl.length()) {
      request->send(503, "application/json", "{\"ok\":false,\"error\":\"DLNA not initialized\"}");
      return;
    }
    String objectId = request->getParam("objectId")->value();
    uint32_t start = request->hasParam("start") ? request->getParam("start")->value().toInt() : 0;
    String json;
    DlnaIndex idx;
    bool ok = idx.listContainer(g_dlnaControlUrl, objectId, json, start);
    if (!ok) {
      request->send(500, "application/json", "{\"ok\":false,\"error\":\"Browse failed\"}");
      return;
    }
    AsyncWebServerResponse *r = request->beginResponse(200, "application/json", json);
    r->addHeader("Cache-Control", "no-store");
    request->send(r);
  });

  webserver.on("/dlna/build", HTTP_GET, [](AsyncWebServerRequest *request) {
    if (!request->hasParam("objectId")) { request->send(400, "text/plain", "Missing objectId"); return; }
    String oid = request->getParam("objectId")->value();
    log_i("[DLNA][HTTP] %s objectId='%s'\n", "/dlna/build", oid.c_str());
    if (dlna_isBusy()) { request->send(429, "application/json", "{\"queued\":false,\"busy\":true}"); return; }

    DlnaJob j{};
    j.type = DJ_BUILD;
    strlcpy(j.objectId, request->getParam("objectId")->value().c_str(), sizeof(j.objectId));
    j.reqId = dlna_next_reqId();
    j.hardLimit = request->hasParam("limit") ? request->getParam("limit")->value().toInt() : 20000;
    dlna_worker_enqueue(j);
    request->send(202, "application/json", "{\"queued\":true}");
  });

  webserver.on("/dlna/append", HTTP_GET, [](AsyncWebServerRequest *request) {
    if (!request->hasParam("objectId")) { request->send(400, "text/plain", "Missing objectId"); return; }
    String oid = request->getParam("objectId")->value();
    log_i("[DLNA][HTTP] %s objectId='%s'\n", "/dlna/append", oid.c_str());
    if (dlna_isBusy()) { request->send(429, "application/json", "{\"queued\":false,\"busy\":true}"); return; }

    DlnaJob j{};
    j.type = DJ_APPEND;
    strlcpy(j.objectId, request->getParam("objectId")->value().c_str(), sizeof(j.objectId));
    j.reqId = dlna_next_reqId();
    j.hardLimit = request->hasParam("limit") ? request->getParam("limit")->value().toInt() : 20000;
    dlna_worker_enqueue(j);
    request->send(202, "application/json", "{\"queued\":true}");
  });

  webserver.on("/dlna/status", HTTP_GET, [](AsyncWebServerRequest *request) {
    static uint32_t s_appliedBuildVer = 0;
    if (!g_dlnaStatus.busy && g_dlnaStatus.ok && g_dlnaStatus.playlistVer != 0 && g_dlnaStatus.playlistVer != s_appliedBuildVer
        && strstr(g_dlnaStatus.msg, "build ok") != nullptr) {
      s_appliedBuildVer = g_dlnaStatus.playlistVer;
      LOGI("[DLNA] Build completed → reset index to 1");
    }

    char buf[256];
    snprintf(
      buf, sizeof(buf), "{\"busy\":%s,\"ok\":%s,\"err\":%d,\"reqId\":%u,\"playlistVer\":%u,\"msg\":\"%s\"}", g_dlnaStatus.busy ? "true" : "false",
      g_dlnaStatus.ok ? "true" : "false", g_dlnaStatus.err, (unsigned)g_dlnaStatus.reqId, (unsigned)g_dlnaStatus.playlistVer, g_dlnaStatus.msg
    );

    AsyncWebServerResponse *r = request->beginResponse(200, "application/json", buf);
    r->addHeader("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
    r->addHeader("Pragma", "no-cache");
    request->send(r);
  });

  webserver.on("/playlist/dlna", HTTP_GET, [](AsyncWebServerRequest *request) {
    bool resume = config.resumeAfterModeChange;
    config.store.playlistSource = PL_SRC_DLNA;
    config.saveValue(&config.store.playlistSource, (uint8_t)PL_SRC_DLNA);

  #ifdef USE_SD
    if (config.getMode() == PM_SDCARD) config.changeMode(PM_WEB);
  #endif

    if (config.getMode() != PM_WEB) {
      config.changeMode(PM_WEB);
    } else {
      config.loadStation(config.store.lastDlnaStation);
      if (player_on_station_change) player_on_station_change();
      netserver.requestOnChange(GETINDEX, 0);
    }

    if (resume) {
      LOGI("[DLNA] Resume playback with DLNA playlist");
      player.sendCommand({PR_PLAY, (int)config.store.lastDlnaStation});
    }
    config.resumeAfterModeChange = false;
    netserver.requestOnChange(GETINDEX, 0);
    netserver.requestOnChange(GETPLAYERMODE, 0);
    request->send(200, "text/plain", "OK");
  });

#endif // USE_DLNA

  // --------------------------------------------------------
  // 7b. SOAP DLNA Browser (SoapESP32) – opcionális
  // --------------------------------------------------------
#ifdef USE_SOAP_DLNA
  soapdlna::begin();

  // Start background scan for DLNA MediaServers
  webserver.on("/soapdlna/scan", HTTP_GET, [](AsyncWebServerRequest *request) {
    uint8_t sec = request->hasParam("sec") ? (uint8_t)request->getParam("sec")->value().toInt() : 30;
    bool ok = soapdlna::startScan(sec);
    request->send(ok ? 202 : 429, "application/json", ok ? "{\"queued\":true}" : "{\"queued\":false,\"busy\":true}");
  });

  webserver.on("/soapdlna/status", HTTP_GET, [](AsyncWebServerRequest *request) {
    String json = "{\"scanning\":" + String(soapdlna::isScanning() ? "true" : "false") +
                  ",\"servers\":" + String(soapdlna::serverCount()) +
                  ",\"lastScanMs\":" + String(soapdlna::lastScanMs()) + "}";
    request->send(200, "application/json", json);
  });

  webserver.on("/soapdlna/servers", HTTP_GET, [](AsyncWebServerRequest *request) {
    String json;
    soapdlna::serversToJson(json);
    AsyncWebServerResponse *r = request->beginResponse(200, "application/json", json);
    r->addHeader("Cache-Control", "no-store");
    request->send(r);
  });

  webserver.on("/soapdlna/browse", HTTP_GET, [](AsyncWebServerRequest *request) {
    if (!request->hasParam("sid") || !request->hasParam("objectId")) {
      request->send(400, "application/json", "{\"ok\":false,\"error\":\"Missing sid/objectId\"}");
      return;
    }
    uint16_t sid = (uint16_t)request->getParam("sid")->value().toInt();
    String oid = request->getParam("objectId")->value();
    uint32_t start = request->hasParam("start") ? (uint32_t)request->getParam("start")->value().toInt() : 0;
    String json;
    bool ok = soapdlna::browseToJson(sid, oid, start, json);
    request->send(ok ? 200 : 500, "application/json", json);
  });

  // Quick play helper (URL → yoRadio player)
  webserver.on("/soapdlna/play", HTTP_GET, [](AsyncWebServerRequest *request) {
    if (!request->hasParam("url")) {
      request->send(400, "application/json", "{\"ok\":false,\"error\":\"Missing url\"}");
      return;
    }
    String url = request->getParam("url")->value();
    url.trim();

    // Optional: track/title coming from the SOAP DLNA browser (web UI)
    String title;
    if (request->hasParam("title")) {
      title = request->getParam("title")->value();
      title.trim();
      // Avoid very long UI strings in player buffers
      if (title.length() > 96) title = title.substring(0, 96);
    }
    // Biztonság: csak valós http(s) URL-t fogadunk el (különben DNS-re megy és megáll)
    if (!(url.startsWith("http://") || url.startsWith("https://"))) {
      request->send(400, "application/json", "{\"ok\":false,\"error\":\"Invalid URL\"}");
      return;
    }

#ifdef USE_DLNA
    // DLNA lejátszás → WEB mód + DLNA playlist (hogy TFT/Web is frissüljön)
    if (config.getMode() != PM_WEB) {
      config.changeMode(PM_WEB);
    }
    config.saveValue(&config.store.playlistSource, (uint8_t)PL_SRC_DLNA, true, true);
    // UI frissítés (web + TFT)
    netserver.requestOnChange(GETINDEX, 0);
    netserver.requestOnChange(GETPLAYERMODE, 0);
    display.putRequest(DRAWPLAYLIST);
#endif

    // If title is known, pass it so TFT/Web can show something meaningful.
    // Fallback remains "DLNA".
    if (title.length()) {
      player.playUrl(url.c_str(), title.c_str());
    } else {
      player.playUrl(url.c_str(), "DLNA");
    }
    request->send(200, "application/json", String("{\"ok\":true,\"url\":\"") + url + "\"}");
  });

  // --------------------------------------------------------
  // SOAP DLNA Browser → build DLNA playlist (playlist_dlna.csv)
  // Body format: TSV lines: <title>\t<url>\t0\n
  // Query params:
  //  - start: 1-based index to start from (default 1)
  //  - autoplay: 0/1 (default 1)
  // Notes:
  //  - We write the body chunk-by-chunk to SPIFFS to avoid large RAM allocations.
  //  - After save, we re-index DLNA playlist and optionally start playback.
  webserver.on(
    "/soapdlna/savepl", HTTP_POST,
    [](AsyncWebServerRequest *request) {
      // Final response is sent from onBody when the last chunk arrives.
      // If we ever get here without body, return error.
      if (request->contentLength() == 0) {
        request->send(400, "application/json", "{\"ok\":false,\"error\":\"Empty body\"}");
      }
    },
    nullptr,
    [](AsyncWebServerRequest *request, uint8_t *data, size_t len, size_t index, size_t total) {
      // Open output file on first chunk
      if (index == 0) {
        if (request->_tempFile) {
          request->_tempFile.close();
        }
        request->_tempFile = SPIFFS.open(PLAYLIST_DLNA_PATH, "w");
        if (!request->_tempFile) {
          request->send(500, "application/json", "{\"ok\":false,\"error\":\"Cannot open DLNA playlist\"}");
          return;
        }
      }

      // Write chunk
      if (request->_tempFile) {
        request->_tempFile.write(data, len);
      }

      // Last chunk → finalize
      if (index + len == total) {
        if (request->_tempFile) {
          request->_tempFile.close();
        }

        // Defaults
        uint16_t start = 1;
        bool autoplay = true;
        if (request->hasParam("start")) {
          start = (uint16_t)request->getParam("start")->value().toInt();
          if (start == 0) start = 1;
        }
        if (request->hasParam("autoplay")) {
          autoplay = request->getParam("autoplay")->value().toInt() != 0;
        }

#ifdef USE_DLNA
        // Switch to DLNA playlist mode (WEB + DLNA source)
        if (config.getMode() != PM_WEB) {
          config.changeMode(PM_WEB);
        }
        config.store.playlistSource = PL_SRC_DLNA;
        config.saveValue(&config.store.playlistSource, (uint8_t)PL_SRC_DLNA, true, true);
        config.initDLNAPlaylist();

        // Clamp start to playlist length
        uint16_t plLen = config.playlistLength();
        if (plLen == 0) {
          netserver.requestOnChange(GETINDEX, 0);
          netserver.requestOnChange(GETPLAYERMODE, 0);
          request->send(200, "application/json", "{\"ok\":true,\"saved\":true,\"count\":0}");
          return;
        }
        if (start > plLen) start = 1;

        // Persist last DLNA station and load it (updates station buffers)
        config.lastStation(start);
        config.loadStation(start);
        if (player_on_station_change) player_on_station_change();

        // UI refresh
        netserver.requestOnChange(GETINDEX, 0);
        netserver.requestOnChange(GETPLAYERMODE, 0);
        display.putRequest(DRAWPLAYLIST);

        if (autoplay) {
          player.sendCommand({PR_PLAY, (int)start});
        }
#endif

        // Respond
        String json = String("{\"ok\":true,\"saved\":true,\"start\":") + start + ",\"autoplay\":" + (autoplay ? "true" : "false") + "}";
        AsyncWebServerResponse *r = request->beginResponse(200, "application/json", json);
        r->addHeader("Cache-Control", "no-store");
        request->send(r);
      }
    }
  );

  webserver.on("/playlist/web", HTTP_GET, [](AsyncWebServerRequest *request) {
    bool resume = config.resumeAfterModeChange;
    config.resumeAfterModeChange = player.isRunning();
    log_i("[MODE] WEB enter, resume=%d\n", config.resumeAfterModeChange);

    config.store.playlistSource = PL_SRC_WEB;
    config.saveValue(&config.store.playlistSource, (uint8_t)PL_SRC_WEB);

    if (config.getMode() != PM_WEB) {
      config.changeMode(PM_WEB);
    } else {
      config.loadStation(config.lastStation());
      if (player_on_station_change) player_on_station_change();
      netserver.requestOnChange(GETINDEX, 0);
    }

    if (resume) {
      LOGI("[DLNA] Resume playback after browser exit");
      player.sendCommand({PR_PLAY, config.lastStation()});
    }
    config.resumeAfterModeChange = false;
    netserver.requestOnChange(GETINDEX, 0);
    netserver.requestOnChange(GETPLAYERMODE, 0);
    request->send(200, "text/plain", "OK");
  });
#endif

  // --------------------------------------------------------
  // 8. RENDSZER LEZÁRÁS ÉS INDÍTÁS (A HELYES SORREND!)
  // --------------------------------------------------------
  
  // Ezt betettük ide alulra, hogy a fentieket ne nyomja el!
  webserver.serveStatic("/", SPIFFS, "/www/");
  
  webserver.onNotFound(handleNotFound);
  webserver.onFileUpload(handleUpload);
  
  websocket.onEvent(onWsEvent);
  webserver.addHandler(&websocket);

  // CSAK ITT, minden után indítjuk el a szervert
  webserver.begin();

#ifdef USE_DLNA  //DLNA mod
  dlna_worker_start();
#endif

  if (!quiet) {
    LOGI("done");
  }
  return true;
}
/////idáig/////////////

size_t NetServer::chunkedHtmlPageCallback(uint8_t *buffer, size_t maxLen, size_t index) {
  File requiredfile;

  // Megnézzük, hogy SD-s playlistet kérnek-e vagy SPIFFS-est
  bool sdpl = strcmp(netserver.chunkedPathBuffer, PLAYLIST_SD_PATH) == 0;

  if (sdpl) {
    requiredfile = config.SDPLFS()->open(netserver.chunkedPathBuffer, "r");
  } else {
    requiredfile = SPIFFS.open(netserver.chunkedPathBuffer, "r");
  }

  // *** FONTOS FIX ***
  // Ha a fájlt NEM sikerült megnyitni, akkor eddig
  // egyszerűen return 0; volt -> display.lock() bent ragadt!
  if (!requiredfile) {
    LOGE("[chunkedHtmlPageCallback] open('%s') FAILED (mode=%d, plSource=%d) -> display.unlock()",
         netserver.chunkedPathBuffer,
         (int)config.getMode(),
#ifdef USE_DLNA
         (int)config.store.playlistSource
#else
         0
#endif
    );
#ifndef NETSERVER_LOOP1
    // Mindig engedjük el a lock-ot, különben a TFT többé nem rajzol
    display.unlock();
#endif
    return 0;
  }

  size_t filesize = requiredfile.size();

  // Üres fájl (0B): nem hiba, csak nincs mit kiszolgálni.
  // (DLNA playlistnél tipikusan ez történik, ha nincs DLNA/üres az index.)
  if (filesize == 0) {
    requiredfile.close();
#ifndef NETSERVER_LOOP1
    display.unlock();
#endif
    return 0;
  }

  // Biztonság: ha valamiért az index nagyobb, mint a file méret,
  // akkor ne olvassunk, csak zárjunk és unlockoljunk.
  if (index >= filesize) {
    LOGW("[chunkedHtmlPageCallback] index(%u) >= filesize(%u) for '%s' -> unlock + return 0",
         (unsigned)index, (unsigned)filesize, netserver.chunkedPathBuffer);
    requiredfile.close();
#ifndef NETSERVER_LOOP1
    display.unlock();
#endif
    return 0;
  }

  size_t needread = filesize - index;

  // Ha nincs már mit olvasni (EOF),
  // zárjuk a fájlt és engedjük el a display lockot.
  if (!needread) {
    requiredfile.close();
#ifndef NETSERVER_LOOP1
    display.unlock();
#endif
    return 0;
  }

#ifdef MAX_PL_READ_BYTES
  if (maxLen > MAX_PL_READ_BYTES) {
    maxLen = MAX_PL_READ_BYTES;
  }
#endif

  size_t canread = (needread > maxLen) ? maxLen : needread;

  DBGVB("[%s] seek to %u in %s and read %u bytes with maxLen=%u",
        __func__,
        (unsigned)index,
        netserver.chunkedPathBuffer,
        (unsigned)canread,
        (unsigned)maxLen);

  requiredfile.seek(index, SeekSet);
  requiredfile.read(buffer, canread);

  requiredfile.close();

  // Itt MÉG NEM unlockolunk, mert a chunked válasz több hívás alatt jön össze
  // A végén (EOF esetén) a fenti needread==0 ág már unlockolta.

  return canread;
}

void NetServer::chunkedHtmlPage(const String &contentType, AsyncWebServerRequest *request, const char *path) {
  memset(chunkedPathBuffer, 0, sizeof(chunkedPathBuffer));
  strlcpy(chunkedPathBuffer, path, sizeof(chunkedPathBuffer) - 1);
  AsyncWebServerResponse *response;
#ifndef NETSERVER_LOOP1
  display.lock();
#endif
  response = request->beginChunkedResponse(contentType, chunkedHtmlPageCallback);
  // Playlist/Index legyen mindig friss, a statikus web UI maradhat cache-elt
bool nocache =
    (strcmp(path, PLAYLIST_PATH) == 0) ||
    (strcmp(path, PLAYLIST_SD_PATH) == 0) ||
#ifdef USE_DLNA
    (strcmp(path, PLAYLIST_DLNA_PATH) == 0) ||
#endif
    (strcmp(path, INDEX_PATH) == 0) ||
    (strcmp(path, INDEX_SD_PATH) == 0) ||
#ifdef USE_DLNA
    (strcmp(path, INDEX_DLNA_PATH) == 0) ||
#endif
    false;

if (nocache) {
  response->addHeader("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
  response->addHeader("Pragma", "no-cache");
} else {
  response->addHeader("Cache-Control", "max-age=31536000");
}
  request->send(response);
}

#ifndef DSP_NOT_FLIPPED
  #define DSP_CAN_FLIPPED true
#else
  #define DSP_CAN_FLIPPED false
#endif
#if !defined(HIDE_WEATHER) && (!defined(DUMMYDISPLAY) && !defined(USE_NEXTION))
  #define SHOW_WEATHER true
#else
  #define SHOW_WEATHER false
#endif

const char *getFormat(BitrateFormat _format) {
  switch (_format) {
    case BF_MP3:  return "MP3";
    case BF_AAC:  return "AAC";
    case BF_FLAC: return "FLC";
    case BF_OGG:  return "OGG";
    case BF_WAV:  return "WAV";
    case BF_VOR:  return "VOR";
    case BF_OPU:  return "OPU";
    default:      return "bitrate";
  }
}

void NetServer::processQueue() {
  if (nsQueue == NULL) return;

  nsRequestParams_t request;
  int guard = 0;

  while (xQueueReceive(nsQueue, &request, 0) == pdTRUE) {
    guard++;

    uint8_t clientId = request.clientId;
    wsBuf[0] = '\0';

    switch (request.type) {
      case PLAYLIST: getPlaylist(clientId); break;
      case PLAYLISTSAVED:
      {
#ifdef USE_SD
        if (config.getMode() == PM_SDCARD) {
          //config.indexSDPlaylist();
          config.initSDPlaylist();
        }
#endif
#ifdef USE_DLNA  //DLNA mod
        if (config.getMode() == PM_WEB && config.store.playlistSource == PL_SRC_DLNA) {
          config.indexDLNAPlaylist();
          config.initDLNAPlaylist();
          break;
        }
#endif
        if (config.getMode() == PM_WEB) {
          config.indexPlaylist();
          config.initPlaylist();
        }
        getPlaylist(clientId);
        break;
      }
      case GETACTIVE:
      {
        bool dbgact = false, nxtn = false;
        //String act = F("\"group_wifi\",");
        nsBuf[0] = '\0';
        APPEND_GROUP("group_wifi");
        if (network.status == CONNECTED) {
          //act += F("\"group_system\",");
          APPEND_GROUP("group_system");
          if (BRIGHTNESS_PIN != 255 || DSP_CAN_FLIPPED || DSP_MODEL == DSP_NOKIA5110 || dbgact) {
            APPEND_GROUP("group_display");
          }
#ifdef USE_NEXTION
          APPEND_GROUP("group_nextion");
          if (!SHOW_WEATHER || dbgact) {
            APPEND_GROUP("group_weather");
          }
          nxtn = true;
#endif
#if defined(LCD_I2C) || defined(DSP_OLED)
          APPEND_GROUP("group_oled");
#endif
#if !defined(HIDE_VU) && !defined(DUMMYDISPLAY)
          APPEND_GROUP("group_vu");
#endif
          if (BRIGHTNESS_PIN != 255 || nxtn || dbgact) {
            APPEND_GROUP("group_brightness");
          }
          if (DSP_CAN_FLIPPED || dbgact) {
            APPEND_GROUP("group_tft");
          }
          if (TS_MODEL != TS_MODEL_UNDEFINED || dbgact) {
            APPEND_GROUP("group_touch");
          }
          if (DSP_MODEL == DSP_NOKIA5110) {
            APPEND_GROUP("group_nokia");
          }
          APPEND_GROUP("group_timezone");
          if (SHOW_WEATHER || dbgact) {
            APPEND_GROUP("group_weather");
          }
          APPEND_GROUP("group_controls");
          if (ENC_BTNL != 255 || ENC2_BTNL != 255 || dbgact) {
            APPEND_GROUP("group_encoder");
          }
          if (IR_PIN != 255 || dbgact) {
            APPEND_GROUP("group_ir");
          }
          if (!psramInit()) {
            APPEND_GROUP("group_buffer");
          }
#if RTCSUPPORTED
          APPEND_GROUP("group_rtc");
#else
          APPEND_GROUP("group_wortc");
#endif
        }
        size_t len = strlen(nsBuf);
        if (len > 0 && nsBuf[len - 1] == ',') {
          nsBuf[len - 1] = '\0';
        }

        snprintf(wsBuf, sizeof(wsBuf), "{\"act\":[%s]}", nsBuf);
        break;
      }
      case GETINDEX:
      {
        requestOnChange(STATION, clientId);
        requestOnChange(TITLE, clientId);
        requestOnChange(VOLUME, clientId);
        requestOnChange(EQUALIZER, clientId);
        requestOnChange(BALANCE, clientId);
        requestOnChange(BITRATE, clientId);
        requestOnChange(MODE, clientId);
        requestOnChange(SDINIT, clientId);
        requestOnChange(GETPLAYERMODE, clientId);
        if (config.getMode() == PM_SDCARD) {
          requestOnChange(SDPOS, clientId);
          requestOnChange(SDLEN, clientId);
          requestOnChange(SDSNUFFLE, clientId);
        }
        break;
      }

      case GETSYSTEM:
        sprintf(
          wsBuf,
          "{\"sst\":%d,\"aif\":%d,\"vu\":%d,\"softr\":%d,\"vut\":%d,\"mdns\":\"%s\",\"ipaddr\":\"%s\", \"abuff\": %d, \"telnet\": %d, \"watchdog\": %d, "
          "\"nameday\": %d, \"ampctl\": %d, \"spkctl\": %d, \"spkudly\": %u }",  // "nameday"
          config.store.smartstart != 2, config.store.audioinfo, config.store.vumeter, config.store.softapdelay, config.vuRefLevel, config.store.mdnsname,
          config.ipToStr(WiFi.localIP()), config.store.abuff, config.store.telnet, config.store.watchdog, config.store.nameday,
          config.store.ampCtlEnabled ? 1 : 0, config.store.spkCtlEnabled ? 1 : 0, (unsigned)config.store.spkUnmuteDelayMs
        );
        log_i("netserver-> config.store.nameday %d \n", config.store.nameday);
        break;
      case GETSCREEN:
        sprintf(
          wsBuf,
          "{\"flip\":%d,\"inv\":%d,\"nump\":%d,\"tsf\":%d,\"tsd\":%d,\"dspon\":%d,\"br\":%d,\"con\":%d,\"scre\":%d,\"scrt\":%d,\"scrb\":%d,\"scrpe\":%d,"
          "\"scrpt\":%d,\"scrpb\":%d}",
          config.store.flipscreen, config.store.invertdisplay, config.store.numplaylist, config.store.fliptouch, config.store.dbgtouch, config.store.dspon,
          config.store.brightness, config.store.contrast, config.store.screensaverEnabled, config.store.screensaverTimeout, config.store.screensaverBlank,
          config.store.screensaverPlayingEnabled, config.store.screensaverPlayingTimeout, config.store.screensaverPlayingBlank
        );
        break;
      case GETTIMEZONE:
        sprintf(
          wsBuf, "{\"tzh\":%d,\"tzm\":%d,\"sntp1\":\"%s\",\"sntp2\":\"%s\", \"timeint\":%d,\"timeintrtc\":%d}", config.store.tzHour, config.store.tzMin,
          config.store.sntp1, config.store.sntp2, config.store.timeSyncInterval, config.store.timeSyncIntervalRTC
        );
        break;
      case GETWEATHER:
        sprintf(
          wsBuf, "{\"wen\":%d,\"wlat\":\"%s\",\"wlon\":\"%s\",\"wkey\":\"%s\",\"wint\":%d}", config.store.showweather, config.store.weatherlat,
          config.store.weatherlon, config.store.weatherkey, config.store.weatherSyncInterval
        );
        break;
      case GETCONTROLS:
        sprintf(
          wsBuf, "{\"vols\":%d,\"enca\":%d,\"irtl\":%d,\"skipup\":%d}", config.store.volsteps, config.store.encacc, config.store.irtlp,
          config.store.skipPlaylistUpDown
        );
        break;
      case DSPON: sprintf(wsBuf, "{\"dspontrue\":%d}", 1); break;
      case STATION:
        requestOnChange(STATIONNAME, clientId);
        requestOnChange(ITEM, clientId);
        break;
      case STATIONNAME: sprintf(wsBuf, "{\"payload\":[{\"id\":\"nameset\", \"value\": \"%s\"}]}", config.station.name); break;
      case ITEM:        sprintf(wsBuf, "{\"current\": %d}", config.lastStation()); break;
      case TITLE:
        sprintf(wsBuf, "{\"payload\":[{\"id\":\"meta\", \"value\": \"%s\"}]}", config.station.title);
        telnet.printf("##CLI.META#: %s\r\n> ", config.station.title);
        break;
      case VOLUME:
        sprintf(wsBuf, "{\"payload\":[{\"id\":\"volume\", \"value\": %d}]}", config.store.volume);
        telnet.printf("##CLI.VOL#: %d\r\n", config.store.volume);
        break;
      case NRSSI:
        sprintf(
          wsBuf, "{\"payload\":[{\"id\":\"rssi\", \"value\": %d}, {\"id\":\"heap\", \"value\": %d}]}", rssi,
          (player.isRunning() && config.store.audioinfo) ? (int)(100 * player.inBufferFilled() / playerBufMax) : 0
        ); /*rssi = 255;*/
        break;
      case SDPOS:
        //"módosítás" Itt adja át az SD kártya pozícióját a csúszkához és a számlálóhoz.
        sprintf(
          wsBuf, "{\"sdpos\": %lu,\"sdtpos\": %lu,\"sdtend\": %lu}", player.getAudioFilePosition(), player.getAudioCurrentTime(), player.getAudioFileDuration()
        );
        //Serial.printf("netserver.cpp-->wsBuf: %s \n", wsBuf);
        break;
      // Az mp3 fájlon belül a zenekezdeti byte és utolsó byte pozíciója.
      case SDLEN:
        sprintf(wsBuf, "{\"sdmin\": %lu,\"sdmax\": %lu}", player.sd_min, player.sd_max);  // Az audionanlersben kap értéket.
        //Serial.printf("netserver.cpp-->wsBuf: %s \n", wsBuf);
        break;
      case SDSNUFFLE: sprintf(wsBuf, "{\"snuffle\": %d}", config.store.sdsnuffle); break;
      case BITRATE:
        sprintf(
          wsBuf, "{\"payload\":[{\"id\":\"bitrate\", \"value\": %d}, {\"id\":\"fmt\", \"value\": \"%s\"}]}", config.station.bitrate, getFormat(config.configFmt)
        );
        break;
      case MODE:
        sprintf(wsBuf, "{\"payload\":[{\"id\":\"playerwrap\", \"value\": \"%s\"}]}", player.status() == PLAYING ? "playing" : "stopped");
        telnet.info();
        break;
      case EQUALIZER:
        sprintf(
          wsBuf, "{\"payload\":[{\"id\":\"bass\", \"value\": %d}, {\"id\": \"middle\", \"value\": %d}, {\"id\": \"trebble\", \"value\": %d}]}",
          config.store.bass, config.store.middle, config.store.trebble
        );
        break;
      case BALANCE: sprintf(wsBuf, "{\"payload\":[{\"id\": \"balance\", \"value\": %d}]}", config.store.balance); break;
      case SDINIT:  sprintf(wsBuf, "{\"sdinit\": %d}", SDC_CS != 255); break;
    case GETPLAYERMODE:
      {
#ifdef USE_DLNA
        if (config.getMode() == PM_WEB && config.store.playlistSource == PL_SRC_DLNA) {
          sprintf(wsBuf, "{\"playermode\": \"modedlna\"}");
        } else
#endif
          if (config.getMode() == PM_SDCARD) {
          sprintf(wsBuf, "{\"playermode\": \"modesd\"}");
        } else {
          sprintf(wsBuf, "{\"playermode\": \"modeweb\"}");
        }
        break;
      }
	  
case CHANGEMODE:
{
	
  bool resume = player.isRunning();     // megjegyezzük, ment-e
  player.sendCommand({PR_STOP, 0});     // biztos stop, mielőtt bármit initelünk
  vTaskDelay(pdMS_TO_TICKS(50));
  // ===========================
  // FIX/DEBUG: Mode switching trace
  // ===========================
  const int oldMode = (int)config.getMode();
  const int newModeReq = (int)config.newConfigMode;

  LOGI("CHANGEMODE enter: oldMode=%d newConfigMode=%d", oldMode, newModeReq);

  // 1) tényleges módváltás
  config.changeMode(config.newConfigMode);

  const int newModeNow = (int)config.getMode();
  LOGI("CHANGEMODE after changeMode(): newMode=%d", newModeNow);

  // 2) Playlist újrainit mód szerint
  if (config.getMode() == PM_SDCARD) {

    LOGI("MODE=SDCARD: init SD playlist start");

#ifdef USE_SD
    // FIX: SD busz hibák miatt itt külön logolunk
    LOGI("[SD] sdman.start()...");
    bool ok = sdman.start();
    LOGI("[SD] sdman.start() -> %d", (int)ok);

    // Ha start() false, ne menjünk tovább, különben később összeomolhat / rossz lista
    if (!ok) {
      LOGE("[SD] sdman.start FAILED -> leaving CHANGEMODE with SD init aborted");
      // UI/TFT frissítés még így is, hogy lássuk a módot
      //display.putRequest(NEWMODE, config.getMode());
      //display.putRequest(DRAWPLAYLIST);
      return;
    }

    LOGI("[SD] indexSDPlaylist()...");
    sdman.indexSDPlaylist();
    LOGI("[SD] indexSDPlaylist done");

    LOGI("[SD] initSDPlaylist()...");
    config.initSDPlaylist();
    LOGI("[SD] initSDPlaylist done");
	LOGI("[SD] First station after SD init: name='%s'",
     config.station.name);
#else
    // DEBUG: ha ezt látod, akkor nincs USE_SD build flag -> SD kód nem fordul bele
    LOGW("MODE=SDCARD but USE_SD is NOT defined -> SD init skipped!");
#endif

  } else { // PM_WEB

    LOGI("MODE=WEB: init WEB/DLNA playlist start");

#ifdef USE_DLNA
    if (config.store.playlistSource == PL_SRC_DLNA) {
      LOGI("[WEB] playlistSource=DLNA -> indexDLNAPlaylist/initDLNAPlaylist");
      config.indexDLNAPlaylist();
      config.initDLNAPlaylist();
      LOGI("[WEB] DLNA init done");
    } else
#endif
    {
      LOGI("[WEB] playlistSource=WEB -> indexPlaylist/initPlaylist");
      config.indexPlaylist();
      config.initPlaylist();
      LOGI("[WEB] WEB init done");
	  LOGI("[WEB] First station after WEB init: name='%s'",
     config.station.name);
    }
  }

  // 3) Web UI frissítés (mindig)
  LOGI("WEB UI refresh: getPlaylist + GETINDEX + GETPLAYERMODE");
  getPlaylist(0);
  requestOnChange(GETINDEX, 0);
  requestOnChange(GETPLAYERMODE, 0);

  // 4) TFT refresh – egyszer, tisztán
  LOGI("TFT refresh: NEWMODE(%d) + DRAWPLAYLIST", (int)config.getMode());
  display.putRequest(NEWMODE, config.getMode());

  // válts lista kijelölést
  if (config.getMode() == PM_SDCARD) {
    display.currentPlItem = 0;
    LOGI("TFT select: currentPlItem=0 (SD)");
  } else {
    display.currentPlItem = config.lastStation();
    LOGI("TFT select: currentPlItem=%d (WEB lastStation)", (int)display.currentPlItem);
  }

  // csak egyszer rajzoljuk újra
  display.putRequest(DRAWPLAYLIST);
  requestOnChange(PLAYLIST, 0);   // websocket felé jelzi, hogy playlist változott
  if (resume) {
  if (config.getMode() == PM_SDCARD) {
    player.sendCommand({PR_PLAY, 0});                 // SD-n az elsőt
  } else {
    player.sendCommand({PR_PLAY, (int)config.lastStation()});  // WEB-en az utolsót
  }
}

  LOGI("CHANGEMODE exit OK");
  return;
}
/////////////changemod finish

      default: break;
    }
	
    if (strlen(wsBuf) > 0) {
      if (clientId == 0) websocket.textAll(wsBuf);
      else websocket.text(clientId, wsBuf);
#ifdef MQTT_ROOT_TOPIC
      if (clientId == 0 && (request.type == STATION || request.type == ITEM || request.type == TITLE || request.type == MODE)) mqttPublishStatus();
      if (clientId == 0 && request.type == VOLUME) mqttPublishVolume();
#endif
    }

    if (guard > 20) break;  // debug guard
  }
}

void NetServer::loop() {

  // --- FIX: A queue-t MINDIG dolgozzuk fel, különben SDREADY állapotban sosem fut le CHANGEMODE ---
  // (Ez okozza, hogy nem látsz Serial logot és nem vált módot.)
  processQueue();
  websocket.cleanupClients();

  if (network.status == SDREADY) {
    // Debug: lásd, hogy ide beakad-e
    LOGI("[NET][W] loop(): network.status==SDREADY -> skip rest, but queue processed!");
    return;
  }

  if (shouldReboot) {
    LOGI("Rebooting...");
    delay(100);
    ESP.restart();
  }

  switch (importRequest) {
    case IMPL:
      importPlaylist();
      importRequest = IMDONE;
      break;
    case IMWIFI:
      config.saveWifi();
      importRequest = IMDONE;
      break;
    default: break;
  }
}

#if IR_PIN != 255
void NetServer::irToWs(const char *protocol, uint64_t irvalue) {
  wsBuf[0] = '\0';
  sprintf(wsBuf, "{\"ircode\": %llu, \"protocol\": \"%s\"}", irvalue, protocol);
  websocket.textAll(wsBuf);
}
void NetServer::irValsToWs() {
  if (!irRecordEnable) {
    return;
  }
  wsBuf[0] = '\0';
  sprintf(
    wsBuf, "{\"irvals\": [%llu, %llu, %llu]}", config.ircodes.irVals[config.irindex][0], config.ircodes.irVals[config.irindex][1],
    config.ircodes.irVals[config.irindex][2]
  );
  websocket.textAll(wsBuf);
}
#endif

void NetServer::onWsMessage(void *arg, uint8_t *data, size_t len, uint8_t clientId) {
  AwsFrameInfo *info = (AwsFrameInfo *)arg;
  if (info->final && info->index == 0 && info->len == len && info->opcode == WS_TEXT) {
    data[len] = 0;
    if (config.parseWsCommand((const char *)data, _wscmd, _wsval, 65)) {
      if (strcmp(_wscmd, "ping") == 0) {
        websocket.text(clientId, "{\"pong\": 1}");
        return;
      }
      // Tone settings (trebble/middle/bass)
      if (strcmp(_wscmd, "trebble") == 0) {
        int8_t valb = atoi(_wsval);
        config.setTone(config.store.bass, config.store.middle, valb);
        return;
      }
      if (strcmp(_wscmd, "middle") == 0) {
        int8_t valb = atoi(_wsval);
        config.setTone(config.store.bass, valb, config.store.trebble);
        return;
      }
      if (strcmp(_wscmd, "bass") == 0) {
        int8_t valb = atoi(_wsval);
        config.setTone(valb, config.store.middle, config.store.trebble);
        return;
      }
      if (strcmp(_wscmd, "submitplaylistdone") == 0) {
#ifdef MQTT_ROOT_TOPIC
        //mqttplaylistticker.attach(5, mqttplaylistSend);
        timekeeper.waitAndDo(5, mqttplaylistSend);
#endif
        if (player.isRunning()) {
          player.sendCommand({PR_PLAY, -config.lastStation()});
        }
        return;
      }

#ifdef USE_DLNA  //DLNA mod
      // ===== WEB playlist aktiválás =====
      if (strcmp(_wscmd, "playlist") == 0 && strcmp(_wsval, "web") == 0) {

        LOGI("[WEB] Switch to WEB playlist");

        config.store.playlistSource = PL_SRC_WEB;
        config.saveValue(&config.store.playlistSource, (uint8_t)PL_SRC_WEB);

        config.indexPlaylist();
        config.initPlaylist();

        netserver.requestOnChange(GETINDEX, 0);
        netserver.requestOnChange(GETPLAYERMODE, 0);

        return;
      }
      // ===== DLNA playlist aktiválás =====
      if (strcmp(_wscmd, "playlist") == 0 && strcmp(_wsval, "dlna") == 0) {

        LOGI("[WEB] Switch to DLNA playlist");

        config.store.playlistSource = PL_SRC_DLNA;
        config.saveValue(&config.store.playlistSource, (uint8_t)PL_SRC_DLNA);

        config.indexDLNAPlaylist();
        config.initDLNAPlaylist();

        netserver.requestOnChange(GETINDEX, 0);
        netserver.requestOnChange(GETPLAYERMODE, 0);

        return;
      }
#endif

      if (cmd.exec(_wscmd, _wsval, clientId)) {
        return;
      }
    }
  }
}

void NetServer::getPlaylist(uint8_t clientId) {

  const char* plPath = PLAYLIST_PATH;  // alap: WEB rádió

#ifdef USE_SD
  if (config.getMode() == PM_SDCARD) {
    plPath = PLAYLIST_SD_PATH;
  }
#endif

#ifdef USE_DLNA
  if (config.getMode() == PM_WEB &&
      config.store.playlistSource == PL_SRC_DLNA) {
    plPath = PLAYLIST_DLNA_PATH;
  }
#endif

  snprintf(
    nsBuf,
    sizeof(nsBuf),
    "{\"file\": \"http://%s%s?v=%lu\"}",
    config.ipToStr(WiFi.localIP()),
    plPath,
    (unsigned long)millis()
  );

  if (clientId == 0)
    websocket.textAll(nsBuf);
  else
    websocket.text(clientId, nsBuf);
}

void NetServer::notify(const char* msg, uint8_t clientId) {
  if (!msg) return;
  // Small JSON string escaper for quotes/backslashes/newlines.
  String s(msg);
  s.replace("\\", "\\\\");
  s.replace("\"", "\\\"");
  s.replace("\r", " ");
  s.replace("\n", " ");
  wsBuf[0] = '\0';
  snprintf(wsBuf, sizeof(wsBuf), "{\"notice\":\"%s\"}", s.c_str());
  if (clientId == 0) websocket.textAll(wsBuf);
  else websocket.text(clientId, wsBuf);
}

int NetServer::_readPlaylistLine(File &file, char *line, size_t size) {
  int bytesRead = file.readBytesUntil('\n', line, size);
  if (bytesRead > 0) {
    line[bytesRead] = 0;
    if (line[bytesRead - 1] == '\r') {
      line[bytesRead - 1] = 0;
    }
  }
  return bytesRead;
}

bool NetServer::importPlaylist() {
  if (config.getMode() == PM_SDCARD) {
    return false;
  }
  //player.sendCommand({PR_STOP, 0});
  File tempfile = SPIFFS.open(TMP_PATH, "r");
  if (!tempfile) {
    return false;
  }
  char linePl[BUFLEN * 3];
  int sOvol;
  _readPlaylistLine(tempfile, linePl, sizeof(linePl) - 1);
  if (config.parseCSV(linePl, nsBuf, nsBuf2, sOvol)) {
    tempfile.close();
    SPIFFS.rename(TMP_PATH, PLAYLIST_PATH);
    requestOnChange(PLAYLISTSAVED, 0);
    return true;
  }
  if (config.parseJSON(linePl, nsBuf, nsBuf2, sOvol)) {
    File playlistfile = SPIFFS.open(PLAYLIST_PATH, "w");
    snprintf(linePl, sizeof(linePl) - 1, "%s\t%s\t%d", nsBuf, nsBuf2, 0);
    playlistfile.println(linePl);
    while (tempfile.available()) {
      _readPlaylistLine(tempfile, linePl, sizeof(linePl) - 1);
      if (config.parseJSON(linePl, nsBuf, nsBuf2, sOvol)) {
        snprintf(linePl, sizeof(linePl) - 1, "%s\t%s\t%d", nsBuf, nsBuf2, 0);
        playlistfile.println(linePl);
      }
    }
    playlistfile.flush();
    playlistfile.close();
    tempfile.close();
    SPIFFS.remove(TMP_PATH);
    requestOnChange(PLAYLISTSAVED, 0);
    return true;
  }
  tempfile.close();
  SPIFFS.remove(TMP_PATH);
  return false;
}

void NetServer::requestOnChange(requestType_e request, uint8_t clientId) {

  if (nsQueue == NULL) {
    g_nsPending.type = request;
    g_nsPending.clientId = clientId;
    g_nsPendingValid = true;

    LOGW("requestOnChange: nsQueue NULL -> PENDING type=%d clientId=%d",
         (int)request, (int)clientId);
    return;
  }

  nsRequestParams_t nsrequest;
  nsrequest.type = request;
  nsrequest.clientId = clientId;

  BaseType_t ok = xQueueSend(nsQueue, &nsrequest, pdMS_TO_TICKS(50));

  if (ok != pdTRUE) {
    LOGE("requestOnChange FAILED (QUEUE FULL) type=%d clientId=%d",
         (int)request, (int)clientId);
  } /*else {
    // type=7 == NRSSI -> NE spam-elje a logot
    if (request != NRSSI) {
      LOGI("requestOnChange OK type=%d clientId=%d",
           (int)request, (int)clientId);
    }
  }*/
}

void NetServer::resetQueue() {
  if (nsQueue != NULL) {
    xQueueReset(nsQueue);
  }
}

void handleUpload(AsyncWebServerRequest *request, String filename, size_t index, uint8_t *data, size_t len, bool final) {
  static int freeSpace = 0;
  if (request->url() == "/upload") {
    if (!index) {
      if (filename != "tempwifi.csv") {
        //player.sendCommand({PR_STOP, 0});
        if (SPIFFS.exists(PLAYLIST_PATH)) {
          SPIFFS.remove(PLAYLIST_PATH);
        }
        if (SPIFFS.exists(INDEX_PATH)) {
          SPIFFS.remove(INDEX_PATH);
        }
        if (SPIFFS.exists(PLAYLIST_SD_PATH)) {
          SPIFFS.remove(PLAYLIST_SD_PATH);
        }
        if (SPIFFS.exists(INDEX_SD_PATH)) {
          SPIFFS.remove(INDEX_SD_PATH);
        }
      }
      freeSpace = (float)SPIFFS.totalBytes() / 100 * 68 - SPIFFS.usedBytes();
      request->_tempFile = SPIFFS.open(TMP_PATH, "w");
    } else {
    }
    if (len) {
      if (freeSpace > index + len) {
        request->_tempFile.write(data, len);
      }
    }
    if (final) {
      request->_tempFile.close();
      freeSpace = 0;
    }
  } else if (request->url() == "/update") {
    if (!index) {
      int target = (request->getParam("updatetarget", true)->value() == "spiffs") ? U_SPIFFS : U_FLASH;
      log_i("Update Start: %s\n", filename.c_str());
      player.sendCommand({PR_STOP, 0});
      display.putRequest(NEWMODE, UPDATING);
      if (!Update.begin(UPDATE_SIZE_UNKNOWN, target)) {
        Update.printError(Serial);
        request->send(200, "text/html", updateError());
      }
    }
    if (!Update.hasError()) {
      if (Update.write(data, len) != len) {
        Update.printError(Serial);
        request->send(200, "text/html", updateError());
      }
    }
    if (final) {
      if (Update.end(true)) {
        log_i("Update Success: %uB\n", index + len);
      } else {
        Update.printError(Serial);
        request->send(200, "text/html", updateError());
      }
    }
  } else {  // "/webboard"
    DBGVB("File: %s, size:%u bytes, index: %u, final: %s\n", filename.c_str(), len, index, final ? "true" : "false");
    if (!index) {
      player.sendCommand({PR_STOP, 0});
      String spath = "/www/";
      if (filename == "playlist.csv" || filename == "wifi.csv") {
        spath = "/data/";
      }
      request->_tempFile = SPIFFS.open(spath + filename, "w");
    }
    if (len) {
      request->_tempFile.write(data, len);
    }
    if (final) {
      request->_tempFile.close();
      if (filename == "playlist.csv") {
        config.indexPlaylist();
      }
    }
  }
}

void onWsEvent(AsyncWebSocket *server, AsyncWebSocketClient *client, AwsEventType type, void *arg, uint8_t *data, size_t len) {
  switch (type) {
    case WS_EVT_CONNECT: /*netserver.requestOnChange(STARTUP, client->id()); */
      if (config.store.audioinfo) {
        log_i("[WEBSOCKET] client #%lu connected from %s\n", client->id(), config.ipToStr(client->remoteIP()));
      }
      break;
    case WS_EVT_DISCONNECT:
      if (config.store.audioinfo) {
        log_i("[WEBSOCKET] client #%lu disconnected\n", client->id());
      }
      break;
    case WS_EVT_DATA:  netserver.onWsMessage(arg, data, len, client->id()); break;
    case WS_EVT_PONG:
    case WS_EVT_ERROR: break;
  }
}
void handleNotFound(AsyncWebServerRequest *request) {
#if defined(HTTP_USER) && defined(HTTP_PASS)
  if (network.status == CONNECTED) {
    if (request->url() == "/logout") {
      request->send(401);
      return;
    }
  }
  if (!request->authenticate(HTTP_USER, HTTP_PASS)) {
    return request->requestAuthentication();
  }
#endif
  if (request->url() == "/emergency") {
    request->send_P(200, "text/html", emergency_form);
    return;
  }
  if (request->method() == HTTP_POST && request->url() == "/webboard" && config.emptyFS) {
    request->redirect("/");
    ESP.restart();
    return;
  }
  if (request->method() == HTTP_GET) {
    //DLNA mod
#ifdef USE_DLNA
    if (request->method() == HTTP_GET && request->url().startsWith("/data/dlna_")) {

      String path = request->url();
      log_i("[DLNA][HTTP] GET %s\n", path.c_str());

      if (!SPIFFS.exists(path)) {
        request->send(404, "text/plain", "DLNA file not found");
        return;
      }

      String type = "text/plain";
      if (path.endsWith(".json")) {
        type = "application/json";
      } else if (path.endsWith(".csv")) {
        type = "text/plain";
      }

      request->send(SPIFFS, path, type);
      return;
    }
#endif
    DBGVB("[%s] client ip=%s request of %s", __func__, config.ipToStr(request->client()->remoteIP()), request->url().c_str());
    if (
      strcmp(request->url().c_str(), PLAYLIST_PATH) == 0 || strcmp(request->url().c_str(), SSIDS_PATH) == 0 || strcmp(request->url().c_str(), INDEX_PATH) == 0
      || strcmp(request->url().c_str(), TMP_PATH) == 0 || strcmp(request->url().c_str(), PLAYLIST_SD_PATH) == 0
      || strcmp(request->url().c_str(), INDEX_SD_PATH) == 0
#ifdef USE_DLNA  //DLNA mod
      || strcmp(request->url().c_str(), PLAYLIST_DLNA_PATH) == 0 || strcmp(request->url().c_str(), INDEX_DLNA_PATH) == 0
#endif
    ) {
#ifdef MQTT_ROOT_TOPIC
      if (strcmp(request->url().c_str(), PLAYLIST_PATH) == 0) {
        while (mqttplaylistblock) {
          vTaskDelay(5);
        }
      }
#endif
      /* if(strcmp(request->url().c_str(), PLAYLIST_PATH) == 0 && config.getMode()==PM_SDCARD){
        netserver.chunkedHtmlPage("application/octet-stream", request, PLAYLIST_SD_PATH);
      }else{
        netserver.chunkedHtmlPage("application/octet-stream", request, request->url().c_str());
      }*/
      if (strcmp(request->url().c_str(), PLAYLIST_PATH) == 0) {

  const char* plPath = PLAYLIST_PATH;

#ifdef USE_SD
  if (config.getMode() == PM_SDCARD)
    plPath = PLAYLIST_SD_PATH;
#endif

#ifdef USE_DLNA
  if (config.getMode() == PM_WEB &&
      config.store.playlistSource == PL_SRC_DLNA)
    plPath = PLAYLIST_DLNA_PATH;
#endif

  netserver.chunkedHtmlPage("application/octet-stream", request, plPath);
  return;
}

      if (strcmp(request->url().c_str(), INDEX_PATH) == 0) {
        netserver.chunkedHtmlPage("application/octet-stream", request, REAL_INDEX);  //DLNA mod
        return;
      }
      netserver.chunkedHtmlPage("application/octet-stream", request, request->url().c_str());
      return;
    }  // if (strcmp(request->url().c_str(), PLAYLIST_PATH) == 0 ||
  }  // if (request->method() == HTTP_GET)

  if (request->method() == HTTP_POST) {
    if (request->url() == "/webboard") {
      request->redirect("/");
      return;
    }  // <--post files from /data/www
    if (request->url() == "/upload") {  // <--upload playlist.csv or wifi.csv
      if (request->hasParam("plfile", true, true)) {
        netserver.importRequest = IMPL;
        request->send(200);
      } else if (request->hasParam("wifile", true, true)) {
        netserver.importRequest = IMWIFI;
        request->send(200);
      } else {
        request->send(404);
      }
      return;
    }
    if (request->url() == "/update") {  // <--upload firmware
      shouldReboot = !Update.hasError();
      AsyncWebServerResponse *response = request->beginResponse(200, "text/plain", shouldReboot ? "OK" : updateError());
      response->addHeader("Connection", "close");
      request->send(response);
      return;
    }
  }  // if (request->method() == HTTP_POST)

  if (request->url() == "/favicon.ico") {
    request->send(200, "image/x-icon", "data:,");
    return;
  }
  if (request->url() == "/variables.js") {  //DLNA mod
    snprintf(
      netserver.nsBuf, sizeof(netserver.nsBuf),
      "var yoVersion='%s';\n"
      "var formAction='%s';\n"
      "var playMode='%s';\n"
      "var dlnaSupported=%d;\n",
      YOVERSION, (network.status == CONNECTED && !config.emptyFS) ? "webboard" : "", (network.status == CONNECTED) ? "player" : "ap",
      (
#if defined(USE_DLNA) || defined(USE_SOAP_DLNA)
        1
#else
        0
#endif
      )
    );
    request->send(200, "text/html", netserver.nsBuf);
    return;
  }
  if (strcmp(request->url().c_str(), "/settings.html") == 0 || strcmp(request->url().c_str(), "/update.html") == 0
      || strcmp(request->url().c_str(), "/ir.html") == 0) {
    //request->send_P(200, "text/html", index_html);
    AsyncWebServerResponse *response = request->beginResponse_P(200, "text/html", index_html);
    response->addHeader("Cache-Control", "max-age=31536000");
    request->send(response);
    return;
  }
  if (request->method() == HTTP_GET && request->url() == "/webboard") {
    request->send_P(200, "text/html", emptyfs_html);
    return;
  }
  log_i("%s", String("Not Found: ").c_str());
  LOGI("%s", request->url().c_str());
  request->send(404, "text/plain", "Not found");
}

void handleIndex(AsyncWebServerRequest *request) {
  if (config.emptyFS) {
    if (request->url() == "/" && request->method() == HTTP_GET) {
      request->send_P(200, "text/html", emptyfs_html);
      return;
    }
    if (request->url() == "/" && request->method() == HTTP_POST) {
      if (request->arg("ssid") != "" && request->arg("pass") != "") {
        netserver.nsBuf[0] = '\0';
        snprintf(netserver.nsBuf, sizeof(netserver.nsBuf), "%s\t%s", request->arg("ssid").c_str(), request->arg("pass").c_str());
        request->redirect("/");
        config.saveWifiFromNextion(netserver.nsBuf);
        return;
      }
      request->redirect("/");
      ESP.restart();
      return;
    }
    log_i("%s", String("Not Found: ").c_str());
    LOGI("%s", request->url().c_str());
    request->send(404, "text/plain", "Not found");
    return;
  }  // end if(config.emptyFS)
#if defined(HTTP_USER) && defined(HTTP_PASS)
  if (network.status == CONNECTED) {
    if (!request->authenticate(HTTP_USER, HTTP_PASS)) {
      return request->requestAuthentication();
    }
  }
#endif
  if (strcmp(request->url().c_str(), "/") == 0 && request->params() == 0) {
    if (network.status == CONNECTED) {
      AsyncWebServerResponse *response = request->beginResponse_P(200, "text/html", index_html);
      response->addHeader("Cache-Control", "max-age=31536000");
      request->send(response);
      //request->send_P(200, "text/html", index_html);
    } else {
      request->redirect("/settings.html");
    }
    return;
  }
  if (network.status == CONNECTED) {
    int paramsNr = request->params();
    if (paramsNr == 1) {
      AsyncWebParameter *p = request->getParam(0);
      if (cmd.exec(p->name().c_str(), p->value().c_str())) {
        if (p->name() == "reset" || p->name() == "clearspiffs") {
          request->redirect("/");
        }
        if (p->name() == "clearspiffs") {
          delay(100);
          ESP.restart();
        }
        request->send(200, "text/plain", "");
        return;
      }
    }
    if (request->hasArg("trebble") && request->hasArg("middle") && request->hasArg("bass")) {
      config.setTone(request->getParam("bass")->value().toInt(), request->getParam("middle")->value().toInt(), request->getParam("trebble")->value().toInt());
      request->send(200, "text/plain", "");
      return;
    }
    if (request->hasArg("sleep")) {
      int sford = request->getParam("sleep")->value().toInt();
      int safterd = request->hasArg("after") ? request->getParam("after")->value().toInt() : 0;
      if (sford > 0 && safterd >= 0) {
        request->send(200, "text/plain", "");
        config.sleepForAfter(sford, safterd);
        return;
      }
    }
    request->send(404, "text/plain", "Not found");

  } else {
    request->send(404, "text/plain", "Not found");
  }
}