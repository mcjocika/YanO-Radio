#if TS_MODEL == TS_MODEL_FT6X36
    #include "FT6X36.h"

FT6X36* FT6X36::_instance = nullptr;

FT6X36::FT6X36(TwoWire* wire, int8_t intPin) {
    _instance = this;
    _wire = wire;
    _intPin = intPin;
}

FT6X36::~FT6X36() {
    detachInterrupt(digitalPinToInterrupt(_intPin));
}

void ISR_ATTR FT6X36::isr() {
    if (_instance) _instance->onInterrupt();
}

bool FT6X36::begin(uint8_t threshold) {
    if (readRegister8(FT6X36_REG_PANEL_ID) != FT6X36_VENDID) return false;

    uint8_t id = readRegister8(FT6X36_REG_CHIPID);
    if (id != FT6206_CHIPID && id != FT6236_CHIPID && id != FT6336_CHIPID) return false;

    pinMode(_intPin, INPUT_PULLUP);
    attachInterrupt(digitalPinToInterrupt(_intPin), FT6X36::isr, FALLING);

    writeRegister8(FT6X36_REG_DEVICE_MODE, 0x00);
    writeRegister8(FT6X36_REG_THRESHHOLD, threshold);
    writeRegister8(FT6X36_REG_TOUCHRATE_ACTIVE, 0x0E);

    return true;
}

void FT6X36::registerIsrHandler(void (*fn)()) {
    _isrHandler = fn;
}

void FT6X36::registerTouchHandler(void (*fn)(TPoint point, TEvent e)) {
    _touchHandler = fn;
}

uint8_t FT6X36::touched() {
    uint8_t n = readRegister8(FT6X36_REG_NUM_TOUCHES);
    if (n > 2) { n = 0; }
    return n;
}

void FT6X36::loop() {
   if (_irqPending)
{
    _irqPending = false;
    processTouch();
}

}

void FT6X36::processTouch() {
    readData();
    uint8_t   n = 0;
    TRawEvent event = (TRawEvent)_touchEvent[n];
    TPoint    point{_touchX[n], _touchY[n]};

    if (event == TRawEvent::PressDown) {
        _points[0] = point;
        _pointIdx = 1;
        _dragMode = false;
        _touchStartTime = millis();
        fireEvent(point, TEvent::TouchStart);
    } else if (event == TRawEvent::Contact) {
        if (_pointIdx < 10) {
            _points[_pointIdx] = point;
            _pointIdx += 1;
        }
        if (!_dragMode && _points[0].aboutEqual(point) && millis() - _touchStartTime > 300) {
            _dragMode = true;
            fireEvent(point, TEvent::DragStart);
        } else if (_dragMode)
            fireEvent(point, TEvent::DragMove);

        fireEvent(point, TEvent::TouchMove);
    } else if (event == TRawEvent::LiftUp) {
        _points[9] = point;
        _touchEndTime = millis();
        fireEvent(point, TEvent::TouchEnd);
        if (_dragMode) {
            fireEvent(point, TEvent::DragEnd);
            _dragMode = false;
        }
        if (_points[0].aboutEqual(point) && _touchEndTime - _touchStartTime <= 300) {
            fireEvent(point, TEvent::Tap);
            _points[0] = {0, 0};
            _touchStartTime = 0;
        }
    } else {
    }
}

void FT6X36::onInterrupt() {
    _irqPending = true;
    if (_isrHandler) { _isrHandler(); }
}

void FT6X36::readData(void) {
    const uint8_t size = 16;
    uint8_t       data[size];
    _wire->beginTransmission(FT6X36_ADDR);
    _wire->write(0);
    _wire->endTransmission();

    _wire->requestFrom((uint8_t)FT6X36_ADDR, size);
    for (uint8_t i = 0; i < size; i++) data[i] = Wire.read();

    #ifdef FT6X36_DEBUG
    log_i("%s", String("REGISTERS:").c_str());
    for (int16_t i = 0; i < size; i++) {
        log_i("%s", String("0x").c_str());
        log_i("%s", String(i, HEX).c_str());
        log_i("%s", String(" = 0x").c_str());
        log_i("%s", String(data[i], HEX).c_str());
    }

    log_i("%s", "");
    log_i("%s", String("TOUCHES: ").c_str());
    log_i("%s", String(data[FT6X36_REG_NUM_TOUCHES]).c_str());
    log_i("%s", String("GESTURE: ").c_str());
    log_i("%s", String(data[FT6X36_REG_GESTURE_ID]).c_str());
    #endif
    _touches = data[FT6X36_REG_NUM_TOUCHES];

    const uint8_t addrShift = 6;
    for (uint8_t i = 0; i < 2; i++) {
        _touchX[i] = data[FT6X36_REG_P1_XH + i * addrShift] & 0x0F;
        _touchX[i] <<= 8;
        _touchX[i] |= data[FT6X36_REG_P1_XL + i * addrShift];
        _touchY[i] = data[FT6X36_REG_P1_YH + i * addrShift] & 0x0F;
        _touchY[i] <<= 8;
        _touchY[i] |= data[FT6X36_REG_P1_YL + i * addrShift];
        _touchEvent[i] = data[FT6X36_REG_P1_XH + i * addrShift] >> 6;
    }
}

void FT6X36::writeRegister8(uint8_t reg, uint8_t value) {
    _wire->beginTransmission(FT6X36_ADDR);
    _wire->write(reg);
    _wire->write(value);
    _wire->endTransmission();
}

uint8_t FT6X36::readRegister8(uint8_t reg) {
    _wire->beginTransmission(FT6X36_ADDR);
    _wire->write(reg);
    _wire->endTransmission();

    _wire->requestFrom((uint8_t)FT6X36_ADDR, (uint8_t)1);
    uint8_t value = _wire->read();

    #ifdef I2C_DEBUG
    log_i("%s", String("REG 0x").c_str());
    log_i("%s", String(reg, HEX).c_str());
    log_i("%s", String(": 0x").c_str());
    log_i("%s", String(value, HEX).c_str());
    #endif

    return value;
}

void FT6X36::fireEvent(TPoint point, TEvent e) {
    if (_touchHandler) _touchHandler(point, e);
}

    #ifdef FT6X36_DEBUG
void FT6X36::debugInfo() {
    log_i("%s", String("TH_DIFF: ").c_str());
    log_i("%s", String(readRegister8(FT6X36_REG_FILTER_COEF)).c_str());
    log_i("%s", String("CTRL: ").c_str());
    log_i("%s", String(readRegister8(FT6X36_REG_CTRL)).c_str());
    log_i("%s", String("TIMEENTERMONITOR: ").c_str());
    log_i("%s", String(readRegister8(FT6X36_REG_TIME_ENTER_MONITOR)).c_str());
    log_i("%s", String("PERIODACTIVE: ").c_str());
    log_i("%s", String(readRegister8(FT6X36_REG_TOUCHRATE_ACTIVE)).c_str());
    log_i("%s", String("PERIODMONITOR: ").c_str());
    log_i("%s", String(readRegister8(FT6X36_REG_TOUCHRATE_MONITOR)).c_str());
    log_i("%s", String("RADIAN_VALUE: ").c_str());
    log_i("%s", String(readRegister8(FT6X36_REG_RADIAN_VALUE)).c_str());
    log_i("%s", String("OFFSET_LEFT_RIGHT: ").c_str());
    log_i("%s", String(readRegister8(FT6X36_REG_OFFSET_LEFT_RIGHT)).c_str());
    log_i("%s", String("OFFSET_UP_DOWN: ").c_str());
    log_i("%s", String(readRegister8(FT6X36_REG_OFFSET_UP_DOWN)).c_str());
    log_i("%s", String("DISTANCE_LEFT_RIGHT: ").c_str());
    log_i("%s", String(readRegister8(FT6X36_REG_DISTANCE_LEFT_RIGHT)).c_str());
    log_i("%s", String("DISTANCE_UP_DOWN: ").c_str());
    log_i("%s", String(readRegister8(FT6X36_REG_DISTANCE_UP_DOWN)).c_str());
    log_i("%s", String("DISTANCE_ZOOM: ").c_str());
    log_i("%s", String(readRegister8(FT6X36_REG_DISTANCE_ZOOM)).c_str());
    log_i("%s", String("CIPHER: ").c_str());
    log_i("%s", String(readRegister8(FT6X36_REG_CHIPID)).c_str());
    log_i("%s", String("G_MODE: ").c_str());
    log_i("%s", String(readRegister8(FT6X36_REG_INTERRUPT_MODE)).c_str());
    log_i("%s", String("PWR_MODE: ").c_str());
    log_i("%s", String(readRegister8(FT6X36_REG_POWER_MODE)).c_str());
    log_i("%s", String("FIRMID: ").c_str());
    log_i("%s", String(readRegister8(FT6X36_REG_FIRMWARE_VERSION)).c_str());
    log_i("%s", String("FOCALTECH_ID: ").c_str());
    log_i("%s", String(readRegister8(FT6X36_REG_PANEL_ID)).c_str());
    log_i("%s", String("STATE: ").c_str());
    log_i("%s", String(readRegister8(FT6X36_REG_STATE)).c_str());
}
    #endif
#endif