#pragma once
#include <Arduino.h>

extern const uint16_t webui_nav_radio[] PROGMEM;
extern const uint16_t webui_nav_radio_w;
extern const uint16_t webui_nav_radio_h;

extern const uint16_t webui_nav_sd[] PROGMEM;
extern const uint16_t webui_nav_sd_w;
extern const uint16_t webui_nav_sd_h;

extern const uint16_t webui_nav_dlna[] PROGMEM;
extern const uint16_t webui_nav_dlna_w;
extern const uint16_t webui_nav_dlna_h;

extern const uint16_t webui_nav_eq[] PROGMEM;
extern const uint16_t webui_nav_eq_w;
extern const uint16_t webui_nav_eq_h;

extern const uint16_t webui_nav_settings[] PROGMEM;
extern const uint16_t webui_nav_settings_w;
extern const uint16_t webui_nav_settings_h;
