#pragma once

#include <Arduino.h>

// SoapESP32 based DLNA browser (Control Point)
// https://github.com/yellobyte/SoapESP32
//
// Enable with build flag: -DUSE_SOAP_DLNA

namespace soapdlna {

  void begin();

  // async scan state
  bool isScanning();
  uint32_t lastScanMs();
  uint16_t serverCount();

  // Start a scan in background (durationSec: 5..120)
  bool startScan(uint8_t durationSec);

  // JSON helpers for web UI
  bool serversToJson(String& outJson);
  bool browseToJson(uint16_t serverIndex, const String& objectId, uint32_t start, String& outJson);

} // namespace soapdlna
