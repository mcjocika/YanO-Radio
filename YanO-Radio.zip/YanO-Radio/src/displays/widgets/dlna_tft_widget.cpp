// DLNA TFT Browser UI (SoapDLNA)

#include "dlna_tft_widget.h"


// --- Text width helpers (no dependency on DspCore::textWidth which may not be linked on all builds)
static inline int _utf8GlyphCount(const char* s) {
  if (!s) return 0;
  int n = 0;
  const unsigned char* p = (const unsigned char*)s;
  while (*p) {
    // Count leading bytes as glyphs, skip UTF-8 continuation bytes (10xxxxxx)
    if ( (*p & 0xC0) != 0x80 ) n++;
    p++;
  }
  return n;
}
static inline int _textWidthPx(const char* s, uint8_t textSize = 1) {
  // Adafruit_GFX built-in 5x7 font approx width = 6px per glyph (incl. 1px spacing)
  return _utf8GlyphCount(s) * 6 * (int)textSize;
}
static inline int _textWidthPx(const String& s, uint8_t textSize = 1) {
  return _textWidthPx(s.c_str(), textSize);
}
// Ensure display driver typedefs (yoDisplay, Canvas, etc.) are visible before commongfx.
#include "../dspcore.h"
#include "../../core/options.h"

#include "../tools/commongfx.h"  // extern DspCore dsp

#include "../../core/config.h"
#include "../../core/player.h"
#include "../../core/netserver.h"
#include "../../core/display.h"
#include "../../core/timekeeper.h"

// NOTE: We intentionally avoid ArduinoJson here to keep dependencies minimal.
// The SoapDLNA helper returns a small, predictable JSON structure that we
// parse with lightweight string scanning.

#include <functional>

static bool _jsonFindKeyValueString(const String& src, const char* key, String& out) {
  String pat = String('"') + key + "\":\"";
  int p = src.indexOf(pat);
  if (p < 0) return false;
  p += pat.length();
  int e = src.indexOf('"', p);
  if (e < 0) return false;
  out = src.substring(p, e);
  return true;
}

static bool _jsonFindKeyValueInt(const String& src, const char* key, int& out) {
  String pat = String('"') + key + "\":";
  int p = src.indexOf(pat);
  if (p < 0) return false;
  p += pat.length();
  int e = p;
  while (e < (int)src.length() && (isDigit(src[e]) || src[e] == '-')) e++;
  if (e == p) return false;
  out = src.substring(p, e).toInt();
  return true;
}

static bool _jsonFindKeyValueBool(const String& src, const char* key, bool& out) {
  String pat = String('"') + key + "\":";
  int p = src.indexOf(pat);
  if (p < 0) return false;
  p += pat.length();
  if (src.startsWith("true", p)) { out = true; return true; }
  if (src.startsWith("false", p)) { out = false; return true; }
  return false;
}

static bool _jsonOkTrue(const String& src) {
  return src.indexOf("\"ok\":true") >= 0;
}

static bool _jsonExtractArray(const String& src, const char* key, String& outArray) {
  // Extracts the raw content between: "key":[ ... ]
  String pat = String('"') + key + "\":[";
  int p = src.indexOf(pat);
  if (p < 0) return false;
  p += pat.length();
  int depth = 1; // we are after '['
  int i = p;
  while (i < (int)src.length() && depth > 0) {
    char c = src[i++];
    if (c == '[') depth++;
    else if (c == ']') depth--;
  }
  if (depth != 0) return false;
  int end = i - 1; // position of closing ']'
  outArray = src.substring(p, end);
  return true;
}

static void _jsonForEachObject(const String& arrayBody, const std::function<void(const String&)>& fn) {
  // arrayBody contains: {..},{..}
  int i = 0;
  while (i < (int)arrayBody.length()) {
    int b = arrayBody.indexOf('{', i);
    if (b < 0) break;
    int depth = 0;
    int j = b;
    while (j < (int)arrayBody.length()) {
      char c = arrayBody[j++];
      if (c == '{') depth++;
      else if (c == '}') {
        depth--;
        if (depth == 0) break;
      }
    }
    if (depth != 0) break;
    fn(arrayBody.substring(b, j));
    i = j;
  }
}

#ifdef USE_SOAP_DLNA
  #include "../../network/soapdlna_service.h"
#endif

extern Player player;
extern Display display;
extern TimeKeeper timekeeper;
extern NetServer netserver;

// --- Browse worker task ---
struct BrowseTaskArgs {
  DlnaTftWidget* self;
  uint16_t sid;
  String objectId;
};

void dlnaBrowseTask(void* pv) {
  BrowseTaskArgs* a = (BrowseTaskArgs*)pv;
  DlnaTftWidget* self = a->self;

  String json;
  bool ok = false;
  String err;

#ifdef USE_SOAP_DLNA
  ok = soapdlna::browseToJson(a->sid, a->objectId, 0, json);
  if (!ok) err = "browse failed";
#else
  ok = false;
  err = "USE_SOAP_DLNA nincs engedelyezve";
#endif

  // publish result (single writer) - protect against concurrent UI reads
  if (self && self->_mx) xSemaphoreTake(self->_mx, portMAX_DELAY);
  if (self) {
    self->_browseJson = json;
    self->_browseErr = err;
    self->_browseOk = ok;
    // set done LAST so UI never sees partially written data
    self->_browseDone = true;
  }
  if (self && self->_mx) xSemaphoreGive(self->_mx);

  delete a;
  vTaskDelete(NULL);
}

void DlnaTftWidget::begin() {
  _hdrH = 18;
  _rowH = 14;
  _pad  = 4;
  _dirtyFull = true;
  _dirtyBody = true;

  if (!_mx) _mx = xSemaphoreCreateMutex();
}

void DlnaTftWidget::onEnter() {
  _servers.clear();
  _stack.clear();
  _cursor = 0;
  _serverSel = 0;
  _serverScroll = 0;
  _scanStarted = false;
  _browseDone = false;
  _browseOk = false;
  _browseJson = "";
  _browseErr = "";
  _setState(ST_SEARCHING, "DLNA szerverek keresese...");
  _startScan();
}

void DlnaTftWidget::onExit() {
  // biztosan engedjük vissza a screensavert
  config.screensaverInhibit = false;
}

void DlnaTftWidget::_setState(UiState s, const String& status) {
  _state = s;
  _stateAt = millis();
  if (status.length()) _status = status;
  _markDirtyFull();
}

void DlnaTftWidget::_markDirtyBody() {
  _dirtyBody = true;
}

void DlnaTftWidget::_markDirtyFull() {
  _dirtyFull = true;
  _dirtyBody = true;
}

void DlnaTftWidget::loop() {
  if (!_active || _locked) return;

  // keresés polling
  if (_state == ST_SEARCHING) {
    _pollScan();
  }

  // browse polling
  if (_state == ST_LOADING) {
    _pollBrowse();
  }

  // NO_SERVER countdown
  if (_state == ST_NO_SERVER) {
    uint32_t elapsed = millis() - _stateAt;
    if (elapsed > 5000) {
      // vissza rádióra és folytatás
      config.screensaverInhibit = false;
      config.store.playlistSource = PL_SRC_WEB;
      if (config.getMode() != PM_WEB) config.changeMode(PM_WEB);
      config.initPlaylist();
      config.loadStation(config.store.lastStation);
      if (player_on_station_change) player_on_station_change();
      netserver.requestOnChange(GETPLAYERMODE, 0);
      display.putRequest(NEWMODE, PLAYER);
      if (player.isRunning()) {
        // már megy, nem nyúlunk
      } else {
        player.sendCommand({PR_PLAY, (int)config.store.lastStation});
      }
    } else {
      // redraw countdown 1Hz
      static uint32_t last = 0;
      if (millis() - last > 900) {
        last = millis();
        _draw();
      }
    }
  }

  // animáció (SEARCHING/LOADING) – csak a body-t frissítjük, hogy ne villogjon
  if (_state == ST_SEARCHING || _state == ST_LOADING) {
    static uint32_t lastAnim = 0;
    // 500ms: csak a pörgőt/státuszt frissítjük ritkán (korábban már bevált)
    if (millis() - lastAnim > 500) {
      lastAnim = millis();
      _markDirtyBody();
    }
  }

  // redraw throttle (kb. 30fps max, de többnyire csak dirty esetén)
  if ((_dirtyFull || _dirtyBody) && (millis() - _lastBodyDrawMs > 30)) {
    _lastBodyDrawMs = millis();
    _draw();
  }
}

int DlnaTftWidget::_visibleRows() const {
  int bodyH = (int)dsp.height() - (int)_hdrH - (int)_pad;
  int rows = bodyH / (int)_rowH;
  if (rows < 1) rows = 1;
  return rows;
}

void DlnaTftWidget::_clampCursor() {
  if (_state == ST_SERVERS) {
    if (_serverSel < 0) _serverSel = 0;
    if (_serverSel >= (int)_servers.size()) _serverSel = (int)_servers.size() - 1;
    if (_serverSel < 0) _serverSel = 0;
    // scroll keep selection visible
    int rows = _visibleRows();
    if (_serverSel < _serverScroll) _serverScroll = _serverSel;
    if (_serverSel >= _serverScroll + rows) _serverScroll = _serverSel - rows + 1;
    if (_serverScroll < 0) _serverScroll = 0;
    return;
  }
  if (_state == ST_BROWSING) {
    if (_stack.empty()) return;
    int n = (int)_stack.back().items.size();
    if (_cursor < 0) _cursor = 0;
    if (_cursor >= n) _cursor = n - 1;
    if (_cursor < 0) _cursor = 0;
    // scroll keep selection visible (rows excludes breadcrumb row)
    Level& lvl = _stack.back();
    int rows = _visibleRows() - 1;
    if (rows < 1) rows = 1;
    if (_cursor < lvl.scroll) lvl.scroll = _cursor;
    if (_cursor >= lvl.scroll + rows) lvl.scroll = _cursor - rows + 1;
    if (lvl.scroll < 0) lvl.scroll = 0;
  }
}

void DlnaTftWidget::_serversMove(int delta) {
  if (_servers.empty()) return;
  _serverSel += delta;
  _clampCursor();
  _markDirtyBody();
}

void DlnaTftWidget::_browseMove(int delta) {
  if (_stack.empty()) return;
  _cursor += delta;
  _clampCursor();
  _markDirtyBody();
}

void DlnaTftWidget::_selectCurrent() {
  if (_state == ST_SERVERS) {
    if (_servers.empty()) return;
    // root browse
    _stack.clear();
    Level root;
    root.objectId = "0";
    root.title = _servers[_serverSel].name;
    _stack.push_back(root);
    _startBrowse(_servers[_serverSel].idx, "0", _servers[_serverSel].name);
    return;
  }
  if (_state == ST_BROWSING) {
    if (_stack.empty()) return;
    Level& lvl = _stack.back();
    if (_cursor < 0 || _cursor >= (int)lvl.items.size()) return;
    Item& it = lvl.items[_cursor];
    if (it.isContainer) {
      Level next;
      next.objectId = it.id;
      next.title = it.title;
      _stack.push_back(next);
      _startBrowse(_servers[_serverSel].idx, it.id, it.title);
      return;
    }
    if (it.url.length()) {
      if (config.getMode() != PM_WEB) config.changeMode(PM_WEB);
      config.store.playlistSource = PL_SRC_DLNA;
      netserver.requestOnChange(GETPLAYERMODE, 0);
      netserver.requestOnChange(GETINDEX, 0);
      player.playUrl(it.url.c_str(), "DLNA");
    }
  }
}

void DlnaTftWidget::_goBack() {
  if (_state == ST_BROWSING) {
    if (_stack.size() > 1) {
      _stack.pop_back();
      _cursor = 0;
      _markDirtyFull();
      return;
    }
    // root -> back to servers
    _stack.clear();
    _setState(ST_SERVERS, "Valassz szervert");
    return;
  }
  if (_state == ST_SERVERS) {
    // back to RADIO
    config.screensaverInhibit = false;
    config.store.playlistSource = PL_SRC_WEB;
    if (config.getMode() != PM_WEB) config.changeMode(PM_WEB);
    display.putRequest(NEWMODE, PLAYER);
    netserver.requestOnChange(GETPLAYERMODE, 0);
    _markDirtyFull();
    return;
  }
}

void DlnaTftWidget::onKey(int evt) {
  if (!_active || _locked) return;
  // We compare raw int ids to avoid pulling common.h here.
  // EVT_BTNLEFT=0, EVT_BTNCENTER=1, EVT_BTNRIGHT=2, EVT_BTNUP=4, EVT_BTNDOWN=5
  if (_state == ST_SEARCHING || _state == ST_LOADING) return;
  switch (evt) {
    case 4: // UP
      if (_state == ST_SERVERS) _serversMove(-1);
      else if (_state == ST_BROWSING) _browseMove(-1);
      break;
    case 5: // DOWN
      if (_state == ST_SERVERS) _serversMove(+1);
      else if (_state == ST_BROWSING) _browseMove(+1);
      break;
    case 1: // CENTER
    case 3: // ENC BTN B
    case 6: // ENC2 BTN B
      _selectCurrent();
      break;
    case 0: // LEFT = back
      _goBack();
      break;
    case 2: // RIGHT (optional: select)
      _selectCurrent();
      break;
    default:
      break;
  }
}

void DlnaTftWidget::_startScan() {
  config.screensaverInhibit = true; // keresés alatt biztosan ne sötétüljön
  _scanStarted = true;
  _scanStartMs = millis();
  _status = "DLNA szerverek keresese...";
#ifdef USE_SOAP_DLNA
  soapdlna::startScan(10);
#else
  _setState(ST_ERROR, "USE_SOAP_DLNA nincs engedelyezve");
#endif
}

void DlnaTftWidget::_pollScan() {
#ifndef USE_SOAP_DLNA
  return;
#else
  // ha még fut a scan → status frissítés
  if (soapdlna::isScanning()) {
    _status = String("DLNA szerverek keresese... (") + soapdlna::serverCount() + ")";
    _markDirtyBody();
    // timeout fallback
    if (millis() - _scanStartMs > 12000) {
      _setState(ST_NO_SERVER, "Nem talalhato DLNA szerver");
    }
    return;
  }

  // scan kész → lista
  String json;
  bool ok = soapdlna::serversToJson(json);
  if (!ok) {
    _setState(ST_NO_SERVER, "Nem talalhato DLNA szerver");
    return;
  }
  _fetchServersFromJson(json);
  if (_servers.empty()) {
    _setState(ST_NO_SERVER, "Nem talalhato DLNA szerver");
    return;
  }
  // mostantól engedjük a screensavert (DLNAUI-ban is)
  config.screensaverInhibit = false;
  _setState(ST_SERVERS, "Valassz szervert");
#endif
}

void DlnaTftWidget::_fetchServersFromJson(const String& json) {
  _servers.clear();
  if (!_jsonOkTrue(json)) return;

  String arr;
  if (!_jsonExtractArray(json, "servers", arr)) return;

  _jsonForEachObject(arr, [&](const String& obj) {
    Server s;
    int idx = 0, port = 0;
    String name, ip;
    if (!_jsonFindKeyValueInt(obj, "idx", idx)) return;
    _jsonFindKeyValueString(obj, "name", name);
    _jsonFindKeyValueString(obj, "ip", ip);
    _jsonFindKeyValueInt(obj, "port", port);
    s.idx = (uint16_t)idx;
    s.name = name;
    s.addr = ip + ":" + String(port);
    _servers.push_back(s);
  });
  _serverSel = 0;
  _serverScroll = 0;
}

void DlnaTftWidget::_startBrowse(uint16_t sid, const String& objectId, const String& title) {
  // browse alatt se aludjon el (rövid ideig)
  config.screensaverInhibit = true;

  if (_mx) xSemaphoreTake(_mx, portMAX_DELAY);
  _browseDone = false;
  _browseOk = false;
  _browseJson = "";
  _browseErr = "";
  if (_mx) xSemaphoreGive(_mx);

  _setState(ST_LOADING, String("Betoltes: ") + title);

  BrowseTaskArgs* a = new BrowseTaskArgs();
  a->self = this;
  a->sid = sid;
  a->objectId = objectId;
  // Run on core0 to avoid competing with UI loop on core1; larger stack for String-heavy JSON.
  xTaskCreatePinnedToCore(dlnaBrowseTask, "DlnaBrowse", 8192, a, 1, nullptr, 0);
}

void DlnaTftWidget::_pollBrowse() {
  // Copy shared results under mutex, then release quickly.
  bool done = false;
  bool ok = false;
  String json;
  String err;
  if (_mx) xSemaphoreTake(_mx, portMAX_DELAY);
  done = _browseDone;
  if (done) {
    ok = _browseOk;
    json = _browseJson;
    err = _browseErr;
    _browseDone = false;
  }
  if (_mx) xSemaphoreGive(_mx);

  if (!done) return;

  if (!ok) {
    config.screensaverInhibit = false;
    _setState(ST_ERROR, err.length() ? err : "DLNA hiba");
    return;
  }

  // apply
  String title = "";
  if (!_stack.empty()) title = _stack.back().title;
  _applyBrowseJson(json, title);
  config.screensaverInhibit = false;
  _setState(ST_BROWSING, "");
}

void DlnaTftWidget::_applyBrowseJson(const String& json, const String& title) {
  Level lvl;
  if (!_jsonOkTrue(json)) return;
  _jsonFindKeyValueString(json, "objectId", lvl.objectId);
  lvl.title = title;
  lvl.items.clear();

  String arr;
  if (_jsonExtractArray(json, "items", arr)) {
    _jsonForEachObject(arr, [&](const String& obj) {
      Item it;
      bool isCont = false;
      _jsonFindKeyValueString(obj, "id", it.id);
      _jsonFindKeyValueString(obj, "parentId", it.parentId);
      _jsonFindKeyValueString(obj, "title", it.title);
      _jsonFindKeyValueBool(obj, "isContainer", isCont);
      it.isContainer = isCont;
      _jsonFindKeyValueString(obj, "url", it.url);
      lvl.items.push_back(it);
    });
  }

  _stack.push_back(std::move(lvl));
  _cursor = 0;
  _clampCursor();
}

bool DlnaTftWidget::_touchHeader(uint16_t x, uint16_t y) {
  if (y > _hdrH) return false;
  uint16_t w = dsp.width();
  // 3 zóna: RADIO | SD | DLNA
  if (x < w / 3) {
    // RADIO
    config.screensaverInhibit = false;
    config.store.playlistSource = PL_SRC_WEB;
    if (config.getMode() != PM_WEB) config.changeMode(PM_WEB);
    display.putRequest(NEWMODE, PLAYER);
    netserver.requestOnChange(GETPLAYERMODE, 0);
    return true;
  }
  if (x < (2 * w) / 3) {
#ifdef USE_SD
    config.screensaverInhibit = false;
    config.changeMode(PM_SDCARD);
    display.putRequest(NEWMODE, PLAYER);
    netserver.requestOnChange(GETPLAYERMODE, 0);
    return true;
#else
    return true;
#endif
  }
  // DLNA → refresh keresés
  onEnter();
  return true;
}

void DlnaTftWidget::onTouch(uint16_t x, uint16_t y) {
  if (!_active || _locked) return;
  if (_touchHeader(x, y)) return;

  // Egyszerű touch scroll zónák (fel/le):
  // - a lista legfelső "üres" sávja (header alatt) = fel
  // - a kijelző alja = le
  // (A cél: legyen fel/le scroll, kijelölés és indítás is.)
  const uint16_t h = dsp.height();
  const int bodyTop = (int)_hdrH;
  if ((int)y > (int)h - 18) {
    // scroll down
    onKey(EVT_BTNDOWN);
    return;
  }
  if ((int)y < bodyTop + 18) {
    // scroll up
    onKey(EVT_BTNUP);
    return;
  }

  int bodyY = (int)_hdrH + (int)_pad;
  if ((int)y < bodyY) return;
  int row = ((int)y - bodyY) / (int)_rowH;
  if (row < 0) return;

  const uint32_t now = millis();

  if (_state == ST_SERVERS) {
    int idx = _serverScroll + row;
    if (idx >= 0 && idx < (int)_servers.size()) {
      // 1 tap = kijelölés, 2 gyors tap = belépés
      if (_lastTapIndex == idx && (now - _lastTapMs) < 450) {
        _lastTapIndex = -1;
        _lastTapMs = 0;
        _serverSel = idx;
        _clampCursor();
        _markDirtyBody();
        _selectCurrent();
      } else {
        _lastTapIndex = idx;
        _lastTapMs = now;
        _serverSel = idx;
        _clampCursor();
        _markDirtyBody();
      }
    }
    return;
  }

  if (_state == ST_BROWSING) {
    if (_stack.empty()) return;
    Level& lvl = _stack.back();
    int idx = lvl.scroll + row;
    if (idx < 0 || idx >= (int)lvl.items.size()) return;
    // 1 tap = kijelölés, 2 gyors tap = belépés/indítás
    if (_lastTapIndex == idx && (now - _lastTapMs) < 450) {
      _lastTapIndex = -1;
      _lastTapMs = 0;
      _cursor = idx;
      _clampCursor();
      _markDirtyBody();
      _selectCurrent();
    } else {
      _lastTapIndex = idx;
      _lastTapMs = now;
      _cursor = idx;
      _clampCursor();
      _markDirtyBody();
    }
    return;
  }

  if (_state == ST_ERROR) {
    // tap → vissza szerverlistára
    if (!_servers.empty()) {
      config.screensaverInhibit = false;
      _setState(ST_SERVERS, "Valassz szervert");
    } else {
      onEnter();
    }
    return;
  }
}

void DlnaTftWidget::_draw() {
  if (!_active || _locked) return;
  const uint16_t w = dsp.width();
  const uint16_t h = dsp.height();

  if (_dirtyFull) {
    // Full redraw (page entry / state change)
    dsp.fillScreen(config.theme.background);
    _drawHeader();
    // Body
    dsp.fillRect(0, _hdrH, w, h - _hdrH, config.theme.background);
    _drawBody();
    _dirtyFull = false;
    _dirtyBody = false;
    return;
  }

  if (_dirtyBody) {
    // Partial redraw: only clear the body area to reduce flicker.
    // (Header stays intact.)
    dsp.fillRect(0, _hdrH, w, h - _hdrH, config.theme.background);
    _drawBody();
    _dirtyBody = false;
  }
}

void DlnaTftWidget::_clear() {
  dsp.fillScreen(config.theme.background);
}

void DlnaTftWidget::_drawHeader() {
  uint16_t w = dsp.width();
  // Harmonize with the main player look: meta bar colors + centered title.
  dsp.fillRect(0, 0, w, _hdrH, config.theme.metafill);

  // Title
  dsp.setTextColor(config.theme.meta, config.theme.metafill);
  dsp.setTextSize(2);
  const char* title = "DLNA";
  int tw = _textWidthPx(title, 1);
  int tx = (int)w/2 - tw/2;
  if (tx < 0) tx = 0;
  dsp.setCursor(tx, 2);
  dsp.print(title);

  // Small "tabs" at the bottom of the header for mode switching.
  dsp.setTextSize(1);
  int tabY = _hdrH - 9;
  dsp.setCursor(_pad, tabY);
  dsp.print("RADIO");
  dsp.setCursor(w/2 - _textWidthPx("SD", 1)/2, tabY);
  dsp.print("SD");
  const char* r = "FRISSIT";
  dsp.setCursor(w - _textWidthPx(r, 1) - _pad, tabY);
  dsp.print(r);
}

void DlnaTftWidget::_drawCentered(const String& line1, const String& line2) {
  uint16_t w = dsp.width();
  uint16_t h = dsp.height();
  dsp.setTextSize(1);
  dsp.setTextColor(config.theme.title1, config.theme.background);
  String s1 = utf8To(line1.c_str(), true);
  int16_t y1 = (int16_t)(h/2 - 12);
  int16_t x1 = (int16_t)((int)w/2 - (int)_textWidthPx(s1.c_str(), 1)/2);
  if (x1 < 0) x1 = 0;
  dsp.setCursor(x1, y1);
  dsp.print(s1);
  if (line2.length()) {
    dsp.setTextColor(config.theme.clock, config.theme.background);
    String s2 = utf8To(line2.c_str(), true);
    int16_t x2 = (int16_t)((int)w/2 - (int)_textWidthPx(s2.c_str(), 1)/2);
    if (x2 < 0) x2 = 0;
    dsp.setCursor(x2, y1 + 14);
    dsp.print(s2);
  }
}

// Truncate UTF8-as plain string (already converted with utf8To) to fit within maxPx.
static String _fitTextPx(DspCore& dsp, const String& s, int maxPx) {
  if (maxPx <= 0) return String("");
  if ((int)_textWidthPx(s.c_str(), 1) <= maxPx) return s;
  String t = s;
  const char* ell = "...";
  const int ellW = _textWidthPx(ell, 1);
  while (t.length() > 0) {
    t.remove(t.length() - 1);
    if ((int)_textWidthPx(t.c_str(), 1) + ellW <= maxPx) {
      t += ell;
      return t;
    }
  }
  return String("");
}

void DlnaTftWidget::_drawBody() {
  int y0 = _hdrH + _pad;

  if (_state == ST_SEARCHING) {
    // egyszerű spinner
    const char frames[] = {'|','/','-','\\'};
    char sp = frames[(millis()/150) % 4];
    String l2 = String(sp) + "  " + _status;
    _drawCentered("DLNA", l2);
    return;
  }

  if (_state == ST_LOADING) {
    const char frames[] = {'|','/','-','\\'};
    char sp = frames[(millis()/150) % 4];
    String l2 = String(sp) + "  " + _status;
    _drawCentered("Betoltes...", l2);
    return;
  }

  if (_state == ST_NO_SERVER) {
    uint32_t left = 5 - ((millis() - _stateAt) / 1000);
    String l2 = "Vissza radiohoz: " + String((int)left);
    _drawCentered("Nem talalhato DLNA szerver", l2);
    return;
  }

  if (_state == ST_ERROR) {
    _drawCentered("DLNA hiba", _status);
    return;
  }

  dsp.setTextSize(1);
  dsp.setTextColor(config.theme.title1, config.theme.background);

  if (_state == ST_SERVERS) {
    int rows = _visibleRows();
    for (int r=0; r<rows; ++r) {
      int i = _serverScroll + r;
      if (i >= (int)_servers.size()) break;
      // rows are drawn from top, not absolute index
      int y = y0 + r*_rowH;
      bool sel = (i == _serverSel);
      if (sel) dsp.fillRect(0, y-1, dsp.width(), _rowH, config.theme.plcurrentbg);
      dsp.setTextColor(sel ? config.theme.plcurrent : config.theme.title1, sel ? config.theme.plcurrentbg : config.theme.background);

      // Right-aligned address
      String addr = _servers[i].addr;
      int addrW = _textWidthPx(addr.c_str(), 1);
      int addrX = (int)dsp.width() - addrW - _pad;
      if (addrX < _pad) addrX = _pad;
      dsp.setCursor(addrX, y);
      dsp.print(addr);

      // Left name, truncated to fit before address
      String name = utf8To(_servers[i].name.c_str(), true);
      int maxNamePx = addrX - (_pad * 2);
      name = _fitTextPx(dsp, name, maxNamePx);
      dsp.setCursor(_pad, y);
      dsp.print(name);
    }
    return;
  }

  if (_state == ST_BROWSING) {
    if (_stack.empty()) {
      _drawCentered("Ures", "");
      return;
    }
    Level& lvl = _stack.back();
    // breadcrumb
    dsp.setTextColor(config.theme.clock, config.theme.background);
    dsp.setCursor(_pad, y0);
    dsp.print(utf8To(lvl.title.c_str(), true));
    int listY = y0 + _rowH;
    int rows = _visibleRows() - 1;
    if (rows < 1) rows = 1;
    for (int r=0;r<rows;++r) {
      int idx = lvl.scroll + r;
      if (idx >= (int)lvl.items.size()) break;
      int y = listY + r*_rowH;
      bool sel = (idx == _cursor);
      if (sel) dsp.fillRect(0, y-1, dsp.width(), _rowH, config.theme.plcurrentbg);
      dsp.setTextColor(sel ? config.theme.plcurrent : config.theme.title1, sel ? config.theme.plcurrentbg : config.theme.background);
      dsp.setCursor(_pad, y);
      const char* prefix = lvl.items[idx].isContainer ? "> " : "  ";
      dsp.print(prefix);
      // Fit the title into the remaining line width.
      String title = utf8To(lvl.items[idx].title.c_str(), true);
      int maxPx = (int)dsp.width() - _pad - (int)_textWidthPx(prefix, 1);
      title = _fitTextPx(dsp, title, maxPx);
      dsp.print(title);
    }
    return;
  }
}
