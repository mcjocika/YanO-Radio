#pragma once
#include <U8g2lib.h>
#include <Wire.h>
#include <time.h>

// yoRadio core helpers (névnap + időjárás)
#include "core/namedays.h"
#include "core/timekeeper.h"
#include "core/config.h"

class OledClock {
  public:
    void begin();
    void update();

  private:
    U8G2_SH1106_128X64_NONAME_F_HW_I2C display =
        U8G2_SH1106_128X64_NONAME_F_HW_I2C(U8G2_R0, U8X8_PIN_NONE);

    unsigned long lastUpdate = 0;
    // cache to avoid unnecessary redraw
    char lastDate[11] = "";     // YYYY-MM-DD
    char lastTimeHHMM[6] = "";  // HH:MM
    bool lastColonOn = false;
    char lastNameday[40] = "";
    char lastTemp[12] = "";     // e.g. -2°C
    char lastWxDesc[32] = "";   // weather description (optional)
};
