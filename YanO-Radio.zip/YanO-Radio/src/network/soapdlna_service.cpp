#include "soapdlna_service.h"

#ifdef USE_SOAP_DLNA

#include <WiFi.h>
#include <WiFiUdp.h>
#include <WiFiClient.h>

#include "SoapESP32.h"

static WiFiClient s_client;
static WiFiUDP    s_udp;
static SoapESP32  s_soap(&s_client, &s_udp);

// NOTE:
// Some WiFi/router setups require the UDP socket to be explicitly joined to
// the SSDP multicast group, otherwise discovery can return 0 servers even
// though DLNA servers exist on the LAN.
static bool s_udpReady = false;

static TaskHandle_t s_scanTask = nullptr;
static volatile bool s_scanning = false;
static uint32_t s_lastScanMs = 0;
static uint16_t s_srvCount = 0;

static void scanTask(void* arg) {
  uint8_t durationSec = (uint8_t)(uintptr_t)arg;
  if (durationSec < 5) durationSec = 5;
  if (durationSec > 120) durationSec = 120;

  s_scanning = true;
  s_srvCount = 0;
  s_soap.seekServer(durationSec);
  soapServer_t srv;
  unsigned int idx = 0;
  while (s_soap.getServerInfo(idx++, &srv)) {
    // Only count content-delivering servers
    s_srvCount++;
  }
  s_lastScanMs = millis();
  s_scanning = false;
  s_scanTask = nullptr;
  vTaskDelete(nullptr);
}

namespace soapdlna {

// SoapESP32 structures store many fields as C strings.
// Some DLNA servers legitimately omit certain tags which can lead to NULL
// pointers (e.g. uri/title). Constructing Arduino String from a NULL pointer
// crashes (strlen(NULL) -> LoadProhibited). Always sanitize first.
static inline String safeStr(const char* p) {
  return (p && *p) ? String(p) : String();
}
static inline String safeStr(const String& s) {
  // Arduino String is never NULL; returning as-is is safe
  return s;
}

void begin() {
  // Best-effort: bind UDP to SSDP multicast.
  if (WiFi.status() == WL_CONNECTED && !s_udpReady) {
    s_udpReady = s_udp.beginMulticast(IPAddress(239,255,255,250), 1900);
  }
}

bool isScanning() { return s_scanning; }
uint32_t lastScanMs() { return s_lastScanMs; }
uint16_t serverCount() { return s_srvCount; }

bool startScan(uint8_t durationSec) {
  if (WiFi.status() != WL_CONNECTED) return false;
  if (s_scanTask) return false;

  // Ensure SSDP multicast socket is ready.
  if (!s_udpReady) {
    s_udpReady = s_udp.beginMulticast(IPAddress(239,255,255,250), 1900);
  }

  xTaskCreatePinnedToCore(scanTask, "soapDlnaScan", 6144, (void*)(uintptr_t)durationSec, 2, &s_scanTask, 0);
  return true;
}

bool serversToJson(String& outJson) {
  soapServer_t srv;
  unsigned int i = 0;
  outJson = "{\"ok\":true,\"servers\":[";
  bool first = true;
  while (s_soap.getServerInfo(i++, &srv)) {
    if (!first) outJson += ',';
    first = false;
    outJson += "{\"idx\":" + String(i-1);
    outJson += ",\"name\":\"" + safeStr(srv.friendlyName) + "\"";
    outJson += ",\"ip\":\"" + srv.ip.toString() + "\"";
    outJson += ",\"port\":" + String(srv.port);
    outJson += "}";
  }
  outJson += "]}";
  return true;
}


static String makeAbsoluteUrl(uint16_t serverIndex, const String& uri) {
  if (uri.length() == 0) return String();
  if (uri.startsWith("http://") || uri.startsWith("https://")) return uri;

  soapServer_t srv;
  if (!s_soap.getServerInfo(serverIndex, &srv)) return uri;

  String path = uri;
  if (!path.startsWith("/")) path = "/" + path;

  String base = "http://" + srv.ip.toString() + ":" + String(srv.port);
  return base + path;
}


bool browseToJson(uint16_t serverIndex, const String& objectId, uint32_t start, String& outJson) {
  soapObjectVect_t vec;

  // SoapESP32 uses C strings; objectId like "0" root.
  if (!s_soap.browseServer(serverIndex, objectId.c_str(), &vec, start, SOAP_DEFAULT_BROWSE_MAX_COUNT)) {
    outJson = "{\"ok\":false,\"error\":\"browse failed\"}";
    return false;
  }

  outJson = "{\"ok\":true,\"server\":" + String(serverIndex) + ",\"objectId\":\"" + objectId + "\",";
  outJson += "\"start\":" + String(start) + ",\"count\":" + String((uint32_t)vec.size()) + ",\"items\":[";

  for (unsigned int i = 0; i < vec.size(); i++) {
    if (i) outJson += ',';

    // Sanitize potentially NULL C-string fields.
    String id       = safeStr(vec[i].id);
    String parentId = safeStr(vec[i].parentId);
    String title    = safeStr(vec[i].name);
    String uri      = safeStr(vec[i].uri);

    outJson += "{";
    outJson += "\"id\":\"" + id + "\",";
    outJson += "\"parentId\":\"" + parentId + "\",";
    outJson += "\"title\":\"" + title + "\",";
    outJson += "\"isContainer\":" + String(vec[i].isDirectory ? "true" : "false") + ",";
    outJson += "\"size\":" + String((uint32_t)vec[i].size) + ",";
    // Always return an absolute URL if the server gives a relative URI.
    outJson += "\"url\":\"" + makeAbsoluteUrl(serverIndex, uri) + "\"";
    outJson += "}";
  }
  outJson += "]}";
  return true;
}

} // namespace soapdlna

#endif // USE_SOAP_DLNA
