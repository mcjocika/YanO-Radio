#include "Arduino.h"
#include "options.h"
#include "WiFi.h"
#include "time.h"
#include "config.h"
#include "display.h"
// (removed) hu_glcdfont Hungarian font support
#include "presets.h"
#include "player.h"
#include "network.h"
#include "netserver.h"
#include "timekeeper.h"
#include "../pluginsManager/pluginsManager.h"
#include "../displays/dspcore.h"
#include "../displays/widgets/widgets.h"
#include "../displays/widgets/dlna_tft_widget.h"
#include "../displays/widgets/pages.h"
#include "../displays/tools/l10n.h"

#if TFT_WEB_SKIN
  #include "../displays/widgets/webui.h"
#endif

#ifdef USE_DLNA
  #include "../network/dlna_worker.h"
#endif

Display display;
#ifdef USE_NEXTION
  #include "../displays/nextion.h"
Nextion nextion;
#endif

#ifndef CORE_STACK_SIZE
  #define CORE_STACK_SIZE 1024 * 4
#endif
#ifndef DSP_TASK_PRIORITY
  #define DSP_TASK_PRIORITY 2  //"task_prioritas"
#endif
#ifndef DSP_TASK_CORE_ID
  #define DSP_TASK_CORE_ID 0
#endif
#ifndef DSP_TASK_DELAY
  #define DSP_TASK_DELAY pdMS_TO_TICKS(10)  // cap for 50 fps
#endif

#define DSP_QUEUE_TICKS 0

#ifndef DSQ_SEND_DELAY
  //#define DSQ_SEND_DELAY portMAX_DELAY
  #define DSQ_SEND_DELAY pdMS_TO_TICKS(200)
#endif

QueueHandle_t displayQueue;

// WebUI: remember whether playback was active before opening dialog screens
static bool s_resumeAfterDialog = false;

static void loopDspTask(void *pvParameters) {
  while (true) {
#ifndef DUMMYDISPLAY
    if (displayQueue == NULL) {
      break;
    }
    if (timekeeper.loop0()) {
      display.loop();
  #ifndef NETSERVER_LOOP1
      netserver.loop();
  #endif
    }
#else
    timekeeper.loop0();
  #ifndef NETSERVER_LOOP1
    netserver.loop();
  #endif
#endif
    vTaskDelay(DSP_TASK_DELAY);
  }
  vTaskDelete(NULL);
}

void Display::_createDspTask() {
  xTaskCreatePinnedToCore(loopDspTask, "DspTask", CORE_STACK_SIZE, NULL, DSP_TASK_PRIORITY, NULL, DSP_TASK_CORE_ID);  //"task_prioritas"
}

#ifndef DUMMYDISPLAY
//============================================================================================================================
DspCore dsp;

Page *pages[] = {new Page(), new Page(), new Page(), new Page(), new Page(), new Page()};  // + DLNA page

  #if !(                                                                                                                                           \
    (DSP_MODEL == DSP_ST7735 && DTYPE == INITR_BLACKTAB) || DSP_MODEL == DSP_ST7789 || DSP_MODEL == DSP_ST7796 || DSP_MODEL == DSP_ILI9488         \
    || DSP_MODEL == DSP_ILI9486 || DSP_MODEL == DSP_ILI9341 || DSP_MODEL == DSP_ILI9225 || DSP_MODEL == DSP_ST7789_170 || DSP_MODEL == DSP_SSD1322 \
  )
    #undef BITRATE_FULL
    #define BITRATE_FULL false
  #endif

void returnPlayer() {
  display.putRequest(NEWMODE, PLAYER);
}

Display::~Display() {
  delete _pager;
  delete _footer;
  delete _plwidget;
  delete _nums;
  delete _clock;
  delete _meta;
  delete _title1;
  delete _title2;
  delete _plcurrent;
  delete _dlnaUi;
  #if TFT_WEB_SKIN
  delete _webui;
  #endif
}

void Display::init() {
  log_i("%s", String("##[BOOT]#\tdisplay.init\t").c_str());
  #ifdef USE_NEXTION
  nextion.begin();
  #endif
  #if LIGHT_SENSOR != 255
  analogSetAttenuation(ADC_0db);
  #endif
  _bootStep = 0;
  dsp.initDisplay();
  displayQueue = NULL;
  displayQueue = xQueueCreate(5, sizeof(requestParams_t));
  while (displayQueue == NULL) {
    ;
  }
  _createDspTask();
  while (!_bootStep == 0) {
    delay(10);
  }
  //_pager.begin();
  //_bootScreen();
  _pager = new Pager();
  _footer = new Page();
  _plwidget = new PlayListWidget();
  _nums = new NumWidget();
  _clock = new ClockWidget();
  _meta = new ScrollWidget();
  _title1 = new ScrollWidget();
  _plcurrent = new ScrollWidget();
  #if TFT_WEB_SKIN
  _webui = new WebUiWidget();
  #endif
  log_i("%s", String("done").c_str());
}

uint16_t Display::width() {
  return dsp.width();
}
uint16_t Display::height() {
  return dsp.height();
}

// PLAYER képernyő SD/DLNA ikon hit-test (érintőkijelző)
bool Display::hitTestModeIcons(uint16_t x, uint16_t y, uint8_t &which) {
  which = 0;
  if (_mode != PLAYER) return false;
  if (!_modeIcons) return false;

  // Geometria: ugyanaz, mint a ModeIconsWidget-ben (2x2, adaptív cell+gap)
  const uint16_t cell = config.store.showweather ? 24 : 32;
  const uint16_t gap  = config.store.showweather ? 4  : 6;
  const uint16_t tw = cell + gap + cell;
  const uint16_t th = cell + gap + cell;

  const uint16_t top = _modeIconsConf.top;

  // Align kezelése: WA_RIGHT esetén _modeIconsConf.left jobb oldali margó
  uint16_t left = _modeIconsConf.left;
  if (_modeIconsConf.align == WA_RIGHT) left = dsp.width() - tw - _modeIconsConf.left;
  else if (_modeIconsConf.align == WA_CENTER) left = (dsp.width() - tw) / 2;

  if (y < top || y >= (uint16_t)(top + th)) return false;
  if (x < left || x >= (uint16_t)(left + tw)) return false;

  // cella index
  const uint16_t dx = x - left;
  const uint16_t dy = y - top;

  const bool rightCol = (dx >= (cell + gap));
  const bool bottomRow = (dy >= (cell + gap));

  // which: 1=SD (bal felső), 2=DLNA (jobb felső), 3=EQ (bal alsó), 4=SET (jobb alsó)
  if (!bottomRow && !rightCol) { which = 1; return true; }
  if (!bottomRow && rightCol)  { which = 2; return true; }
  if (bottomRow && !rightCol)  { which = 3; return true; }
  if (bottomRow && rightCol)   { which = 4; return true; }
  return false;
}

#if TFT_WEB_SKIN
bool Display::hitTestWebUi(uint16_t x, uint16_t y, WebUiBtn &btn) {
  btn = WebUiBtn::NONE;
  if (_mode != PLAYER) return false;
  if (!_webui) return false;
  // Ghost click védelem: képernyőváltás után rövid ideig ignoráljuk a WebUI gombokat
  if (_webuiIgnoreUntil && (int32_t)(millis() - _webuiIgnoreUntil) < 0) return false;
  btn = _webui->hitTest(x, y);
  return (btn != WebUiBtn::NONE);
}

void Display::ignoreWebUi(uint32_t ms) {
  _webuiIgnoreUntil = millis() + ms;
}

#endif

void Display::dlnaUiTouch(uint16_t x, uint16_t y) {
  if (_mode != DLNAUI) return;
  if (_dlnaUi) _dlnaUi->onTouch(x, y);
}

void Display::dlnaUiKey(int evt) {
  if (_mode != DLNAUI) return;
  if (_dlnaUi) _dlnaUi->onKey(evt);
}
  #if TIME_SIZE > 19
    #if DSP_MODEL == DSP_SSD1322
      #define BOOT_PRG_COLOR WHITE
      #define BOOT_TXT_COLOR WHITE
      #define PINK           WHITE
    #elif DSP_MODEL == DSP_SSD1327
      #define BOOT_PRG_COLOR 0x07
      #define BOOT_TXT_COLOR 0x3f
      #define PINK           0x02
    #else
      #define BOOT_PRG_COLOR 0xE68B
      #define BOOT_TXT_COLOR 0xFFFF
      #define PINK           0xF97F
    #endif
  #endif

void Display::_bootScreen() {
  _boot = new Page();
  _boot->addWidget(new ProgressWidget(bootWdtConf, bootPrgConf, BOOT_PRG_COLOR, 0));
  _bootstring = (TextWidget *)&_boot->addWidget(new TextWidget(bootstrConf, 50, true, BOOT_TXT_COLOR, 0));
  _pager->addPage(_boot);
  _pager->setPage(_boot, true);
  dsp.drawLogo(bootLogoTop);
  _bootStep = 1;
}

void Display::_buildPager() {
  #if !TFT_WEB_SKIN
    _meta->init("*", metaConf, config.theme.meta, config.theme.metabg);
    _title1->init("*", title1Conf, config.theme.title1, config.theme.background);
  #endif
  #if !TFT_WEB_SKIN
    _clock->init(clockConf, 0, 0);
    // Módváltó ikonok: külön "sáv"-ként kezeljük (ne a clock helyén), hogy ne fedjék egymást.
    WidgetConfig iconsConf = clockConf;
    iconsConf.align = WA_RIGHT;
    iconsConf.left  = 10;
    if (iconsConf.top > 40) iconsConf.top = iconsConf.top - 40;
    _modeIcons = new ModeIconsWidget(iconsConf, config.theme.clock, config.theme.background);
    _modeIconsConf = iconsConf;  // sync for hit-test
  #else
    // WEB-SKIN módban a régi widget-es UI elemeket nem rajzoljuk.
    _clock->init({0,0,0,WA_LEFT}, 0, 0); // init safe (nem lesz page-re rakva)
    _modeIcons = nullptr;
  #endif


  #if DSP_MODEL == DSP_NOKIA5110
  _plcurrent->init("*", playlistConf, 0, 1);
  #else
  _plcurrent->init("*", playlistConf, config.theme.plcurrent, config.theme.plcurrentbg);
  #endif
  _plwidget->init(_plcurrent);
  #if !defined(DSP_LCD)
  _plcurrent->moveTo({TFT_FRAMEWDT, (uint16_t)(_plwidget->currentTop()), (int16_t)playlistConf.width});
  #endif
  #ifndef HIDE_TITLE2
    #if !TFT_WEB_SKIN
      _title2 = new ScrollWidget("*", title2Conf, config.theme.title2, config.theme.background);
    #else
      _title2 = nullptr;
    #endif
  #endif
  #if !TFT_WEB_SKIN
    #if !defined(DSP_LCD) && DSP_MODEL != DSP_NOKIA5110
      _plbackground = new FillWidget(playlBGConf, config.theme.plcurrentfill);
      #if DSP_INVERT_TITLE || defined(DSP_OLED)
        _metabackground = new FillWidget(metaBGConf, config.theme.metafill);
      #else
        _metabackground = new FillWidget(metaBGConfInv, config.theme.metafill);
      #endif
    #endif
  #else
    _plbackground = nullptr;
    _metabackground = nullptr;
  #endif
  #if DSP_MODEL == DSP_NOKIA5110
  _plbackground = new FillWidget(playlBGConf, 1);
    //_metabackground = new FillWidget(metaBGConf, 1);
  #endif
  #if !TFT_WEB_SKIN
    #ifndef HIDE_VU
      _vuwidget = new VuWidget(vuConf, bandsConf, config.theme.vumax, config.theme.vumid, config.theme.vumin, config.theme.background);
    #endif
  #else
    _vuwidget = nullptr;
  #endif
  #if !TFT_WEB_SKIN
    #ifndef HIDE_VOLBAR
      _volbar = new SliderWidget(volbarConf, config.theme.volbarin, config.theme.background, 100, config.theme.volbarout);
    #endif
    #ifndef HIDE_HEAPBAR
      _heapbar = new SliderWidget(heapbarConf, config.theme.buffer, config.theme.background, psramInit() ? 300000 : 1600 * config.store.abuff);
    #endif
    #ifndef HIDE_VOL
      _voltxt = new TextWidget(voltxtConf, 10, false, config.theme.vol, config.theme.background);
    #endif
    #ifndef HIDE_IP
      _volip = new TextWidget(iptxtConf, 30, false, config.theme.ip, config.theme.background);
    #endif
    #ifndef HIDE_RSSI
      _rssi = new TextWidget(rssiConf, 20, false, config.theme.rssi, config.theme.background);
    #endif
  #else
    _volbar = nullptr;
    _heapbar = nullptr;
    _voltxt = nullptr;
    _volip = nullptr;
    _rssi = nullptr;
  #endif
  _nums->init(numConf, 10, false, config.theme.digit, config.theme.background);

  // DLNA TFT UI widget (külön oldal)
  _dlnaUi = new DlnaTftWidget();
  {
    WidgetConfig full{0, 0, 0, WA_LEFT};
    _dlnaUi->init(full, config.theme.title1, config.theme.background);
    _dlnaUi->begin();
    pages[PG_DLNA]->addWidget(_dlnaUi);
  }
  #if !TFT_WEB_SKIN
    #ifndef HIDE_WEATHER
      _weather = new ScrollWidget("\007", weatherConf, config.theme.weather, config.theme.background);
    #endif
  #else
    _weather = nullptr;
  #endif

  #if !TFT_WEB_SKIN
    _chtxt = new TextWidget(chtxtConf, 12, false, config.theme.ch, config.theme.background);
  #else
    _chtxt = nullptr;
  #endif

  if (!TFT_WEB_SKIN) {
    if (_volbar)  _footer->addWidget(_volbar);
    if (_voltxt)  _footer->addWidget(_voltxt);
    if (_volip)   _footer->addWidget(_volip);
    if (_rssi)    _footer->addWidget(_rssi);
    if (_heapbar) _footer->addWidget(_heapbar);
    if (_chtxt)   _footer->addWidget(_chtxt);
  }
#if !TFT_WEB_SKIN
  if (_metabackground) {
    pages[PG_PLAYER]->addWidget(_metabackground);
  }
#endif
  #if !TFT_WEB_SKIN
    pages[PG_PLAYER]->addWidget(_meta);
    pages[PG_PLAYER]->addWidget(_title1);
    if (_title2) {
      pages[PG_PLAYER]->addWidget(_title2);
    }
  #else
    // Teljesen új UI: egyetlen "web" widget rajzol mindent.
    WidgetConfig full{0, 0, 1, WA_LEFT};
    _webui->init(full, config.theme.title1, config.theme.background);
    _webui->setActive(true);
    pages[PG_PLAYER]->addWidget(_webui);
  #endif

  #if !TFT_WEB_SKIN
    if (_weather) {
      pages[PG_PLAYER]->addWidget(_weather);
    }
    #if BITRATE_FULL
      _fullbitrate = new BitrateWidget(fullbitrateConf, config.theme.bitrate, config.theme.background);
      pages[PG_PLAYER]->addWidget(_fullbitrate);
    #else
      _bitrate = new TextWidget(bitrateConf, 30, false, config.theme.bitrate, config.theme.background);
      pages[PG_PLAYER]->addWidget(_bitrate);
    #endif
    if (_vuwidget) {
      pages[PG_PLAYER]->addWidget(_vuwidget);
    }
    if (_modeIcons) pages[PG_PLAYER]->addWidget(_modeIcons);
    pages[PG_PLAYER]->addWidget(_clock);
    pages[PG_SCREENSAVER]->addWidget(_clock);
    pages[PG_PLAYER]->addPage(_footer);
  #endif

  #if !TFT_WEB_SKIN
    if (_metabackground) {
      pages[PG_DIALOG]->addWidget(_metabackground);
    }
    pages[PG_DIALOG]->addWidget(_meta);
    pages[PG_DIALOG]->addWidget(_nums);
  #else
    // új UI-ban a dialog page jelenleg nem használatos
  #endif

  #if !defined(DSP_LCD) && DSP_MODEL != DSP_NOKIA5110
  pages[PG_DIALOG]->addPage(_footer);
  #endif
  #if !defined(DSP_LCD)
  if (_plbackground) {
    pages[PG_PLAYLIST]->addWidget(_plbackground);
    _plbackground->setHeight(_plwidget->itemHeight());
    _plbackground->moveTo({0, (uint16_t)(_plwidget->currentTop() - playlistConf.widget.textsize * 2), (int16_t)playlBGConf.width});
  }
  #endif
  pages[PG_PLAYLIST]->addWidget(_plcurrent);
  pages[PG_PLAYLIST]->addWidget(_plwidget);
  for (const auto &p : pages) {
    _pager->addPage(p);
  }
}

void Display::_apScreen() {
  if (_boot) {
    _pager->removePage(_boot);
  }
  #ifndef DSP_LCD
  _boot = new Page();
    #if DSP_MODEL != DSP_NOKIA5110
      #if DSP_INVERT_TITLE || defined(DSP_OLED)
  _boot->addWidget(new FillWidget(metaBGConf, config.theme.metafill));
      #else
  _boot->addWidget(new FillWidget(metaBGConfInv, config.theme.metafill));
      #endif
    #endif
  ScrollWidget *bootTitle = (ScrollWidget *)&_boot->addWidget(new ScrollWidget("*", apTitleConf, config.theme.meta, config.theme.metabg));
  bootTitle->setText("yoRadio AP Mode");
  TextWidget *apname = (TextWidget *)&_boot->addWidget(new TextWidget(apNameConf, 30, false, config.theme.title1, config.theme.background));
  apname->setText(LANG::apNameTxt);
  TextWidget *apname2 = (TextWidget *)&_boot->addWidget(new TextWidget(apName2Conf, 30, false, config.theme.clock, config.theme.background));
  apname2->setText(apSsid);
  TextWidget *appass = (TextWidget *)&_boot->addWidget(new TextWidget(apPassConf, 30, false, config.theme.title1, config.theme.background));
  appass->setText(LANG::apPassTxt);
  TextWidget *appass2 = (TextWidget *)&_boot->addWidget(new TextWidget(apPass2Conf, 30, false, config.theme.clock, config.theme.background));
  appass2->setText(apPassword);
  ScrollWidget *bootSett = (ScrollWidget *)&_boot->addWidget(new ScrollWidget("*", apSettConf, config.theme.title2, config.theme.background));
  bootSett->setText(config.ipToStr(WiFi.softAPIP()), LANG::apSettFmt);
  _pager->addPage(_boot);
  _pager->setPage(_boot);
  #else
  dsp.apScreen();
  #endif
}

void Display::_start() {
  if (_boot) {
    _pager->removePage(_boot);
  }
  #ifdef USE_NEXTION
  nextion.wake();
  #endif
  if (network.status != CONNECTED && network.status != SDREADY) {
    _apScreen();
  #ifdef USE_NEXTION
    nextion.apScreen();
  #endif
    _bootStep = 2;
    return;
  }
  #ifdef USE_NEXTION
  //nextion.putcmd("page player");
  nextion.start();
  #endif
  _buildPager();
  _mode = PLAYER;
  config.setTitle(LANG::const_PlReady);

  if (_heapbar) {
    _heapbar->lock(!config.store.audioinfo);
  }

  if (_weather) {
    _weather->lock(!config.store.showweather);
  }
  if (_weather && config.store.showweather) {
    _weather->setText(LANG::const_getWeather);
  }

  if (_vuwidget) {
    _vuwidget->lock();
  }
  if (_rssi) {
    _setRSSI(WiFi.RSSI());
  }
  if (_chtxt) {                                      // Ha létezik a widget
    _chtxt->setText(config.lastStation(), "CH:%d");  // Beállítja a csatorna számát a widgetnek.
  }
  #ifndef HIDE_IP
  if (_volip) {
    _volip->setText(config.ipToStr(WiFi.localIP()), iptxtFmt);
  }
  #endif
  _pager->setPage(pages[PG_PLAYER]);
#if TFT_WEB_SKIN
  if (_webui) _webui->requestRedraw(true);
#endif
  _volume();
  _station();
  _time(false);
  _bootStep = 2;
  pm.on_display_player();
      // restore playback if a dialog screen stopped it unexpectedly
      if (s_resumeAfterDialog && player.status() != PLAYING) {
        player.sendCommand({PR_PLAY, (int)config.lastStation()});
      }
      s_resumeAfterDialog = false;
}

void Display::_showDialog(const char *title) {
  dsp.setScrollId(NULL);
  _pager->setPage(pages[PG_DIALOG]);
  #ifdef META_MOVE
  _meta->moveTo(metaMove);
  #endif
  _meta->setAlign(WA_CENTER);
  _meta->setText(title);
}

void Display::_swichMode(displayMode_e newmode) {
  #ifdef USE_NEXTION
  //nextion.swichMode(newmode);
  nextion.putRequest({NEWMODE, newmode});
  #endif
  // --- EZT ADD HOZZÁ: ---
  if (newmode == VOL) return; 
  // ----------------------
  if (newmode == _mode || (network.status != CONNECTED && network.status != SDREADY)) {
    return;
  }
  displayMode_e oldmode = _mode;
  // kilépés hook
  if (oldmode == DLNAUI && _dlnaUi) {
    _dlnaUi->onExit();
  }

  _mode = newmode;
  dsp.setScrollId(NULL);
  if (newmode == PLAYER) {
    #if TFT_WEB_SKIN
      // Web-skin UI: ne használjuk a régi widgeteket (óra/meta), csak oldalváltás + full redraw.
      config.isScreensaver = false;
      _pager->setPage(pages[PG_PLAYER]);
#if TFT_WEB_SKIN
  if (_webui) _webui->requestRedraw(true);
#endif
      #ifdef DSP_LCD
        dsp.clearDsp();
      #endif
      if (_webui) _webui->setActive(true);
      if (_webui) _webui->requestRedraw(true);
      config.setDspOn(config.store.dspon, false);
      pm.on_display_player();
    #else
      if (player.isRunning()) {
        if (clockMove.width < 0) {
          _clock->moveBack();
        } else {
          _clock->moveTo(clockMove);
        }
      } else {
        _clock->moveBack();
      }
    #ifdef DSP_LCD
      dsp.clearDsp();
    #endif
      numOfNextStation = 0;
    #ifdef META_MOVE
      _meta->moveBack();
    #endif
      _meta->setAlign(metaConf.widget.align);
      _station();
      config.isScreensaver = false;
      _pager->setPage(pages[PG_PLAYER]);
#if TFT_WEB_SKIN
  if (_webui) _webui->requestRedraw(true);
#endif
      config.setDspOn(config.store.dspon, false);
      pm.on_display_player();
    #endif
  }

  if (newmode == DLNAUI) {
    // DLNA külön oldal
    config.isScreensaver = false;
    _pager->setPage(pages[PG_DLNA]);
    if (_dlnaUi) _dlnaUi->onEnter();
    // DLNA oldalon is legyen biztosan DSP on
    config.setDspOn(config.store.dspon, false);
  }
  if (newmode == SCREENSAVER || newmode == SCREENBLANK) {
    config.isScreensaver = true;
    _pager->setPage(pages[PG_SCREENSAVER]);
    if (newmode == SCREENBLANK) {
      //dsp.clearClock();
      _clock->clear();
      config.setDspOn(false, false);
    }
  } else {
    config.screensaverTicks = SCREENSAVERSTARTUPDELAY;
    config.screensaverPlayingTicks = SCREENSAVERSTARTUPDELAY;
    config.isScreensaver = false;
  }
  if (newmode == VOL) {
  #ifndef HIDE_IP
    _showDialog(LANG::const_DlgVolume);
  #else
    _showDialog(config.ipToStr(WiFi.localIP()));
  #endif
    _nums->setText(config.store.volume, numtxtFmt);
  }
  if (newmode == LOST) {
    _showDialog(LANG::const_DlgLost);
  }
  if (newmode == UPDATING) {
    _showDialog(LANG::const_DlgUpdate);
  }
  if (newmode == SLEEPING) {
    _showDialog("SLEEPING");
  }
  if (newmode == SDCHANGE) {
    _showDialog(LANG::const_waitForSD);
  }
  if (newmode == INFO || newmode == SETTINGS || newmode == TIMEZONE || newmode == WIFI) {
    _showDialog(LANG::const_DlgNextion);
  }
  if (newmode == EQSCREEN) {
    s_resumeAfterDialog = (player.status() == PLAYING);
    // WEB-SKIN módban a régi dialog/widget réteg nincs initelve (meta/title),
    // ezért itt közvetlen rajzolunk, hogy ne legyen null-pointer / reset.
    #if !TFT_WEB_SKIN
      _showDialog("EQUALIZER");
    #endif
    #if TFT_WEB_SKIN
      if (_webui) _webui->setActive(false);
    #endif
    _drawEqScreen();
  }
  if (newmode == QUICKSETTINGS) {
    s_resumeAfterDialog = (player.status() == PLAYING);
    #if !TFT_WEB_SKIN
      _showDialog("SETTINGS");
    #endif
    #if TFT_WEB_SKIN
      if (_webui) _webui->setActive(false);
    #endif
    _drawQuickSettings();
  }
  if (newmode == NUMBERS) {
    _showDialog("");
  }
  #if DSP_MODEL == DSP_ILI9488
  if (newmode == PRESETS) {
    _pager->setPage(pages[PG_PRESETS], true);
    presets_drawScreen();
  }
  #endif
  if (newmode == STATIONS) {
    _pager->setPage(pages[PG_PLAYLIST]);
    _plcurrent->setText("");
    currentPlItem = config.lastStation();
    _drawPlaylist();
  }
}

void Display::resetQueue() {
  if (displayQueue != NULL) {
    xQueueReset(displayQueue);
  }
}

void Display::_drawPlaylist() {
  #ifdef USE_DLNA
  // DLNA módban a playlist felépítése (SOAP browse/build) időigényes lehet.
  // Ne azt lássa a user, hogy "STOP" / üres a lista, hanem kapjon visszajelzést.
  if (config.getMode() == PM_WEB && config.store.playlistSource == PL_SRC_DLNA) {
    if (g_dlnaStatus.busy) {
      dsp.fillRect(0, _plwidget->yStart(), dsp.width(), _plwidget->itemsCount() * _plwidget->itemHeight(), config.theme.background);
      dsp.setTextColor(config.theme.playlist[0], config.theme.background);
      dsp.setTextSize(playlistConf.widget.textsize);
      dsp.setCursor(TFT_FRAMEWDT, _plwidget->yStart() + 4);
      dsp.print(utf8To("DLNA: dolgozom...", true));
      dsp.setCursor(TFT_FRAMEWDT, _plwidget->yStart() + 4 + _plwidget->itemHeight());
      dsp.print(utf8To(g_dlnaStatus.msg, true));
      timekeeper.waitAndReturnPlayer(2);
      return;
    }
  }
  #endif

  //dsp.drawPlaylist(currentPlItem);
  _plwidget->drawPlaylist(currentPlItem);
  uint8_t stations_list_return_time = STATIONS_LIST_RETURN_TIME;
  if (stations_list_return_time < 1) {
    stations_list_return_time = 1;
  }
  timekeeper.waitAndReturnPlayer(stations_list_return_time);  // "stations_list_return_time"
                                                              //  Serial.printf(" Display::_drawPlaylist \n");
}

void Display::_drawNextStationNum(uint16_t num) {
  timekeeper.waitAndReturnPlayer(30);  // Visszatérési idő a főképernyőre.
  _meta->setText(config.stationByNum(num));
  _nums->setText(num, "%d");
}

void Display::putRequest(displayRequestType_e type, int payload) {
  if (displayQueue == NULL) {
    return;
  }
  requestParams_t request;
  request.type = type;
  request.payload = payload;
  xQueueSend(displayQueue, &request, DSQ_SEND_DELAY);
  #ifdef USE_NEXTION
  nextion.putRequest(request);
  #endif
}

void Display::_layoutChange(bool played) {
  #if TFT_WEB_SKIN
    (void)played;
    return;
  #endif
  if (config.store.vumeter && _vuwidget) {
    if (played) {
      if (_vuwidget) {
        _vuwidget->unlock();
      }
      //_clock->moveTo(clockMove);
      if (clockMove.width < 0) {
        _clock->moveBack();
      } else {
        _clock->moveTo(clockMove);
      }
      if (_weather) {
        _weather->moveTo(weatherMoveVU);
      }
    } else {
      if (_vuwidget) {
        if (!_vuwidget->locked()) {
          _vuwidget->lock();
        }
      }
      _clock->moveBack();
      if (_weather) {
        _weather->moveBack();
      }
    }
  } else {
    if (played) {
      if (clockMove.width < 0) {
        _clock->moveBack();
      } else {
        _clock->moveTo(clockMove);
      }
      if (_weather) {
        _weather->moveTo(weatherMove);
      }
      //_clock->moveBack();
    } else {
      if (_weather) {
        _weather->moveBack();
      }
      _clock->moveBack();
    }
  }
}

void Display::loop() {
  if (_bootStep == 0) {
    _pager->begin();
    _bootScreen();
    return;
  }
  if (displayQueue == NULL || _locked) {
    return;
  }
  _pager->loop();
  #ifdef USE_NEXTION
  nextion.loop();
  #endif
  requestParams_t request;
  if (xQueueReceive(displayQueue, &request, DSP_QUEUE_TICKS)) {
    bool pm_result = true;
    pm.on_display_queue(request, pm_result);
    if (pm_result) {
      switch (request.type) {
        case WEBUIBTN:
        {
#if TFT_WEB_SKIN
          if (_mode != PLAYER) break;
          WebUiBtn btn = (WebUiBtn)request.payload;
          switch (btn) {
            case WebUiBtn::PREV:      player.sendCommand({PR_PREV, 0}); break;
            case WebUiBtn::PLAYPAUSE: player.sendCommand({PR_TOGGLE, 0}); break;
            case WebUiBtn::STOP:      player.sendCommand({PR_STOP, 0}); break;
            case WebUiBtn::NEXT:      player.sendCommand({PR_NEXT, 0}); break;

            case WebUiBtn::EQ:
              _swichMode(EQSCREEN);
              break;
            case WebUiBtn::SETTINGS:
              _swichMode(QUICKSETTINGS);
              break;

            case WebUiBtn::RADIO:
              {
                config.store.playlistSource = PL_SRC_WEB;
                if (config.getMode() != PM_WEB) config.changeMode(PM_WEB);

                // Switch back to WEB radio: re-init playlist, load last station, start playback
                config.initPlaylist();

                uint16_t st = config.store.lastStation;
                uint16_t len = config.playlistLength();
                if (st < 1 || (len > 0 && st > len)) st = 1;
                if (len > 0) {
                  config.loadStation(st);
                  if (player_on_station_change) player_on_station_change();
                  player.sendCommand({PR_PLAY, (int)st});
                }

                netserver.requestOnChange(GETINDEX, 0);
                netserver.requestOnChange(GETPLAYERMODE, 0);

                // Ensure a clean TFT after mode/source switch
                display.putRequest(NEWMODE, CLEAR);
                display.putRequest(NEWMODE, PLAYER);
                display.putRequest(NEWSTATION);
                display.putRequest(NEWTITLE);
              }
              break;
#ifdef USE_SD
            case WebUiBtn::SD:
              config.changeMode(PM_SDCARD);
              netserver.requestOnChange(GETPLAYERMODE, 0);
              break;
#endif
#ifdef USE_DLNA
            case WebUiBtn::DLNA:
              // DLNA quick-start: only if playlist exists and server is reachable.
              // Otherwise show guidance on Web UI.
              player.startDlnaFromButton();

              // Ensure a clean TFT after mode/source switch
              display.putRequest(NEWMODE, CLEAR);
              display.putRequest(NEWMODE, PLAYER);
              break;
#endif
            default:
              break;
          }
          if (_webui) _webui->requestRedraw();
#endif
          break;
        }
        case NEWMODE:
          _swichMode((displayMode_e)request.payload);
          #if TFT_WEB_SKIN
          if (_webui) _webui->requestRedraw();
          #endif
          break;
        case CLOSEPLAYLIST: player.sendCommand({PR_PLAY, request.payload}); break;
        case CLOCK:
          if (_mode == PLAYER || _mode == SCREENSAVER) {
            _time(request.payload == 1);
          }
          /*#ifdef USE_NEXTION
            if(_mode==TIMEZONE) nextion.localTime(network.timeinfo);
            if(_mode==INFO)     nextion.rssi();
          #endif*/
          break;
        case NEWTITLE:
          _title();
          #if TFT_WEB_SKIN
          if (_webui) _webui->requestRedraw();
          #endif
          break;
        case NEWSTATION:
          _station();
          #if TFT_WEB_SKIN
          if (_webui) _webui->requestRedraw();
          #endif
          break;
        case NEXTSTATION:  _drawNextStationNum(request.payload); break;

        // Playlist rajzolás kizárólag akkor, ha a TFT ténylegesen a STATIONS (playlist) képernyőn van.
        // Webes DLNA playlist betöltéskor/auto-playkor több helyről is érkezhet DRAWPLAYLIST kérés,
        // és ha ilyenkor a PLAYER képernyő aktív, a playlist egy pillanatra rárajzolódhat a kijelzőre.
        // Ez a guard megakadályozza a "villanást" és a kijelző összekavarását.
        case DRAWPLAYLIST:
          if (_mode == STATIONS) {
            _drawPlaylist();
          }
          break;
		case DRAWVOL:
          _volume();
          #if TFT_WEB_SKIN
          if (_webui) _webui->requestRedraw();
          #endif
          break;
        case DBITRATE:
        {
          if (_mode == PLAYER) {  // csak a lejátszás képernyőn frissíti a bitrateWidgetet
            char buf[20];
            snprintf(buf, 20, bitrateFmt, config.station.bitrate);
            if (_bitrate) {
              _bitrate->setText(config.station.bitrate == 0 ? "" : buf);
            }
            if (_fullbitrate) {
              _fullbitrate->setBitrate(config.station.bitrate);
              _fullbitrate->setFormat(config.configFmt);
            }
            if (_chtxt) {                                      // Ha létezik a widget
              _chtxt->setText(config.lastStation(), "CH:%d");  // Beállítja a csatorna számát a widgetnek.
            }
          }
          #if TFT_WEB_SKIN
          if (_webui) _webui->requestRedraw();
          #endif
        } break;
        case CLEARALLBITRATE:
        {                         // "nameday"
          if (_mode == PLAYER) {  // csak a lejátszás képernyőn
            if (_fullbitrate) {
              _fullbitrate->clearAll();
            }
          }
        } break;
        case AUDIOINFO:
          if (_heapbar) {
            _heapbar->lock(!config.store.audioinfo);
            _heapbar->setValue(player.inBufferFilled());
          }
          break;
        case SHOWVUMETER:
        {
          if (_vuwidget) {
            _vuwidget->lock(!config.store.vumeter);
            _layoutChange(player.isRunning());
          }
          break;
        }
        case SHOWWEATHER:
        {
          if (_weather) {
            _weather->lock(!config.store.showweather);
          }
          if (!config.store.showweather) {
  #ifndef HIDE_IP
            if (_volip) {
              _volip->setText(config.ipToStr(WiFi.localIP()), iptxtFmt);
            }
  #endif
          } else {
            if (_weather) {
              _weather->setText(LANG::const_getWeather);
            }
          }
          break;
        }
        case NEWWEATHER:
        {
          if (_weather && timekeeper.weatherBuf) {
            _weather->setText(timekeeper.weatherBuf);
          }
          break;
        }
        case BOOTSTRING:
        {
          if (_bootstring) {
            _bootstring->setText(config.ssids[request.payload].ssid, LANG::bootstrFmt);
          }
          /*#ifdef USE_NEXTION
            char buf[50];
            snprintf(buf, 50, bootstrFmt, config.ssids[request.payload].ssid);
            nextion.bootString(buf);
          #endif*/
          break;
        }
        case WAITFORSD:
        {
          if (_bootstring) {
            _bootstring->setText(LANG::const_waitForSD);
          }
          break;
        }
        case SDFILEINDEX:
        {
          if (_mode == SDCHANGE) {
            _nums->setText(request.payload, "%d");
          }
          break;
        }
        case DSPRSSI:
          if (_rssi) {
            _setRSSI(request.payload);
          }
          if (_heapbar && config.store.audioinfo) {
            _heapbar->setValue(player.isRunning() ? player.inBufferFilled() : 0);
          }
          break;
        case PSTART:    _layoutChange(true); break;
        case PSTOP:     _layoutChange(false); break;
        case DSP_START: _start(); break;
        case NEWIP:
        {
  #ifndef HIDE_IP
          if (_volip) {
            _volip->setText(config.ipToStr(WiFi.localIP()), iptxtFmt);
          }
  #endif
          break;
        }
        default:
          break;
      } // switch(request.type)

      // Ha még van üzenet a sorban, inkább azt dolgozzuk fel, ne rajzoljunk feleslegesen.
      if (uxQueueMessagesWaiting(displayQueue)) {
        return;
      }

      // A felső sávot több művelet (title/station/playlist/redraw) felülírhatja,
      // ezért a mód-ikonokat mindig a frissítések UTÁN, overlay-ként húzzuk rá.
      // Throttle: ne rajzoljuk 50fps-sel, elég ~6-7fps (és az üzenetek után).
      static uint32_t s_lastModeIconsRedraw = 0;
      const uint32_t now = millis();
      if (_mode == PLAYER && _modeIcons && !_modeIcons->locked()) {
        if (now - s_lastModeIconsRedraw > 150) {
          _modeIcons->drawNow();
          s_lastModeIconsRedraw = now;
        }
      }

    } // while(xQueueReceive)
  } // if(displayQueue)

  dsp.loop();
  /*
  #if I2S_DOUT==255
  player.computeVUlevel();
  #endif
*/
}

void Display::_setRSSI(int rssi) {
  if (!_rssi) {
    return;
  }
  #if RSSI_DIGIT
  _rssi->setText(rssi, rssiFmt);
  return;
  #endif
  char rssiG[3];
  int rssi_steps[] = {RSSI_STEPS};
  if (rssi >= rssi_steps[0]) {
    strlcpy(rssiG, "\004\006", 3);
  }
  if (rssi >= rssi_steps[1] && rssi < rssi_steps[0]) {
    strlcpy(rssiG, "\004\005", 3);
  }
  if (rssi >= rssi_steps[2] && rssi < rssi_steps[1]) {
    strlcpy(rssiG, "\004\002", 3);
  }
  if (rssi >= rssi_steps[3] && rssi < rssi_steps[2]) {
    strlcpy(rssiG, "\003\002", 3);
  }
  if (rssi < rssi_steps[3] || rssi >= 0) {
    strlcpy(rssiG, "\001\002", 3);
  }
  _rssi->setText(rssiG);
}

// ---------------------------------------------------------------------------
// Egyszerű TFT oldalak: EQ + Quick settings
// (Később lehet szebb widgetesre cserélni; most a cél a stabil, működő érintés.)
// ---------------------------------------------------------------------------

static void _drawBtn(int x, int y, int w, int h, const char* txt, uint16_t fg, uint16_t bg) {
  dsp.fillRoundRect(x, y, w, h, 6, bg);
  dsp.drawRoundRect(x, y, w, h, 6, fg);
  dsp.setTextColor(fg, bg);
  dsp.setTextSize(1);
  int16_t tx = x + 8;
  int16_t ty = y + (h / 2) - 4;
  dsp.setCursor(tx, ty);
  dsp.print(txt);
}

// (removed) hu_glcdfont based text drawing helpers

void Display::_drawEqScreen() {
  dsp.fillRect(0,0,dsp.width(),dsp.height(),config.theme.background);
  dsp.setTextSize(2);
  dsp.setTextColor(config.theme.meta, config.theme.background);
  dsp.setCursor(10, 10);
  dsp.print("Hangszinszabalyzo");

  // 3 sor: Bass / Mid / Treble
  dsp.setTextSize(1);
  const int x0 = 20;
  const int y0 = 50;
  const int rowH = 60;
  auto drawRow = [&](int row, const char* name, int val) {
    int y = y0 + row * rowH;
    dsp.setTextColor(config.theme.title1, config.theme.background);
    dsp.setCursor(x0, y);
    dsp.printf("%s: %d", name, val);
    // - / + gombok
    _drawBtn(dsp.width() - 150, y - 10, 60, 40, "-", config.theme.meta, config.theme.metabg);
    _drawBtn(dsp.width() - 80,  y - 10, 60, 40, "+", config.theme.meta, config.theme.metabg);
  };
  drawRow(0, "BASS",   config.store.bass);
  drawRow(1, "MID",    config.store.middle);
  drawRow(2, "TREBLE", config.store.trebble);

  _drawBtn(10, dsp.height() - 50, 140, 40, "<- Vissza", config.theme.meta, config.theme.metabg);
}

void Display::drawEqScreen() {
  if (_mode == EQSCREEN) _drawEqScreen();
}

void Display::_drawQuickSettings() {
  dsp.fillRect(0,0,dsp.width(),dsp.height(),config.theme.background);
  dsp.setTextSize(2);
  dsp.setTextColor(config.theme.meta, config.theme.background);
  dsp.setCursor(10, 10);
  dsp.print("Beallitasok");

  dsp.setTextSize(1);
  const int x0 = 20;
  const int y0 = 55;
  const int rowH = 45;
  const int bottomReserved = 60; // BACK gomb + margó

  struct Tgl { const char* label; bool* ptr; };
  Tgl toggles[] = {
    {"Telnet",  &config.store.telnet},
    {"Watchdog",&config.store.watchdog},
    {"Screensaver", &config.store.screensaverEnabled},
    {"AMP ctl", &config.store.ampCtlEnabled},
    {"SPK ctl", &config.store.spkCtlEnabled},
  };

  const int total = (int)(sizeof(toggles)/sizeof(toggles[0]));
  const int maxRows = (dsp.height() - y0 - bottomReserved) / rowH + 1;
  if (_qsScroll < 0) _qsScroll = 0;
  const int maxScroll = (total > maxRows) ? (total - maxRows) : 0;
  if (_qsScroll > maxScroll) _qsScroll = maxScroll;

  // Scroll gombok (ha kell)
  if (total > maxRows) {
    _drawBtn(dsp.width() - 44, y0 - 38, 34, 28, "^", config.theme.meta, config.theme.metabg);
    _drawBtn(dsp.width() - 44, dsp.height() - bottomReserved - 10, 34, 28, "v", config.theme.meta, config.theme.metabg);
  }

  for (int vi = 0; vi < maxRows; ++vi) {
    int i = _qsScroll + vi;
    if (i >= total) break;
    int y = y0 + vi * rowH;
    dsp.setTextColor(config.theme.title1, config.theme.background);
    dsp.setCursor(x0, y);
    dsp.print(toggles[i].label);
    const char* st = (*toggles[i].ptr) ? "ON" : "OFF";
    uint16_t bg = (*toggles[i].ptr) ? config.theme.volbarin : config.theme.metabg;
    _drawBtn(dsp.width() - 120, y - 12, 90, 34, st, config.theme.meta, bg);
  }

  _drawBtn(10, dsp.height() - 50, 140, 40, "<- Vissza", config.theme.meta, config.theme.metabg);
}

void Display::drawQuickSettings() {
  if (_mode == QUICKSETTINGS) _drawQuickSettings();
}

void Display::scrollQuickSettings(int delta) {
  // A teljes sor számát a rajzoló függvény is számolja, de itt egyszerű maximumot adunk.
  // A valós maxScroll-t _drawQuickSettings clippeli.
  _qsScroll += delta;
  if (_qsScroll < 0) _qsScroll = 0;
}

void Display::_station() {
  #if TFT_WEB_SKIN
    // Új UI: mindent a WebUiWidget rajzol (ne nyúljunk a régi meta/title widgetekhez).
    if (_webui) _webui->requestRedraw();
    return;
  #endif
  _meta->setAlign(metaConf.widget.align);

  // Egységes felső sor (külön "oldal" érzet módonként)
  #ifdef USE_DLNA
  if (config.getMode() == PM_WEB && config.store.playlistSource == PL_SRC_DLNA) {
    _meta->setText("YanO-Radió  |  DLNA-Player");
    return;
  }
  #endif
  #ifdef USE_SD
  if (config.getMode() == PM_SDCARD) {
    _meta->setText("YanO-Radió  |  SD-Player");
    return;
  }
  #endif
  // WEB rádió
  _meta->setText("YanO-Radió  |  Rádió");
  // Az állomás neve/title továbbra is a cím sorokban látszik.
  return;

  // (régi logika: meta = állomásnév)
  // Ez most tudatosan nem fut le, mert a felső sort mód felirattá tettük.

  /*#ifdef USE_NEXTION
  nextion.newNameset(config.station.name);
  nextion.bitrate(config.station.bitrate);
  nextion.bitratePic(ICON_NA);
#endif*/
}

char *split(char *str, const char *delim) {
  char *dmp = strstr(str, delim);
  if (dmp == NULL) {
    return NULL;
  }
  *dmp = '\0';
  return dmp + strlen(delim);
}

void Display::_title() {
  #if TFT_WEB_SKIN
    if (_webui) _webui->requestRedraw();
    return;
  #endif
  // Ha üres a title, használja a playlistben tárolt nevet.
  if (strlen(config.station.title) == 0) {
    strlcpy(config.station.title, config.station.name, sizeof(config.station.title));
  }
  if (strlen(config.station.title) > 0) {
    char tmpbuf[strlen(config.station.title) + 1];
    strlcpy(tmpbuf, config.station.title, sizeof(tmpbuf));
    char *stitle = split(tmpbuf, " - ");
    if (stitle && _title2) {
      _title1->setText(tmpbuf);
      _title2->setText(stitle);
    } else {
      _title1->setText(config.station.title);
      if (_title2) {
        _title2->setText("");
      }
    }
  } else {
    _title1->setText("");
    if (_title2) {
      _title2->setText("");
    }
  }
  if (player_on_track_change) {
    player_on_track_change();
  }
  pm.on_track_change();
}

void Display::_time(bool redraw) {

  #if LIGHT_SENSOR != 255
  if (config.store.dspon) {
    config.store.brightness = AUTOBACKLIGHT(analogRead(LIGHT_SENSOR));
    config.setBrightness();
  }
  #endif
  /*if (config.isScreensaver && network.timeinfo.tm_sec % 60 == 0) {
  #if TIME_SIZE < 19
    uint16_t ft = static_cast<uint16_t>(random(TFT_FRAMEWDT, (dsp.height() - TIME_SIZE * CHARHEIGHT - TFT_FRAMEWDT)));
  #else
    uint16_t ft = static_cast<uint16_t>(random(TFT_FRAMEWDT + TIME_SIZE, (dsp.height() - _clock->dateSize() - TFT_FRAMEWDT * 2)));
  #endif
    uint16_t lt = static_cast<uint16_t>(random(TFT_FRAMEWDT, (dsp.width() - _clock->clockWidth() - TFT_FRAMEWDT)));
    if (clockConf.align == WA_CENTER) {
      lt -= (dsp.width() - _clock->clockWidth()) / 2;
    }
    //_clock->moveTo({clockConf.left, ft, 0});
    _clock->moveTo({lt, ft, 0});
  }
  _clock->draw(redraw);
  //#ifdef USE_NEXTION
    nextion.printClock(network.timeinfo);
  #endif*/
  _clock->moveTo({300, 300, 0});
}

void Display::_volume() {
  #if TFT_WEB_SKIN
    if (_webui) _webui->requestRedraw();
    return;
  #endif
  if (_volbar) {  // Módosítás "vol_step"
    int vol = (config.store.volume);
    if (vol > 100) {
      vol = 100;
    }
    if (vol < 0) {
      vol = 0;
    }
    _volbar->setValue(vol);
  }
  #ifndef HIDE_VOL
  if (_voltxt) {                                       // ha az alapképernyő van
    _voltxt->setText(config.store.volume, voltxtFmt);  // Módosítás "vol_step"
  }
  #endif
  if (_mode == VOL) {
    timekeeper.waitAndReturnPlayer(2);
    _nums->setText(config.store.volume, numtxtFmt);
  }
  /*#ifdef USE_NEXTION
    nextion.setVol(config.store.volume, _mode == VOL);
  #endif*/
}

void Display::flip() {
  dsp.flip();
}

void Display::invert() {
  dsp.invert();
}

void Display::setContrast() {
  #if DSP_MODEL == DSP_NOKIA5110
  dsp.setContrast(config.store.contrast);
  #endif
}

bool Display::deepsleep() {
  #if defined(LCD_I2C) || defined(DSP_OLED) || BRIGHTNESS_PIN != 255
  dsp.sleep();
  return true;
  #endif
  return false;
}

void Display::wakeup() {
  #if defined(LCD_I2C) || defined(DSP_OLED) || BRIGHTNESS_PIN != 255
  dsp.wake();
  #endif
}
//============================================================================================================================
#else  // !DUMMYDISPLAY
//============================================================================================================================
void Display::init() {
  _createDspTask();
  #ifdef USE_NEXTION
  nextion.begin(true);
  #endif
}
void Display::_start() {
  #ifdef USE_NEXTION
  //nextion.putcmd("page player");
  nextion.start();
  #endif
  config.setTitle(LANG::const_PlReady);
}

void Display::putRequest(displayRequestType_e type, int payload) {
  if (type == DSP_START) {
    _start();
  }
  #ifdef USE_NEXTION
  requestParams_t request;
  request.type = type;
  request.payload = payload;
  nextion.putRequest(request);
  #else
  if (type == NEWMODE) {
    mode((displayMode_e)payload);
  }
  #endif
}
//============================================================================================================================
#endif  // DUMMYDISPLAY