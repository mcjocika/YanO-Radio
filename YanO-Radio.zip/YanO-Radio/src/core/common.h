#ifndef COMMON_H
#define COMMON_H
#pragma once

// Megjegyzés: új képernyők a végére kerülnek, hogy a meglévő módok sorszáma ne változzon.
enum displayMode_e { PLAYER, VOL, STATIONS, PRESETS, NUMBERS, LOST, UPDATING, INFO, SETTINGS, TIMEZONE, WIFI, CLEAR, SLEEPING, SDCHANGE, SCREENSAVER, SCREENBLANK, EQSCREEN, QUICKSETTINGS,
  // TFT DLNA Browser UI (külön oldal)
  DLNAUI
}; // "presets"

enum pages_e      : uint8_t  { PG_PLAYER=0, PG_DIALOG=1, PG_PLAYLIST=2, PG_SCREENSAVER=3, PG_PRESETS=4,
  // DLNA TFT UI oldal
  PG_DLNA=5
}; // "presets"

// Megjegyzés: új request típusokat a végére tegyünk.
enum displayRequestType_e { BOOTSTRING, NEWMODE, CLOCK, NEWTITLE, NEWSTATION, NEXTSTATION, DRAWPLAYLIST, CLOSEPLAYLIST, DRAWVOL, DBITRATE, AUDIOINFO, SHOWVUMETER, DSPRSSI, SHOWWEATHER, NEWWEATHER, PSTOP, PSTART, DSP_START, WAITFORSD, SDFILEINDEX, NEWIP, NOPE, CLEARALLBITRATE,
  // TFT_WEB_SKIN: gomb esemény a WebUiWidget-ből (payload = WebUiBtn)
  WEBUIBTN
};
struct requestParams_t
{
  displayRequestType_e type;
  int payload;
};

enum controlEvt_e { EVT_NONE=255, EVT_BTNLEFT=0, EVT_BTNCENTER=1, EVT_BTNRIGHT=2, EVT_ENCBTNB=3, EVT_BTNUP=4, EVT_BTNDOWN=5, EVT_ENC2BTNB=6, EVT_BTNMODE=7 };



#endif
