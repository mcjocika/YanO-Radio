#pragma once

#include <Arduino.h>

// Hungarian-capable 5x7 font table (256 glyphs, 5 bytes per glyph).
// This is based on the user's uploaded glcdfont.c ("Standard ASCII + hungarian 5x7 font by Lucza Gyuri").
extern const unsigned char hu_glcdfont[] PROGMEM;

// Map a UTF-8 sequence to an ISO-8859-2 (Latin-2) 8-bit code that matches hu_glcdfont.
// Sets *consumed to 1 or 2.
uint8_t hu_map_utf8_latin2(const char* s, uint8_t* consumed);
