#include "../core/options.h"
#ifdef USE_DLNA

#include "dlna_desc.h"
#include "dlna_http_guard.h"

#include <WiFiClient.h>
#include <HTTPClient.h>

static bool extractControlUrlFromXml(const String& xml, String& outControlPath) {
  outControlPath = "";

  const char* svcType = "urn:schemas-upnp-org:service:ContentDirectory:1";
  int st = xml.indexOf(svcType);
  if (st < 0) return false;

  // keressük meg a service blokk elejét/végét a serviceType körül
  int svcStart = xml.lastIndexOf("<service", st);
  int svcEnd   = xml.indexOf("</service>", st);
  if (svcStart < 0 || svcEnd < 0 || svcEnd <= svcStart) return false;

  String svc = xml.substring(svcStart, svcEnd);

  int a = svc.indexOf("<controlURL>");
  int b = svc.indexOf("</controlURL>");
  if (a < 0 || b < 0 || b <= a) return false;

  a += 12;
  outControlPath = svc.substring(a, b);
  outControlPath.trim();
  return outControlPath.length() > 0;

  // DLNA szerverek néha HTML entity-t/whitespace-t raknak bele
  // (itt csak trimmelünk; ha kell, később bővíthető)
  return outControlPath.length() > 0;
}

bool DlnaDescription::resolveControlURL(const String& descUrl, String& outControlUrl) {
  outControlUrl = "";

  HTTPClient http;
  WiFiClient client;

  log_i("[DLNA] GET %s\n", descUrl.c_str());

  // Globális DLNA HTTP lock (nálad ez fontos, mert több helyről is jöhet HTTP)
  DlnaHttpGuard lock;

  // Rövid timeoutok: ha egy szerver “megáll”, ne blokkoljuk a core-t
  client.setTimeout(5000);
  http.setTimeout(5000);

  if (!http.begin(client, descUrl)) {
    log_i("%s", String("[DLNA] HTTP begin failed").c_str());
    return false;
  }

  int code = http.GET();
  if (code != HTTP_CODE_OK) {
    log_i("[DLNA] HTTP error: %d\n", code);
    http.end();
    return false;
  }

  // Tiszta megoldás: teljes XML beolvasása stringbe (rootDesc.xml általában kicsi)
  String xml = http.getString();
  http.end();

  if (xml.length() == 0) {
    log_i("%s", String("[DLNA] Empty rootDesc.xml").c_str());
    return false;
  }

  String controlPath;
  if (!extractControlUrlFromXml(xml, controlPath)) {
    log_i("%s", String("[DLNA] ContentDirectory not found").c_str());
    return false;
  }

  String base = extractBaseUrl(descUrl);
  outControlUrl = base + controlPath;

  return true;
}

// Meghagyom kompatibilitás miatt (ha a headerben deklarálva van), de javítva:
// - NEM a s.available() vezérli a ciklust (hálózaton az félrevezető)
// - Van timeout + yield, hogy ne éheztesse az IDLE-t
bool DlnaDescription::parseStream(Stream& s, String& outControlPath) {
  outControlPath = "";

  bool inService = false;
  bool isContentDir = false;

  String line;

  const uint32_t start = millis();
  const uint32_t hardTimeoutMs = 2000;

  while ((millis() - start) < hardTimeoutMs) {
    // Ha van adat, olvasunk; ha nincs, yieldelünk
    if (s.available() > 0) {
      line = s.readStringUntil('\n');
      line.trim();

      if (line.indexOf("<service>") >= 0) {
        inService = true;
        isContentDir = false;
      }

      if (inService &&
          line.indexOf("<serviceType>urn:schemas-upnp-org:service:ContentDirectory:1</serviceType>") >= 0) {
        isContentDir = true;
      }

      if (inService && isContentDir && line.indexOf("<controlURL>") >= 0) {
        int a = line.indexOf("<controlURL>") + 12;
        int b = line.indexOf("</controlURL>");
        if (b > a) {
          outControlPath = line.substring(a, b);
          outControlPath.trim();
          return outControlPath.length() > 0;
        }
      }

      if (line.indexOf("</service>") >= 0) {
        inService = false;
        isContentDir = false;
      }
    } else {
      // fontos: ne blokkoljon CPU0-n
      delay(1);
    }
  }

  return false;
}

String DlnaDescription::extractBaseUrl(const String& fullUrl) {
  // http://IP:PORT/desc/device.xml → http://IP:PORT
  int idx = fullUrl.indexOf('/', 8); // 8 = after http://
  if (idx > 0) return fullUrl.substring(0, idx);
  return fullUrl;
}

#endif // USE_DLNA