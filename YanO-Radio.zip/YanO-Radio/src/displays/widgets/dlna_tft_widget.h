// DLNA TFT Browser UI (SoapDLNA)
// -----------------------------------------------------------------------------
// Külön TFT oldal: DLNA szerver keresés + szerverlista + böngészés + lejátszás.
// Nem blokkoló UI: scan státuszt pollingolja, browse-t külön task végzi.

#pragma once

#include <Arduino.h>

// DSP_MODEL / DSP_DUMMY macros live here.
#include "../../core/options.h"

// Pull in the concrete display driver types (yoDisplay, Canvas, Adafruit_GFX, etc.)
// before widgets.h is included. widgets.h assumes these exist for LCD builds.
#include "../dspcore.h"

#include "widgets.h"

#include <vector>


class DlnaTftWidget : public Widget {
public:
  using Widget::init;

  void begin();
  void onEnter();
  void onExit();
  void onTouch(uint16_t x, uint16_t y);
  // Rotary / physical buttons (controls.cpp routes events when DLNAUI is active)
  void onKey(int evt);

  void loop() override;

private:
  // Browse worker task írhatja a belső buffer-eket.
  friend void dlnaBrowseTask(void* pv);

  enum UiState : uint8_t {
    ST_ENTER = 0,
    ST_SEARCHING,
    ST_SERVERS,
    ST_LOADING,
    ST_BROWSING,
    ST_NO_SERVER,
    ST_ERROR,
  };

  struct Server {
    uint16_t idx = 0;
    String name;
    String addr;
  };

  struct Item {
    String id;
    String parentId;
    String title;
    bool isContainer = false;
    String url;
  };

  struct Level {
    String objectId;
    String title;
    std::vector<Item> items;
    int scroll = 0;
  };

  UiState _state = ST_ENTER;
  uint32_t _stateAt = 0;

  // scan
  bool _scanStarted = false;
  uint32_t _scanStartMs = 0;
  String _status;
  std::vector<Server> _servers;
  int _serverSel = 0;
  int _serverScroll = 0;

  // redraw throttling / flicker reduction
  bool _dirtyFull = true;
  bool _dirtyBody = true;
  uint32_t _lastBodyDrawMs = 0;

  // browse
  std::vector<Level> _stack;
  int _cursor = 0;
  volatile bool _browseDone = false;
  volatile bool _browseOk = false;
  String _browseJson;
  String _browseErr;

  // thread-safety: worker task <-> UI
  SemaphoreHandle_t _mx = nullptr;

  // touch: double-tap on same item
  int _lastTapIndex = -1;
  uint32_t _lastTapMs = 0;


  // UI constants
  // Slightly taller header for a centered "DLNA" title.
  uint16_t _hdrH = 24;
  // A bit more row height for readability.
  uint16_t _rowH = 16;
  uint16_t _pad = 4;

  // helpers
  void _setState(UiState s, const String& status = "");
  void _draw() override;
  void _clear() override;

  void _drawHeader();
  void _drawBody();
  void _drawCentered(const String& line1, const String& line2 = "");

  void _markDirtyBody();
  void _markDirtyFull();

  bool _touchHeader(uint16_t x, uint16_t y);
  void _startScan();
  void _pollScan();
  void _fetchServersFromJson(const String& json);

  void _startBrowse(uint16_t sid, const String& objectId, const String& title);
  void _pollBrowse();
  void _applyBrowseJson(const String& json, const String& title);

  int _visibleRows() const;
  void _clampCursor();

  // selection helpers
  void _serversMove(int delta);
  void _browseMove(int delta);
  void _selectCurrent();
  void _goBack();
};

