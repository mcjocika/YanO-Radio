// ampguard.h
// -----------------------------------------------------------------------------
// yoRadio – Erősítő + hangfalvédő (SPKRS_RELAY) kiszervezett logika
//
// Cél:
//  - A PWR_AMP és SPKRS_RELAY pin-eket kizárólag ebben a modulban kezeljük.
//  - Player / TimeKeeper csak hívja a modul függvényeit.
//  - A beállítások (engedélyezés, késleltetések) a Config::store-ból jönnek.
//
// Megjegyzés:
//  A logika jelenleg a projektben lévő (már működő) állapotgépet tükrözi.
//  Később ezen könnyű lesz finomítani anélkül, hogy a player/timekeeper szétcsúszna.
// -----------------------------------------------------------------------------

#pragma once

#include <stdint.h>

namespace ampguard {

// Egyszeri init: pinMode + biztonságos alapállapot.
void begin();

// Player oldali, gyakori hívás (pl. Player::loop / setOutputPins)
// isPlaying: a lejátszó állapota
// volume: 0..100
// muteLock: külső mute flag (ha van), különben false
void updatePlayer(bool isPlaying, uint8_t volume, bool muteLock);

// UI / TimeKeeper oldali hívás: screensaver/blank váltások és szekvencia.
// ssActive: display.mode() alapján (SCREENSAVER vagy SCREENBLANK)
// playingNow: player.isRunning()
void updateUi(bool ssActive, bool playingNow);

// Azonnali kényszerített némítás (pl. kritikus hibánál / stopnál).
void forceMute();

// Helper: képernyővédő állapotváltás esetén érdemes reszetelni az időzítőket.
void reset();

} // namespace ampguard
