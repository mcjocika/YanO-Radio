#ifndef _my_theme_h
#define _my_theme_h

#define ENABLE_THEME
#ifdef  ENABLE_THEME
// clang-format off
/*                               R    G    B  */
/*----- SCREEN -----*/
#define COLOR_BACKGROUND         10,  10,  10

/*----- META -----*/
// "Green / gray" harmónia (a jelölt mintaképed alapján)
// - háttér: sötét szürke-fekete
// - fejléc: világos zöld-szürke
// - kiemelések: zöld
// - szöveg: fehér / világos szürke
#define COLOR_STATION_NAME        0,   0,   0   // fekete felirat a világos fejlécen
#define COLOR_STATION_BG        170, 205, 170   // fejléc sáv: "menta" zöld-szürke
#define COLOR_STATION_FILL       80, 140,  80   // kiemelés / vonal
#define COLOR_SNG_TITLE_1       235, 235, 235   // fő cím: világos szürke
#define COLOR_SNG_TITLE_2       120, 200, 120   // másodlagos: zöldes
#define COLOR_BITRATE           170, 205, 170

/*----- WEATHER -----*/
#define COLOR_WEATHER           235, 235, 235

/*---- VOLUME SCREEN -----*/
#define COLOR_DIGITS            235, 235, 235

/*----- NAMEDAY -----*/
#define COLOR_NAMEDAY           235, 235, 235

/*----- CLOCK, DATE -----*/
#define COLOR_CLOCK             235, 235, 235
#define COLOR_CLOCK_BG            0,   0,   0
#define COLOR_SECONDS           120, 200, 120
#define COLOR_DIVIDER            80, 140,  80
#define COLOR_DATE              235, 235, 235

/*----- VU WIDGET ----*/
#define COLOR_VU_MAX             90, 220,  90
#define COLOR_VU_MID             60, 170,  60
#define COLOR_VU_MIN             35,  80,  35

/*----- FOOTER -----*/
#define COLOR_VOLBAR_OUT         80, 140,  80
#define COLOR_VOLBAR_IN         120, 200, 120
#define COLOR_VOLUME_VALUE      235, 235, 235
#define COLOR_IP                170, 205, 170
#define COLOR_CH                170, 205, 170
#define COLOR_RSSI              170, 205, 170
#define COLOR_HEAP               40,  60,  75
#define COLOR_BUFFER             50,  80, 110

/*----- PLAYLIST -----*/
#ifdef PLAYLIST_SCROLL_MOVING_CURSOR
    #define COLOR_PL_CURRENT        255, 255, 255
    #define COLOR_PL_CURRENT_BG       0,   0,   0
    #define COLOR_PL_CURRENT_FILL     0,   0,   0
    #define COLOR_PLAYLIST_0        165, 165, 165
    #define COLOR_PLAYLIST_1        165, 165, 165
    #define COLOR_PLAYLIST_2        165, 165, 165
    #define COLOR_PLAYLIST_3        165, 165, 165
    #define COLOR_PLAYLIST_4        165, 165, 165
#else
    #define COLOR_PL_CURRENT        255, 255, 255
    #define COLOR_PL_CURRENT_BG      10,  10,  10
    #define COLOR_PL_CURRENT_FILL    10,  10,  10
    #define COLOR_PLAYLIST_0        115, 115, 115
    #define COLOR_PLAYLIST_1         89,  89,  89
    #define COLOR_PLAYLIST_2         56,  56,  56
    #define COLOR_PLAYLIST_3         35,  35,  35
    #define COLOR_PLAYLIST_4         25,  25,  25
#endif

/*----- PRESETS -----*/
#define COLOR_PRST_BUTTON        21,  21,  21  // "presets" buttons background
#define COLOR_PRST_CARD          21,  21,  21  // "presets" kards
#define COLOR_PRST_ACCENT        50,  50,  50
#define COLOR_PRST_FAV          255, 255, 255
#define COLOR_PRST_TITLE_1      255, 255, 255
#define COLOR_PRST_TITLE_2      200, 200, 200
#define COLOR_PRST_TITLE_3      150, 150, 150
#define COLOR_PRST_LINE         162, 162, 162
#endif  /* #ifdef  ENABLE_THEME */
#endif  /* #define _my_theme_h  */