#pragma once

#include <Arduino.h>
#include <WiFi.h>
#include <math.h>

#include "widgets.h"
#include "../tools/commongfx.h"  // extern DspCore dsp
#include "webui_icons.h"
#include "webui_navicons.h"
#include "webui_ctrlicons.h"
// (removed) hu_glcdfont Hungarian font support
#include "../../core/config.h"
#include "../../core/player.h"
#include "../../core/network.h"

#include "webui_btns.h"

// Minimal, stabil (nem dupláz widgetet) "web" jellegű UI.
// A teljes képernyőt rajzolja: fejléc + status + 2 sor gomb.
//
// Flicker csökkentés:
// - statikus elemeket egyszer rajzolunk (háttér + gombok kerete)
// - dinamikus részeket (cím/meta/státusz/kiemelések) kis téglalapokban frissítjük
class WebUiWidget : public Widget {
public:
  WebUiWidget() = default;
  ~WebUiWidget() override = default;

  void init(WidgetConfig conf, uint16_t fgcolor, uint16_t bgcolor) override {
    Widget::init(conf, fgcolor, bgcolor);
    _dirty = true;
    _staticDrawn = false;
    _firstPaint = true;
    _lastMode = 0xFF;
    _lastVol = 0xFFFF;
    _lastRssi = 0x7FFF;
    _lastPlaying = 0xFF;
    _lastModeRedraw = 0xFF;
    _lastPlayRedraw = 0xFF;
    _lastName = "";
    _lastTitle = "";
    _lastIp = "";
  }

  void loop() override {
    if (_active && !_locked && _dirty) {
      if (_firstPaint) {
        _staticDrawn = false;
        _lastModeRedraw = 0xFF;
        _lastPlayRedraw = 0xFF;
      }
      _draw();
      _dirty = false;
      _firstPaint = false;
    }
  }

  void requestRedraw(bool full = false) {
    if (full) { _staticDrawn = false; _firstPaint = true; _lastModeRedraw = 0xFF; _lastPlayRedraw = 0xFF; }
    _dirty = true;
  }

  WebUiBtn hitTest(uint16_t x, uint16_t y) const {
    const uint16_t W = dsp.width();
    const uint16_t H = dsp.height();

    const uint16_t pad = 8;
    const uint16_t gap = 8;
    const uint16_t btnH = (H >= 240) ? 44 : 34;
    const uint16_t row2Top = H - pad - btnH;
    const uint16_t row1Top = row2Top - gap - btnH;

    if (y >= row1Top && y < row1Top + btnH) {
      // 5 gomb: Radio SD DLNA EQ Settings
      const uint16_t n = 5;
      const uint16_t bw = (W - 2 * pad - (n - 1) * gap) / n;
      if (x < pad || x >= W - pad) return WebUiBtn::NONE;
      uint16_t idx = (x - pad) / (bw + gap);
      uint16_t lx = pad + idx * (bw + gap);
      if (x >= lx + bw) return WebUiBtn::NONE;
      switch (idx) {
        case 0: return WebUiBtn::RADIO;
        case 1: return WebUiBtn::SD;
        case 2: return WebUiBtn::DLNA;
        case 3: return WebUiBtn::EQ;
        case 4: return WebUiBtn::SETTINGS;
        default: return WebUiBtn::NONE;
      }
    }

    if (y >= row2Top && y < row2Top + btnH) {
      // 4 gomb: Prev Play Stop Next
      const uint16_t n = 4;
      const uint16_t bw = (W - 2 * pad - (n - 1) * gap) / n;
      if (x < pad || x >= W - pad) return WebUiBtn::NONE;
      uint16_t idx = (x - pad) / (bw + gap);
      uint16_t lx = pad + idx * (bw + gap);
      if (x >= lx + bw) return WebUiBtn::NONE;
      switch (idx) {
        case 0: return WebUiBtn::PREV;
        case 1: return WebUiBtn::PLAYPAUSE;
        case 2: return WebUiBtn::STOP;
        case 3: return WebUiBtn::NEXT;
        default: return WebUiBtn::NONE;
      }
    }

    return WebUiBtn::NONE;
  }

protected:
  void _clear() override {
    dsp.fillRect(_config.left, _config.top, dsp.width(), dsp.height(), _bgcolor);
  }

  static inline uint16_t rgb565(uint8_t r, uint8_t g, uint8_t b) {
    return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
  }

  static inline uint16_t lighten(uint16_t c, uint8_t amt) {
    // amt: 0..255
    uint8_t r = (c >> 8) & 0xF8;
    uint8_t g = (c >> 3) & 0xFC;
    uint8_t b = (c << 3) & 0xF8;
    auto add = [&](uint8_t v, uint8_t maxv) {
      uint16_t nv = v + ((uint16_t)(maxv - v) * amt) / 255;
      return (uint8_t)nv;
    };
    return rgb565(add(r, 0xF8), add(g, 0xFC), add(b, 0xF8));
  }

  static inline uint16_t darken(uint16_t c, uint8_t amt) {
    uint8_t r = (c >> 8) & 0xF8;
    uint8_t g = (c >> 3) & 0xFC;
    uint8_t b = (c << 3) & 0xF8;
    auto sub = [&](uint8_t v) {
      uint16_t nv = (uint16_t)v - ((uint16_t)v * amt) / 255;
      return (uint8_t)nv;
    };
    return rgb565(sub(r), sub(g), sub(b));
  }

  void drawBtnShell(int16_t, int16_t, int16_t, int16_t, uint16_t, bool=false) { /* no background */ }

  void drawBtnLabel(int16_t x, int16_t y, int16_t w, int16_t h, const char* label, uint16_t bg) {
    if (!label) return;
    // Ensure UTF-8 strings (e.g. Hungarian accents) render correctly on TFT by
    // converting to the display's single-byte charset (used on playlist screens).
    const char* out = utf8To(label, false);
    dsp.setTextColor(0xFFFF, bg);
    dsp.setTextSize(1);
    int16_t tw = (int16_t)strlen(out) * 6;
    int16_t tx = x + (w - tw) / 2;
    if (tx < x + 6) tx = x + 6;
    int16_t ty = y + (h/2) - 4;
    dsp.setCursor(tx, ty);
    dsp.print(out);
  }

  void drawIconCenteredRGB565(int16_t x, int16_t y, int16_t w, int16_t h,
                             const uint16_t* icon, uint16_t iw, uint16_t ih) {
    int16_t ix = x + (w - (int16_t)iw) / 2;
    int16_t iy = y + (h - (int16_t)ih) / 2;
    dsp.drawRGBBitmap(ix, iy, icon, iw, ih);
  }

  // RGB565 ikon kirajzolás "kulcsszín" (általában fekete) áttetszőséggel.
  // Kicsi ikonokhoz (24x24) elég gyors, és nem kell külön maszk.
  // NOTE: arrays are stored as native RGB565 (no byte-swap).
  // We fix it here by swapping bytes for every pixel.
  void drawRGBBitmapKey(int16_t x, int16_t y, const uint16_t* icon, uint16_t iw, uint16_t ih, uint16_t key = 0x0000) {
    for (uint16_t yy = 0; yy < ih; ++yy) {
      for (uint16_t xx = 0; xx < iw; ++xx) {
        uint16_t c = pgm_read_word(icon + yy * iw + xx);
        if (c != key) {
          dsp.drawPixel(x + xx, y + yy, c);
        }
      }
    }
  }

  #if 0
  // ---- 5x7 font (hu_glcdfont) drawing helpers ----
  void drawChar5x7(int16_t x, int16_t y, uint8_t code, uint16_t col, uint16_t bg, uint8_t scale = 1) {
    // 5 columns, 7 rows, 1px spacing
    const uint8_t* base = hu_glcdfont + (uint16_t)code * 5;
    for (uint8_t cx = 0; cx < 5; ++cx) {
      uint8_t bits = pgm_read_byte(base + cx);
      for (uint8_t cy = 0; cy < 7; ++cy) {
        bool on = bits & (1 << cy);
        uint16_t c = on ? col : bg;
        if (scale == 1) {
          dsp.drawPixel(x + cx, y + cy, c);
        } else {
          dsp.fillRect(x + cx * scale, y + cy * scale, scale, scale, c);
        }
      }
    }
    // spacing column
    if (bg != 0xFFFF) {
      if (scale == 1) {
        dsp.drawFastVLine(x + 5, y, 7, bg);
      } else {
        dsp.fillRect(x + 5 * scale, y, scale, 7 * scale, bg);
      }
    }
  }

  #endif // 0

  // (removed) Hungarian UTF-8 drawing helpers

  // Standard vezérlő ikonok (bitmap alapú)
  void drawCtrlSymbol(WebUiBtn btn, int16_t x, int16_t y, int16_t w, int16_t h, uint16_t) {
    const uint16_t* bmp = nullptr;
    uint16_t bw = 0, bh = 0;

    switch (btn) {
      case WebUiBtn::PREV:      bmp = webui_ctrl_prev;      bw = webui_ctrl_prev_w;      bh = webui_ctrl_prev_h;      break;
      case WebUiBtn::STOP:      bmp = webui_ctrl_stop;      bw = webui_ctrl_stop_w;      bh = webui_ctrl_stop_h;      break;
      case WebUiBtn::NEXT:      bmp = webui_ctrl_next;      bw = webui_ctrl_next_w;      bh = webui_ctrl_next_h;      break;
      case WebUiBtn::PLAYPAUSE: {
        const bool playing = (player.status() == PLAYING);
        bmp = playing ? webui_ctrl_pause : webui_ctrl_play;
        bw  = playing ? webui_ctrl_pause_w : webui_ctrl_play_w;
        bh  = playing ? webui_ctrl_pause_h : webui_ctrl_play_h;
      } break;
      default: break;
    }

    if (!bmp || bw == 0 || bh == 0) return;
    const int16_t ix = x + (w - (int16_t)bw) / 2;
    const int16_t iy = y + (h - (int16_t)bh) / 2;
    drawRGBBitmapKey(ix, iy, bmp, bw, bh, 0x0000);
  }

  // Felső (mód) ikonok – a feltöltött, szép bitmapek
  void drawNavIconBmp(WebUiBtn btn, int16_t x, int16_t y, int16_t w, int16_t h) {
    switch (btn) {
      case WebUiBtn::RADIO:
        drawRGBBitmapKey(x + (w - (int)webui_nav_radio_w) / 2, y + (h - (int)webui_nav_radio_h) / 2,
                         webui_nav_radio, webui_nav_radio_w, webui_nav_radio_h, 0x0000);
        break;
      case WebUiBtn::SD:
        drawRGBBitmapKey(x + (w - (int)webui_nav_sd_w) / 2, y + (h - (int)webui_nav_sd_h) / 2,
                         webui_nav_sd, webui_nav_sd_w, webui_nav_sd_h, 0x0000);
        break;
      case WebUiBtn::DLNA:
        drawRGBBitmapKey(x + (w - (int)webui_nav_dlna_w) / 2, y + (h - (int)webui_nav_dlna_h) / 2,
                         webui_nav_dlna, webui_nav_dlna_w, webui_nav_dlna_h, 0x0000);
        break;
      case WebUiBtn::EQ:
        drawRGBBitmapKey(x + (w - (int)webui_nav_eq_w) / 2, y + (h - (int)webui_nav_eq_h) / 2,
                         webui_nav_eq, webui_nav_eq_w, webui_nav_eq_h, 0x0000);
        break;
      case WebUiBtn::SETTINGS:
        drawRGBBitmapKey(x + (w - (int)webui_nav_settings_w) / 2, y + (h - (int)webui_nav_settings_h) / 2,
                         webui_nav_settings, webui_nav_settings_w, webui_nav_settings_h, 0x0000);
        break;
      default:
        break;
    }
  }

  void drawWrappedText(int16_t x, int16_t y, int16_t w, const char* txt, uint8_t size, uint16_t fg, uint16_t bg, uint8_t maxLines) {
    if (!txt || !*txt) return;
    dsp.setTextSize(size);
    dsp.setTextColor(fg, bg);

    const int charW = 6 * size;
    const int maxChars = (w / charW);
    if (maxChars <= 0) return;

    String s(txt);
    s.trim();
    int line = 0;
    while (s.length() && line < (int)maxLines) {
      int cut = s.length();
      if (cut > maxChars) {
        cut = maxChars;
        int sp = s.lastIndexOf(' ', cut);
        if (sp > 8) cut = sp;
      }
      String part = s.substring(0, cut);
      part.trim();
      dsp.setCursor(x, y + line * (10 * size));
      dsp.print(part);
      s.remove(0, cut);
      s.trim();
      line++;
    }
  }

  // Compatibility wrapper kept to minimize code changes.
  // Convert UTF-8 to the display's single-byte charset so Hungarian accents are
  // rendered the same way as on the playlist screen.
  void drawWrappedTextHU(int16_t x, int16_t y, int16_t w, const char* txt, uint8_t scale, uint16_t fg, uint16_t bg, uint8_t maxLines) {
    if (!txt || !*txt) return;
    const char* out = utf8To(txt, false);
    drawWrappedText(x, y, w, out, scale, fg, bg, maxLines);
  }

  uint8_t modeId() const {
    if (config.getMode() == PM_SDCARD) return 1;
    if (config.getMode() == PM_WEB && config.store.playlistSource == PL_SRC_DLNA) return 2;
    return 0; // RADIO
  }

  void _draw() override {
    const uint16_t W = dsp.width();
    const uint16_t H = dsp.height();

    const uint16_t pad = 8;
    const uint16_t gap = 8;
    const uint16_t btnH = (H >= 240) ? 44 : 34;
    const uint16_t row2Top = H - pad - btnH;
    const uint16_t row1Top = row2Top - gap - btnH;

	    // Status sor ikonokkal: az ikonok 28px magasak, ezért adjunk elég sáv-magasságot,
	    // különben belógnak a gombok területére és átfedést okoznak.
	    const uint16_t statusH   = 30;
	    const uint16_t statusGap = 6;
	    const int16_t  statusTop = (int16_t)row1Top - (int16_t)statusH - (int16_t)statusGap;

    // Színek (RGB565) – webes hangulat: kék+zöld+narancs+lila+szürke
    const uint16_t cRadio = rgb565( 40, 140, 255);
    const uint16_t cSD    = rgb565(255, 160,  40);
    const uint16_t cDLNA  = rgb565(120, 220, 120);
    const uint16_t cEQ    = rgb565(200, 120, 255);
    const uint16_t cSet   = rgb565(160, 160, 160);

    const uint16_t cCtrl  = rgb565( 90, 160, 255);
    const uint16_t cPlay  = rgb565( 80, 220, 120);
    const uint16_t cStop  = rgb565(255, 100, 100);

    // Statikus: háttér + fejléc cím + gombok alapja
    if (!_staticDrawn) {
      dsp.fillRect(0, 0, W, H, _bgcolor);

      // Fejléc fix cím
      dsp.setTextSize(1);
      dsp.setTextColor(_fgcolor, _bgcolor);
      dsp.setCursor(8, 6);
      dsp.print("YanO-Radio");
      // elválasztó
      dsp.drawFastHLine(0, 20, W, darken(_fgcolor, 150));

      // Row1 shells
      {
        const uint16_t n = 5;
        const uint16_t bw = (W - 2*pad - (n-1)*gap) / n;
        int16_t x = pad;
        drawBtnShell(x, row1Top, bw, btnH, cRadio); x += bw + gap;
        drawBtnShell(x, row1Top, bw, btnH, cSD);    x += bw + gap;
        drawBtnShell(x, row1Top, bw, btnH, cDLNA);  x += bw + gap;
        drawBtnShell(x, row1Top, bw, btnH, cEQ);    x += bw + gap;
        drawBtnShell(x, row1Top, bw, btnH, cSet);
      }

      // Row2 shells
      {
        const uint16_t n = 4;
        const uint16_t bw = (W - 2*pad - (n-1)*gap) / n;
        int16_t x = pad;
        drawBtnShell(x, row2Top, bw, btnH, cCtrl); x += bw + gap;
        drawBtnShell(x, row2Top, bw, btnH, cPlay); x += bw + gap;
        drawBtnShell(x, row2Top, bw, btnH, cStop); x += bw + gap;
        drawBtnShell(x, row2Top, bw, btnH, cCtrl);
      }

      _staticDrawn = true;
      // statikus frissítésnél mindent újraírunk
      _lastMode = 0xFF;
      _lastVol = 0xFFFF;
      _lastRssi = 0x7FFF;
      _lastPlaying = 0xFF;
      _lastName = "";
      _lastTitle = "";
      _lastIp = "";
    }

    // Dinamikus értékek
    const uint8_t curMode = modeId();
    const bool curPlaying = (player.status() == PLAYING);
    const uint16_t curVol = (uint16_t)config.store.volume;
    const int16_t curRssi = WiFi.isConnected() ? (int16_t)WiFi.RSSI() : (int16_t)0;
    const String curIp = WiFi.isConnected() ? WiFi.localIP().toString() : String("0.0.0.0");
    const String curName = String(config.station.name);
    const String curTitle = String(config.station.title);

    // 1) Mód felirat jobb felül
    if (curMode != _lastMode) {
      dsp.fillRect(W - 80, 0, 80, 20, _bgcolor);
      dsp.setTextSize(1);
      dsp.setTextColor(_fgcolor, _bgcolor);
      dsp.setCursor(W - 70, 6);
      if (curMode == 1) dsp.print("SD");
      else if (curMode == 2) dsp.print("DLNA");
      else dsp.print("RADIO");
      _lastMode = curMode;
    }

    // 2) Fő tartalom (név + meta) – kis téglalapban törlünk
    const int contentTop = 26;
    const int contentLeft = 8;
    const int contentW = (int)W - 16;
	    // hagyjunk helyet a status sornak (+ kis hézag), különben átfedhet
	    const int contentH = (int)(statusTop - contentTop - 4);

    if (curName != _lastName || curTitle != _lastTitle) {
      dsp.fillRect(contentLeft, contentTop, contentW, contentH, _bgcolor);
      drawWrappedTextHU(contentLeft, contentTop, contentW, config.station.name, 2, _fgcolor, _bgcolor, 2);
      if (config.station.title[0]) {
        drawWrappedTextHU(contentLeft, contentTop + 44, contentW, config.station.title, 1, _fgcolor, _bgcolor, 2);
      }
      _lastName = curName;
      _lastTitle = curTitle;
    }

    // 3) Status sor ikonokkal (IP + Vol + WiFi RSSI)
    //   - csak akkor frissítjük, ha változott valami
	    if (curIp != _lastIp || curVol != _lastVol || curRssi != _lastRssi || curPlaying != (bool)_lastPlaying) {
	      // Teljes status sáv törlése (ikonok beleférnek, nincs átfedés)
	      dsp.fillRect(0, statusTop, W, statusH, _bgcolor);

      dsp.setTextWrap(false);
      dsp.setTextSize(1);
      const int16_t textY = statusTop + (statusH - 8) / 2; // 8px font height @ size1

      int16_t x = 6;
      // IP icon + text
      const int16_t ipY = statusTop + (statusH - (int16_t)webui_icon_ip_h) / 2;
	      dsp.drawRGBBitmap(x, ipY, webui_icon_ip, webui_icon_ip_w, webui_icon_ip_h);
      x += webui_icon_ip_w + 6;
      dsp.setTextColor(rgb565(120, 190, 255), _bgcolor);
	      dsp.setCursor(x, textY);
      dsp.print(curIp);

      // Volume icon + number
      x = W/2 - 40;
      const int16_t volY = statusTop + (statusH - (int16_t)webui_icon_vol_h) / 2;
	      dsp.drawRGBBitmap(x, volY, webui_icon_vol, webui_icon_vol_w, webui_icon_vol_h);
      x += webui_icon_vol_w + 4;
      dsp.setTextColor(rgb565(255, 230, 80), _bgcolor);
	      dsp.setCursor(x, textY);
      dsp.print((int)curVol);

      // WiFi icon + RSSI (no signal bars)
      // jobbra igazítjuk: [wifi] [rssi]
      x = W - ((int)webui_icon_wifi_w + 60);
      // töröljük a teljes jobb oldali blokkot, hogy semmi maradék vonal ne maradjon
      dsp.fillRect(x - 6, statusTop, webui_icon_wifi_w + 70, statusH, _bgcolor);

      const int16_t wifiY = statusTop + (statusH - (int16_t)webui_icon_wifi_h) / 2;
      dsp.drawRGBBitmap(x, wifiY, webui_icon_wifi, webui_icon_wifi_w, webui_icon_wifi_h);
      x += webui_icon_wifi_w + 6;
      dsp.setTextColor(rgb565(120, 190, 255), _bgcolor);
	      dsp.setCursor(x, textY);
      dsp.print(String(curRssi));
      dsp.print(" dBm");

      _lastIp = curIp;
      _lastVol = curVol;
      _lastRssi = curRssi;
      _lastPlaying = curPlaying ? 1 : 0;
    }

    // 4) Mode row kiemelések + feliratok (kis terület)
    //    újrarajzoljuk row1-et, ha mód változott
    if (_lastModeRedraw != curMode) {
      const uint16_t n = 5;
      const uint16_t bw = (W - 2*pad - (n-1)*gap) / n;
      int16_t x = pad;
      const bool isRadio = (curMode == 0);
      const bool isSD    = (curMode == 1);
      const bool isDLNA  = (curMode == 2);

      // Töröljük a sávot
      dsp.fillRect(0, row1Top - 2, W, btnH + 4, _bgcolor);

      // újra shell + label (pressed = aktív)
      // Nav icons (drawn with primitives)
      drawBtnShell(x, row1Top, bw, btnH, cRadio, isRadio);
      drawNavIconBmp(WebUiBtn::RADIO, x, row1Top, bw, btnH);
      x += bw + gap;

      drawBtnShell(x, row1Top, bw, btnH, cSD, isSD);
      drawNavIconBmp(WebUiBtn::SD, x, row1Top, bw, btnH);
      x += bw + gap;

      drawBtnShell(x, row1Top, bw, btnH, cDLNA, isDLNA);
      drawNavIconBmp(WebUiBtn::DLNA, x, row1Top, bw, btnH);
      x += bw + gap;

      drawBtnShell(x, row1Top, bw, btnH, cEQ, false);
      drawNavIconBmp(WebUiBtn::EQ, x, row1Top, bw, btnH);
      x += bw + gap;

      drawBtnShell(x, row1Top, bw, btnH, cSet, false);
      drawNavIconBmp(WebUiBtn::SETTINGS, x, row1Top, bw, btnH);

      _lastModeRedraw = curMode;
    }

    // 5) Control row ikonok (play/pause state miatt)
    if (_lastPlayRedraw != (uint8_t)curPlaying) {
      const uint16_t n = 4;
      const uint16_t bw = (W - 2*pad - (n-1)*gap) / n;
      int16_t x = pad;

      // Töröljük a sávot
      dsp.fillRect(0, row2Top - 2, W, btnH + 4, _bgcolor);

      // shell + symbol
      drawBtnShell(x, row2Top, bw, btnH, cCtrl); drawCtrlSymbol(WebUiBtn::PREV, x, row2Top, bw, btnH, cCtrl); x += bw + gap;
      drawBtnShell(x, row2Top, bw, btnH, cPlay); drawCtrlSymbol(WebUiBtn::PLAYPAUSE, x, row2Top, bw, btnH, cPlay); x += bw + gap;
      drawBtnShell(x, row2Top, bw, btnH, cStop); drawCtrlSymbol(WebUiBtn::STOP, x, row2Top, bw, btnH, cStop); x += bw + gap;
      drawBtnShell(x, row2Top, bw, btnH, cCtrl); drawCtrlSymbol(WebUiBtn::NEXT, x, row2Top, bw, btnH, cCtrl);

      _lastPlayRedraw = curPlaying ? 1 : 0;
    }

    // Safety: clear a tiny strip at the right edge to avoid any leftover glyph artifacts.
    dsp.fillRect(W - 3, 0, 3, H, _bgcolor);
  }

private:
  volatile bool _dirty = true;
  bool _staticDrawn = false;
  bool _firstPaint = true;

  // Flicker csökkentéshez "last" értékek
  uint8_t _lastMode = 0xFF;
  uint8_t _lastModeRedraw = 0xFF;
  uint8_t _lastPlayRedraw = 0xFF;
  uint16_t _lastVol = 0xFFFF;
  int16_t _lastRssi = 0x7FFF;
  uint8_t _lastPlaying = 0xFF;
  String _lastName;
  String _lastTitle;
  String _lastIp;
};
