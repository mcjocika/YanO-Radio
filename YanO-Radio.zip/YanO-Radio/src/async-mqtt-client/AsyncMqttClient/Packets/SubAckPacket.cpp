#include "SubAckPacket.hpp"

using AsyncMqttClientInternals::SubAckPacket;

SubAckPacket::SubAckPacket(ParsingInformation* parsingInformation, OnSubAckInternalCallback callback)
: _parsingInformation(parsingInformation)
, _callback(callback)
, _bytePosition(0)
, _packetIdMsb(0)
, _packetId(0) {
}

SubAckPacket::~SubAckPacket() {
}

void SubAckPacket::parseVariableHeader(char* data, size_t len, size_t* currentBytePosition) {
  char currentByte = data[(*currentBytePosition)++];
  if (_bytePosition++ == 0) {
    _packetIdMsb = currentByte;
  } else {
    _packetId = currentByte | _packetIdMsb << 8;
    _parsingInformation->bufferState = BufferState::PAYLOAD;
  }
}

void SubAckPacket::parsePayload(char* data, size_t len, size_t* currentBytePosition) {
  char status = data[(*currentBytePosition)++];

  /* switch (status) {
    case 0:
      log_i("%s", String("Success QoS 0").c_str());
      break;
    case 1:
      log_i("%s", String("Success QoS 1").c_str());
      break;
    case 2:
      log_i("%s", String("Success QoS 2").c_str());
      break;
    case 0x80:
      log_i("%s", String("Failure").c_str());
      break;
  } */

  _parsingInformation->bufferState = BufferState::NONE;
  _callback(_packetId, status);
}
