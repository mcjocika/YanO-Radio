#include "options.h"        // ebben van behúzva az AsyncWebServer lib is
#include "sdmanager_web.h"

#ifdef USE_SD

#include <SPIFFS.h>
#include <SD.h>
#include "sdmanager.h"
#include "player.h"
#include "config.h"
#include "netserver.h"


// Ezek globális objektumok, más fordítási egységben definiálva.
extern Player    player;
extern Config    config;
extern NetServer netserver;
extern SDManager sdman;   // ha a típus neve nem SdManager, itt igazítsd!

// --------------------------------------------------------
// Segédfüggvény(ek) FreeRTOS task-hoz – csak kód tisztításra
// --------------------------------------------------------

static void sd_task_reindex_full(void*) {
  vTaskDelay(500 / portTICK_PERIOD_MS);
  sdman.start();
  if (!sdman.exists("/data")) {
    sdman.mkdir("/data");
  }
  sdman.indexSDPlaylist();

  // Ha épp SD módban vagyunk, akkor töltsük újra az SD playlistet a memóriába
  if (config.getMode() == PM_SDCARD) {
    netserver.requestOnChange(PLAYLISTSAVED, 0);
  }

  vTaskDelete(nullptr);
}

static void sd_task_reindex_only(void*) {
  vTaskDelay(500 / portTICK_PERIOD_MS);
  sdman.indexSDPlaylist();

  if (config.getMode() == PM_SDCARD) {
    netserver.requestOnChange(PLAYLISTSAVED, 0);
  }

  vTaskDelete(nullptr);
}

// --------------------------------------------------------
// SD-s HTTP végpontok regisztrálása
// (ezek a te korábbi módosított kódodból lettek átemelve)
// --------------------------------------------------------

void SdManagerWeb::registerRoutes(AsyncWebServer& webserver) {

  // 1. SD KÁRTYA LISTÁZÁS
  webserver.on("/sd/list", HTTP_GET, [](AsyncWebServerRequest *request){
    String path = "/";
    if (request->hasParam("dir")) path = request->getParam("dir")->value();
    if (!path.startsWith("/")) path = "/" + path;

    String json = "[";
    File root = sdman.open(path, "r");
    if (!root) { sdman.start(); root = sdman.open(path, "r"); }

    if (root && root.isDirectory()) {
      File file = root.openNextFile();
      bool first = true;
      while (file) {
        String fileName = String(file.name());
        if (fileName.lastIndexOf('/') >= 0) {
          fileName = fileName.substring(fileName.lastIndexOf('/') + 1);
        }
        if (!fileName.startsWith(".")) {
          if (!first) json += ",";
          json += "{\"name\":\"" + fileName + "\",\"type\":\"" + String(file.isDirectory() ? "dir" : "file") + "\"}";
          first = false;
        }
        file = root.openNextFile();
      }
      root.close();
    }
    json += "]";
    request->send(200, "application/json", json);
  });

  // 2. FÁJL FELTÖLTÉS - EXTRA VÉDELEMMEL
  webserver.on("/edit", HTTP_POST,
    [](AsyncWebServerRequest *request){
      request->send(200, "text/plain", "OK");
    },
    [](AsyncWebServerRequest *request, String filename, size_t index, uint8_t *data, size_t len, bool final){
      if(!index){
        // új feltöltés indul
        player.sendCommand({PR_STOP, 0});
        //config.newConfigMode = PM_WEB;
        //vTaskDelay(300);

        log_i("[SD] Feltöltés kezdete: %s\n", filename.c_str());
        sdman.start();

        if(!filename.startsWith("/")) filename = "/" + filename;

        if (filename.endsWith("playlistsd.csv")) {
          if (!sdman.exists("/data")) sdman.mkdir("/data");
          filename = PLAYLIST_SD_PATH;
        }

        request->_tempFile = sdman.open(filename, "w", true);
      }

      if(request->_tempFile) {
        request->_tempFile.write(data, len);
      }

      if(final){
        if(request->_tempFile) {
          request->_tempFile.close();
        }
        log_i("%s", String("[SD] Feltöltés kész.").c_str());

        // háttérben indexelés (start + /data + index)
        xTaskCreate(sd_task_reindex_full, "sd_idx", 4096, nullptr, 1, nullptr);
      }
    }
  );

  // 3. LEJÁTSZÁSI LISTA ÉPÍTÉSE
  webserver.on("/sd/build", HTTP_GET, [](AsyncWebServerRequest *request){
    player.sendCommand({PR_STOP, 0});
    xTaskCreate(sd_task_reindex_full, "sd_bld", 4096, nullptr, 1, nullptr);
    request->send(200, "text/plain", "Építés indítva...");
  });

  // 4. FÁJL TÖRLÉSE
  webserver.on("/sd_delete", HTTP_GET, [](AsyncWebServerRequest *request){
    if(request->hasParam("filename")) {
      String fn = request->getParam("filename")->value();

      log_i("[SD] Torles: %s\n", fn.c_str());
      player.sendCommand({PR_STOP, 0});
      vTaskDelay(200 / portTICK_PERIOD_MS);

      if(sdman.remove(fn)) {
        // törlés utáni háttér indexelés
        xTaskCreate(sd_task_reindex_only, "sd_del_idx", 3072, nullptr, 1, nullptr);
        request->send(200, "text/plain", "Sikeres torles");
      } else {
        request->send(500, "text/plain", "Hiba: Nem sikerult torolni!");
      }
    } else {
      request->send(400, "text/plain", "Hianyzik a filenev!");
    }
  });

  // 5. MÓDVÁLTÁS SD-re
webserver.on("/playlist/sd", HTTP_GET, [](AsyncWebServerRequest *request){
  player.sendCommand({PR_STOP, 0});
  vTaskDelay(200 / portTICK_PERIOD_MS); 

  config.newConfigMode = PM_SDCARD;
  netserver.requestOnChange(CHANGEMODE, 0); 
  vTaskDelay(300 / portTICK_PERIOD_MS); // Időt adunk az SD kártya inicializálásának

  // SD playlist betöltése (ez már bizonyítottan működött)
  log_i("%s", String("[MODE] /playlist/sd -> initSDPlaylist()").c_str());
  config.initSDPlaylist();

  // TELJES playlist frissítés (websocket/TFT)
  netserver.requestOnChange(PLAYLIST, 0);

  // Egyéb állapotok frissítése
  netserver.requestOnChange(GETINDEX, 0);
  netserver.requestOnChange(GETPLAYERMODE, 0);

  request->send(200, "text/plain", "Váltás SD kártyára...");
});
}

#endif // USE_SD