#include "dlna_renderer.h"

#ifdef USE_DLNA_RENDERER

#include "WiFi.h"

// arduino-dlna: https://github.com/pschatzmann/arduino-dlna
#if defined(__GNUC__)
#  pragma GCC diagnostic push
// The DLNA dependency is external; we keep its warnings from spamming the build.
#  pragma GCC diagnostic ignored "-Wignored-qualifiers"
#  pragma GCC diagnostic ignored "-Wdeprecated-copy"
#  pragma GCC diagnostic ignored "-Wdelete-non-virtual-dtor"
#  pragma GCC diagnostic ignored "-Wformat"
#  pragma GCC diagnostic ignored "-Wunused-variable"
#  pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#  pragma GCC diagnostic ignored "-Wunused-function"
#  pragma GCC diagnostic ignored "-Woverloaded-virtual"
#  pragma GCC diagnostic ignored "-Wuninitialized"
#endif
#include "DLNA.h"
#if defined(__GNUC__)
#  pragma GCC diagnostic pop
#endif

// Explicit template aliases for arduino-dlna (tiny_dlna)
#include <WiFiUdp.h>

#include <esp_system.h>

using HttpServer_t = tiny_dlna::HttpServer<WiFiClient, WiFiServer>;
using UDPService_t = tiny_dlna::UDPService<WiFiUDP>;
using Renderer_t  = tiny_dlna::DLNAMediaRenderer<WiFiClient>;

#include "../core/player.h"
#include "../core/config.h"

// We use a dedicated port to avoid conflicts with yoRadio's AsyncWebServer (typically 80).
static constexpr int kDlnaPort = 9000;
// Device description (device.xml) is served by yoRadio's webserver on port 80.
static constexpr int kDescPort = 80;

static WiFiServer s_wifi(kDlnaPort);
static HttpServer_t s_http(s_wifi, 1024);
static UDPService_t s_udp;
static Renderer_t s_renderer(s_http, s_udp);

static TaskHandle_t s_task = nullptr;
static TaskHandle_t s_ssdpTask = nullptr;
static volatile bool s_running = false;
static String s_pendingUri;
static String s_pendingName;

static String makeUriLabel(const char* uri) {
  if (!uri || !uri[0]) return String();
  String u(uri);
  // Strip query
  int q = u.indexOf('?');
  if (q >= 0) u = u.substring(0, q);
  // Take last path segment
  int slash = u.lastIndexOf('/');
  if (slash >= 0 && slash + 1 < (int)u.length()) u = u.substring(slash + 1);
  u.trim();
  if (u.length() > 48) u = u.substring(0, 48);
  return u;
}

// Windows (and some controllers) sometimes provide SetAVTransportURI URLs with
// a hostname (e.g. http://DESKTOP-XXXX:10243/...) or other variants that an ESP
// cannot always resolve depending on router/DNS settings.
// Best-effort: if the URI host is a hostname (not an IPv4 address), resolve it
// via WiFi.hostByName and replace it with the resolved IP.
static String normalizeUriForEsp(const char* uri) {
  if (!uri || !uri[0]) return String();
  String u(uri);
  // Only handle plain http:// (most ESP audio stacks are HTTP-only).
  if (!u.startsWith("http://")) return u;

  // IPv6 URL form: http://[fe80::...]/... -> do not touch.
  int schemeEnd = 7; // len("http://")
  if (u.length() > schemeEnd && u[schemeEnd] == '[') return u;

  int hostStart = schemeEnd;
  int hostEnd = u.indexOf('/', hostStart);
  if (hostEnd < 0) hostEnd = u.length();
  String hostPort = u.substring(hostStart, hostEnd);

  String host = hostPort;
  String port;
  int colon = hostPort.indexOf(':');
  if (colon >= 0) {
    host = hostPort.substring(0, colon);
    port = hostPort.substring(colon); // keep ':'
  }
  host.trim();
  if (host.length() == 0) return u;

  // If it's already an IPv4 address, keep it.
  bool isIp = true;
  for (size_t i = 0; i < host.length(); ++i) {
    char c = host[i];
    if (!((c >= '0' && c <= '9') || c == '.')) { isIp = false; break; }
  }
  if (isIp) return u;

  IPAddress resolved;
  if (WiFi.hostByName(host.c_str(), resolved) == 1) {
    log_i("[DLNA-R] normalizeUri: host '%s' -> %s", host.c_str(), resolved.toString().c_str());
    String out = "http://" + resolved.toString() + port;
    out += u.substring(hostEnd);
    return out;
  }
  log_w("[DLNA-R] normalizeUri: hostByName FAILED for '%s' (keeping original)", host.c_str());
  return u;
}

// Some controllers are picky about non-ASCII characters in SSDP/device strings.
// If the stored mDNS name contains UTF-8 accents (pl. magyar ékezet), discovery can fail.
// Create a conservative ASCII-only friendly name for the renderer.
static String sanitizeFriendlyName(const char* in) {
  if (!in || !in[0]) return String();
  String out;
  out.reserve(32);
  for (const uint8_t* p = (const uint8_t*)in; *p; ++p) {
    const uint8_t c = *p;
    // Allowed: basic printable ASCII, but keep it simple.
    const bool ok =
      (c >= 'a' && c <= 'z') ||
      (c >= 'A' && c <= 'Z') ||
      (c >= '0' && c <= '9') ||
      c == ' ' || c == '-' || c == '_' || c == '.';
    out += ok ? (char)c : '_';
    if (out.length() >= 32) break;
  }
  out.trim();
  return out;
}

// -----------------------------------------------------------------------------
// SSDP compatibility notifier (BubbleUPnP / Hi-Fi Cast)
// -----------------------------------------------------------------------------
// Some Android control-point apps appear to rely heavily on periodic SSDP NOTIFY
// announcements (alive). Depending on tiny_dlna version/config, the built-in
// UDP service may only respond to M-SEARCH or may announce a limited set of
// NT/USN variants. To be "sure", we send standard NOTIFY alive messages for
// rootdevice, MediaRenderer, and the key services.
//
// This does NOT replace UDP/1900 discovery; it improves it. It does not require
// binding port 1900, only sending multicast packets.

static WiFiUDP s_ssdpUdp;
static char s_udnBuf[64] = {0};

static void buildStableUdn() {
  if (s_udnBuf[0]) return;
  // Build a stable UUID from the ESP MAC.
  // Format: uuid:xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
  uint64_t mac = ESP.getEfuseMac();
  const uint32_t m1 = (uint32_t)(mac & 0xFFFFFFFFULL);
  const uint32_t m2 = (uint32_t)((mac >> 32) & 0xFFFFFFFFULL);
  // Not a RFC4122 UUID, but stable and unique enough on a LAN.
  snprintf(s_udnBuf, sizeof(s_udnBuf),
           "uuid:%08x-%04x-%04x-%04x-%04x%08x",
           (unsigned)m1,
           (unsigned)((m2 >> 16) & 0xFFFF),
           (unsigned)(m2 & 0xFFFF),
           (unsigned)((m1 >> 16) & 0xFFFF),
           (unsigned)(m1 & 0xFFFF),
           (unsigned)m2);
}

// tiny_dlna API differs across forks; probe optional methods without breaking builds.
template <typename R>
static auto trySetUDN(R& r, const char* id, int) -> decltype(r.device().setUDN(id), bool()) {
  r.device().setUDN(id);
  return true;
}
template <typename R>
static bool trySetUDN(R&, const char*, ...) {
  return false;
}


static void ssdpNotifyAliveOnce() {
  if (WiFi.status() != WL_CONNECTED) return;
  buildStableUdn();

  IPAddress mcast(239, 255, 255, 250);
  const uint16_t port = 1900;

  // Ensure UDP is started (ephemeral local port).
  static bool started = false;
  if (!started) {
    // Start multicast listener context on SSDP group/port (required on some stacks to send multicast reliably).
    started = s_ssdpUdp.beginMulticast(mcast, port);
    if (!started) {
      // Fallback: at least open a local UDP socket.
      s_ssdpUdp.begin(0);
      started = true;
    }
  }

  const String ip = WiFi.localIP().toString();
  const String location = "http://" + ip + ":" + String(kDescPort) + "/device.xml";

  // Cache-Control is important for some clients.
  const char* cache = "CACHE-CONTROL: max-age=1800\r\n";
  const char* server = "SERVER: yoRadio/1.0 UPnP/1.0 DLNADOC/1.50\r\n";
  const char* nts = "NTS: ssdp:alive\r\n";
  const String host = "HOST: 239.255.255.250:1900\r\n";
  const String loc = "LOCATION: " + location + "\r\n";

  auto sendNotify = [&](const String& nt, const String& usn) {
    String msg;
    msg.reserve(256);
    msg += "NOTIFY * HTTP/1.1\r\n";
    msg += host;
    msg += cache;
    msg += loc;
    msg += nts;
    msg += "NT: " + nt + "\r\n";
    msg += "USN: " + usn + "\r\n";
    msg += server;
    msg += "\r\n";

    s_ssdpUdp.beginPacket(mcast, port);
    s_ssdpUdp.write((const uint8_t*)msg.c_str(), msg.length());
    s_ssdpUdp.endPacket();
  };

  const String udn = String(s_udnBuf);
  // Root device
  sendNotify("upnp:rootdevice", udn + "::upnp:rootdevice");
  // UUID itself
  sendNotify(udn, udn);
  // Device type
  sendNotify("urn:schemas-upnp-org:device:MediaRenderer:1", udn + "::urn:schemas-upnp-org:device:MediaRenderer:1");
  // Key services
  sendNotify("urn:schemas-upnp-org:service:AVTransport:1", udn + "::urn:schemas-upnp-org:service:AVTransport:1");
  sendNotify("urn:schemas-upnp-org:service:RenderingControl:1", udn + "::urn:schemas-upnp-org:service:RenderingControl:1");
  sendNotify("urn:schemas-upnp-org:service:ConnectionManager:1", udn + "::urn:schemas-upnp-org:service:ConnectionManager:1");
}

static void ssdpNotifyTask(void* /*arg*/) {
  // Announce quickly at start, then periodically.
  for (int i = 0; i < 3; ++i) {
    ssdpNotifyAliveOnce();
    vTaskDelay(pdMS_TO_TICKS(600));
  }
  for (;;) {
    ssdpNotifyAliveOnce();
    vTaskDelay(pdMS_TO_TICKS(10000));
  }
}

static void handleMediaEvent(tiny_dlna::MediaEvent ev, Renderer_t& mr) {
  switch (ev) {
    case MediaEvent::SET_URI: {
      // Controller set a new stream URL
      const char* uri = mr.getCurrentUri();
      if (uri && uri[0]) {
        String fixed = normalizeUriForEsp(uri);
        s_pendingUri = fixed.length() ? fixed : String(uri);
        s_pendingName = makeUriLabel(s_pendingUri.c_str());
        log_i("[DLNA-R] SET_URI: '%s' (active=%d)", s_pendingUri.c_str(), (int)mr.isActive());
        // If controller already considers us active, start immediately.
        if (mr.isActive()) {
          log_i("[DLNA-R] SET_URI -> playUrl(name='%s')", s_pendingName.length() ? s_pendingName.c_str() : "DLNA");
          player.playUrl(s_pendingUri.c_str(), s_pendingName.length() ? s_pendingName.c_str() : "DLNA");
        }
      }
      break;
    }
    case MediaEvent::PLAY: {
      // Start playback of pending URI
      log_i("[DLNA-R] PLAY (pending=%d)", (int)s_pendingUri.length());
      if (s_pendingUri.length()) {
        log_i("[DLNA-R] PLAY -> playUrl('%s')", s_pendingUri.c_str());
        player.playUrl(s_pendingUri.c_str(), s_pendingName.length() ? s_pendingName.c_str() : "DLNA");
      } else {
        // Best-effort: resume current station
        if (!player.isRunning()) {
          log_w("[DLNA-R] PLAY without pending URI -> resume lastStation=%u", (unsigned)config.lastStation());
          player.sendCommand({PR_PLAY, (int)config.lastStation()});
        }
      }
      break;
    }
    case MediaEvent::STOP: {
      log_i("[DLNA-R] STOP");
      player.sendCommand({PR_STOP, 0});
      break;
    }
    case MediaEvent::PAUSE: {
      // yoRadio has no real pause; map to stop.
      log_i("[DLNA-R] PAUSE -> STOP");
      player.sendCommand({PR_STOP, 0});
      break;
    }
    case MediaEvent::SET_VOLUME: {
      // DLNA volume is 0..100
      int v = (int)mr.getVolume();
      if (v < 0) v = 0;
      if (v > 100) v = 100;
      log_i("[DLNA-R] SET_VOLUME: %d", v);
      player.sendCommand({PR_VOL, v});
      break;
    }
    case MediaEvent::SET_MUTE: {
      // Best-effort: if muted -> volume 0, else restore stored volume.
      log_i("[DLNA-R] SET_MUTE: %d", (int)mr.isMuted());
      if (mr.isMuted()) {
        player.sendCommand({PR_VOL, 0});
      } else {
        player.sendCommand({PR_VOL, (int)config.store.volume});
      }
      break;
    }
    default:
      break;
  }
}

static void dlnaTask(void* /*arg*/) {
  s_running = true;
  for (;;) {
    s_renderer.loop();
    vTaskDelay(pdMS_TO_TICKS(20));
  }
}

namespace {

template <typename T, typename = void>
struct has_set_manufacturer : std::false_type {};
template <typename T>
struct has_set_manufacturer<T, std::void_t<decltype(std::declval<T&>().setManufacturer((const char*)nullptr))>> : std::true_type {};

template <typename T, typename = void>
struct has_set_model_name : std::false_type {};
template <typename T>
struct has_set_model_name<T, std::void_t<decltype(std::declval<T&>().setModelName((const char*)nullptr))>> : std::true_type {};

template <typename T, typename = void>
struct has_set_model_number : std::false_type {};
template <typename T>
struct has_set_model_number<T, std::void_t<decltype(std::declval<T&>().setModelNumber((const char*)nullptr))>> : std::true_type {};

template <typename T, typename = void>
struct has_set_model_description : std::false_type {};
template <typename T>
struct has_set_model_description<T, std::void_t<decltype(std::declval<T&>().setModelDescription((const char*)nullptr))>> : std::true_type {};

template <typename T, typename = void>
struct has_set_protocols_1 : std::false_type {};
template <typename T>
struct has_set_protocols_1<T, std::void_t<decltype(std::declval<T&>().setProtocols((const char*)nullptr))>> : std::true_type {};

template <typename T, typename = void>
struct has_set_protocols_2 : std::false_type {};
template <typename T>
struct has_set_protocols_2<T, std::void_t<decltype(std::declval<T&>().setProtocols((const char*)nullptr, (const char*)nullptr))>> : std::true_type {};

} // namespace



// --- tiny_dlna API compatibility helpers (compile-time detection) ---
namespace {
  template <typename R>
  static auto _trySetProtocols1(R& r, const char* sink, int) -> decltype(r.setProtocols(sink), bool()) {
    r.setProtocols(sink);
    return true;
  }
  template <typename R>
  static bool _trySetProtocols1(R&, const char*, ...) { return false; }

  template <typename R>
  // Some forks expose setProtocols(source, sink) but the parameter order is not
  // always documented. To be robust (and to satisfy Windows which requires a
  // non-empty Sink in GetProtocolInfo), we set BOTH sides to the same list.
  static auto _trySetProtocols2(R& r, const char* list, int) -> decltype(r.setProtocols(list, list), bool()) {
    r.setProtocols(list, list);
    return true;
  }
  template <typename R>
  static bool _trySetProtocols2(R&, const char*, ...) { return false; }
} // namespace

namespace dlna_renderer {

// Keep strings passed into tiny_dlna alive for the lifetime of the renderer.
// Some tiny_dlna builds store raw pointers (do not deep-copy), so passing
// String::c_str() from a temporary can crash later.
static char s_friendlyNameBuf[64] = {0};

void begin() {
  if (s_task != nullptr) return;
  if (WiFi.status() != WL_CONNECTED) return;

  log_i("[DLNA-R] begin(): ip=%s port=%d", WiFi.localIP().toString().c_str(), (int)kDlnaPort);

  // Basic info. If user has mdns name, use it; otherwise fallback.
  // NOTE: Windows "Cast to device" / "Play To" list is extremely sensitive to
  // the renderer's friendly name and SSDP strings. Keep it ASCII-only.
  // If the user didn't set an mDNS name, default to the requested device name.
  const char* raw = (strlen(config.store.mdnsname) > 0) ? config.store.mdnsname : "YanO-Player";
  String friendly = sanitizeFriendlyName(raw);
  if (!friendly.length()) friendly = "YanO-Player";
  // Copy into stable buffer.
  strlcpy(s_friendlyNameBuf, friendly.c_str(), sizeof(s_friendlyNameBuf));

  // Ensure the dedicated HTTP server is really bound to kDlnaPort.
  // Some tiny_dlna builds assume the user starts the underlying WiFiServer,
  // and may fall back to a default port if it isn't listening yet.
  s_wifi.begin();
  s_wifi.setNoDelay(true);

  // IMPORTANT: Some tiny_dlna builds crash if optional device metadata/protocol setters
  // are called before begin(). Keep begin() minimal and add extras after start.
  s_renderer.setBaseURL(WiFi.localIP(), kDescPort);
  s_renderer.setMediaEventHandler(handleMediaEvent);

  // Ensure we have a stable UDN across boots: this helps Windows and can reduce
  // control-point caching issues.
  buildStableUdn();
  // Some library versions expose setUDN(). Call it only if it exists.
  bool udnOk = trySetUDN(s_renderer, s_udnBuf, 0);
  if (udnOk) {
    log_i("[DLNA-R] UDN set to %s", s_udnBuf);
  } else {
    log_w("[DLNA-R] UDN setter not available in tiny_dlna (keeping default)");
  }

  if (!s_renderer.begin()) {
    log_w("[DLNA-R] s_renderer.begin() FAILED (will retry later)");
    // If it fails, we keep task null so it can retry later.
    return;
  }

  // Re-apply base URL after start as well: some versions rebuild SSDP/LOCATION
  // strings during begin() and can overwrite the previously set port.
  s_renderer.setBaseURL(WiFi.localIP(), kDescPort);

  // Some tiny_dlna builds crash if setFriendlyName() is called before begin().
  // Apply it only after a successful start.
  s_renderer.setFriendlyName(s_friendlyNameBuf);
  log_i("[DLNA-R] friendlyName: '%s' (raw='%s')", s_friendlyNameBuf, raw);

  // Optional device metadata (helps some Windows/UPnP stacks).
  // We only call setters that exist in the currently installed tiny_dlna.
  if constexpr (has_set_manufacturer<Renderer_t>::value) {
    s_renderer.setManufacturer("mcjocika");
  }
  if constexpr (has_set_model_name<Renderer_t>::value) {
    s_renderer.setModelName("YoRadio");
  }
  if constexpr (has_set_model_number<Renderer_t>::value) {
    s_renderer.setModelNumber("1.0");
  }
  if constexpr (has_set_model_description<Renderer_t>::value) {
    s_renderer.setModelDescription("YoRadio DLNA MediaRenderer");
  }

  // Optional: advertise sink protocols for better Windows "Cast to device" compatibility.
  // Do it AFTER begin() to avoid pre-init crashes on some library versions.
  {
		// User-confirmed supported formats: aac, flac, mp3, opus, vorbis, wav.
		// Note: Windows is happiest when at least the common audio types are present.
		// OGG-based codecs (vorbis/opus) are included for clients that honor them; Windows
		// may ignore some of these even if advertised.
		const char* winSink =
		  "http-get:*:audio/mpeg:*,"
		  "http-get:*:audio/mp3:*,"
		  "http-get:*:audio/aac:*,"
		  "http-get:*:audio/flac:*,"
		  "http-get:*:audio/wav:*,"
		  "http-get:*:audio/x-wav:*,"
		  "http-get:*:audio/ogg:*,"
		  "http-get:*:application/ogg:*,"
		  "http-get:*:audio/vorbis:*,"
		  "http-get:*:audio/opus:*";

    // tiny_dlna API compatibility:
    // - Some versions expose setProtocols(sink)
    // - Others expose setProtocols(source, sink)
    // We probe both signatures.
    bool ok = _trySetProtocols1(s_renderer, winSink, 0) || _trySetProtocols2(s_renderer, winSink, 0);
    if (ok) {
      log_i("[DLNA-R] sinkProtocolInfo set via setProtocols");
    } else {
      log_w("[DLNA-R] sinkProtocolInfo NOT set (API not available)");
    }
  }

  log_i("[DLNA-R] renderer started OK");

  // Start SSDP NOTIFY helper task (improves discovery in BubbleUPnP/Hi-Fi Cast).
  if (!s_ssdpTask) {
    xTaskCreatePinnedToCore(ssdpNotifyTask, "ssdpNotify", 4096, nullptr, 1, &s_ssdpTask, 0);
  }

  xTaskCreatePinnedToCore(dlnaTask, "dlnaRenderer", 6144, nullptr, 1, &s_task, 0);
}

void end() {
  if (!s_task) return;
  vTaskDelete(s_task);
  s_task = nullptr;
  s_running = false;

  if (s_ssdpTask) {
    vTaskDelete(s_ssdpTask);
    s_ssdpTask = nullptr;
  }
}

void restart() {
  // Best-effort restart. If WiFi isn't up yet, begin() will no-op.
  end();
  // Give the stack a moment to release sockets on some builds.
  delay(20);
  begin();
}

bool isRunning() {
  return s_running;
}


const char* udn() {
  // Ensure buffer is populated even if begin() hasn't been called yet.
  if (s_udnBuf[0] == 0) {
    buildStableUdn();
  }
  return s_udnBuf;
}

const char* friendlyName() {
  if (s_friendlyNameBuf[0] == 0) {
    // Best effort default; begin() will overwrite with configured value.
    strlcpy(s_friendlyNameBuf, "YanO-Player", sizeof(s_friendlyNameBuf));
  }
  return s_friendlyNameBuf;
}

int httpPort() {
  return kDlnaPort;
}

} // namespace dlna_renderer

#endif // USE_DLNA_RENDERER