// Módosítva "vol_step"
#include "options.h"
#include "player.h"
#include "config.h"
#include "telnet.h"
#include "display.h"
#include "sdmanager.h"
#include "netserver.h"
#include "timekeeper.h"
#include "ampguard.h"
#ifdef USE_DLNA
  #include <WiFi.h>
  #include <WiFiClient.h>
#endif
#include "../displays/tools/l10n.h"
#include "../pluginsManager/pluginsManager.h"
#ifdef USE_NEXTION
  #include "../displays/nextion.h"
#endif
Player player;
QueueHandle_t playerQueue;

#ifdef USE_DLNA
// Extract host/port from http(s) URL.
// Very small parser (no allocations besides String).
static bool parseHttpUrl(const String& url, String& host, uint16_t& port) {
  host = "";
  port = 0;
  if (!(url.startsWith("http://") || url.startsWith("https://"))) return false;

  bool https = url.startsWith("https://");
  int p = https ? 8 : 7;
  int slash = url.indexOf('/', p);
  String hostport = (slash >= 0) ? url.substring(p, slash) : url.substring(p);
  hostport.trim();
  if (!hostport.length()) return false;

  int colon = hostport.indexOf(':');
  if (colon >= 0) {
    host = hostport.substring(0, colon);
    String ps = hostport.substring(colon + 1);
    ps.trim();
    int pi = ps.toInt();
    if (pi <= 0 || pi > 65535) return false;
    port = (uint16_t)pi;
  } else {
    host = hostport;
    port = https ? 443 : 80;
  }
  host.trim();
  return host.length() > 0;
}

static bool dlnaPlaylistFirstUrl(String& outUrl) {
  outUrl = "";
  if (!SPIFFS.exists(PLAYLIST_DLNA_PATH)) return false;
  File f = SPIFFS.open(PLAYLIST_DLNA_PATH, "r");
  if (!f) return false;
  while (f.available()) {
    String line = f.readStringUntil('\n');
    line.trim();
    if (!line.length()) continue;
    int t1 = line.indexOf('\t');
    if (t1 < 0) continue;
    int t2 = line.indexOf('\t', t1 + 1);
    String url = (t2 > t1) ? line.substring(t1 + 1, t2) : line.substring(t1 + 1);
    url.trim();
    if (url.startsWith("http://") || url.startsWith("https://")) {
      outUrl = url;
      f.close();
      return true;
    }
  }
  f.close();
  return false;
}
#endif

#if VS1053_CS != 255 && !I2S_INTERNAL
  #if VS_HSPI
Player::Player() : Audio(VS1053_CS, VS1053_DCS, VS1053_DREQ, &SPI2) {}
  #else
Player::Player() : Audio(VS1053_CS, VS1053_DCS, VS1053_DREQ, &SPI) {}
  #endif
void ResetChip() {
#if (VS1053_RST != -1) && (VS1053_RST != 255)
  pinMode(VS1053_RST, OUTPUT);
  digitalWrite(VS1053_RST, LOW);
  delay(30);
  digitalWrite(VS1053_RST, HIGH);
  delay(100);
#endif
}
#else
  #if !I2S_INTERNAL
Player::Player() {}
  #else
Player::Player() : Audio(true, I2S_DAC_CHANNEL_BOTH_EN) {}
  #endif
#endif

void Player::init() {
	// Erősítő/hangfal védelem init (a GPIO-kat kizárólag az ampguard kezeli)
	ampguard::begin();
  log_i("%s", String("##[BOOT]#\tplayer.init\t").c_str());
  playerQueue = NULL;
  _resumeFilePos = 0;
  _hasError = false;
  playerQueue = xQueueCreate(5, sizeof(playerRequestParams_t));


 
#ifdef MQTT_ROOT_TOPIC
  memset(burl, 0, MQTT_BURL_SIZE);
#endif
#if I2S_DOUT != 255
  #if !I2S_INTERNAL
  setPinout(I2S_BCLK, I2S_LRC, I2S_DOUT);
  #endif
#else
  SPI.begin();
  if (VS1053_RST > 0) {
    ResetChip();
  }
  begin();
#endif
  setBalance(-config.store.balance);  // "audio_change"   -16 to 16 fordítás 16 to -16
  setTone(config.store.bass, config.store.middle, config.store.trebble);
  setVolumeSteps(100);  // "audio_change" "vol_step" Új beállítás, a maximális hangerő.
  setVolume(0);
  _status = STOPPED;
  _volTimer = false;
//randomSeed(analogRead(0));
#if PLAYER_FORCE_MONO
  forceMono(true);
#endif
  _loadVol(config.store.volume);
  setConnectionTimeout(CONNECTION_TIMEOUT, CONNECTION_TIMEOUT_SSL);
  log_i("%s", String("done").c_str());
}

void Player::sendCommand(playerRequestParams_t request) {
  if (playerQueue == NULL) {
    return;
  }
  xQueueSend(playerQueue, &request, PLQ_SEND_DELAY);
}

void Player::resetQueue() {
  if (playerQueue != NULL) {
    xQueueReset(playerQueue);
  }
}

void Player::stopInfo() {
  config.setSmartStart(0);
  netserver.requestOnChange(MODE, 0);
}

void Player::setError() {
  _hasError = true;
  config.setTitle(config.tmpBuf);
  telnet.printf("##ERROR#:\t%s\r\n", config.tmpBuf);
}

void Player::setError(const char *e) {
  strlcpy(config.tmpBuf, e, sizeof(config.tmpBuf));
  setError();
}

void Player::_stop(bool alreadyStopped) {
  log_i("%s called", __func__);
  if (config.getMode() == PM_SDCARD && !alreadyStopped) {
    config.sdResumePos = player.getAudioFilePosition();
    config.stopedSdStationId = config.lastStation();
  }

  _status = STOPPED;
  setOutputPins(false);

  if (!_hasError) {
    config.setTitle((display.mode() == LOST || display.mode() == UPDATING) ? "" : LANG::const_PlStopped);
  }
  config.station.bitrate = 0;
  config.setBitrateFormat(BF_UNKNOWN);
#ifdef USE_NEXTION
  nextion.bitrate(config.station.bitrate);
#endif
  if (!alreadyStopped) stopSong();

  netserver.requestOnChange(BITRATE, 0);
  display.putRequest(DBITRATE);
  display.putRequest(PSTOP);

  if (!lockOutput) stopInfo();

  if (player_on_stop_play) player_on_stop_play();
  pm.on_stop_play();
}

void Player::initHeaders(const char *file) {
  if (strlen(file) == 0 || true) {
    return;  //TODO Read TAGs
  }
  connecttoFS(sdman, file);
  //eofHeader = false; // megszűnt az Audio.h ban.
  //while(!eofHeader) Audio::loop(); // megszűnt az Audio.h ban.
  //netserver.requestOnChange(SDPOS, 0);
  //setDefaults(); // free buffers and set defaults átkerült a privat függvényekhez az Audio.h ban.
}
void resetPlayer() {
  if (!config.store.watchdog) {
    return;
  }
  player.resetQueue();
  player.sendCommand({PR_STOP, 0});
  player.loop();
}

#ifndef PL_QUEUE_TICKS
  #define PL_QUEUE_TICKS 0
#endif
#ifndef PL_QUEUE_TICKS_ST
  #define PL_QUEUE_TICKS_ST 15
#endif
void Player::loop() {
  if (playerQueue == NULL) {
    return;
  }
  playerRequestParams_t requestP;
  if (xQueueReceive(playerQueue, &requestP, isRunning() ? PL_QUEUE_TICKS : PL_QUEUE_TICKS_ST)) {
    switch (requestP.type) {
      case PR_STOP: _stop(); break;
      case PR_PREV: prev(); break;
      case PR_NEXT: next(); break;
      case PR_PLAY:
      {
        uint16_t st = (uint16_t)abs(requestP.payload);

#ifdef USE_DLNA
        if (config.store.playlistSource == PL_SRC_DLNA) {
          config.store.lastDlnaStation = st;
          config.saveValue(&config.store.lastDlnaStation, (uint16_t)st);
          config.sdResumePos = 0;
          // FONTOS: ne írjuk felül tartósan a "lastPlayedSource"-t DLNA-ra.
          // Ha nincs DLNA playlist (vagy csak teszteltél az ikonnal), akkor egy következő
          // boot után a UI üres DLNA playlistet próbálna betölteni.
          _play(st);
          netserver.requestOnChange(GETINDEX, 0);
          break;
        }
#endif

        // ==== EREDETI VISSELKEDÉS (WEB / SD) ====
        if (requestP.payload > 0) {
          config.setLastStation(st);
        }
#ifdef USE_DLNA
        config.saveValue(&config.store.lastPlayedSource, (uint8_t)PL_SRC_WEB);
#endif
        _play(st);
        if (player_on_station_change) {
          player_on_station_change();
        }
        pm.on_station_change();
        break;
      }
      case PR_TOGGLE:
      {
        toggle();
        break;
      }
      case PR_VOL:
      {
        config.setVolume(requestP.payload);
        Audio::setVolume(volToI2S(requestP.payload));

        // Web UI / távoli parancs esetén is számítson user-aktivitásnak → ébredjen a kijelzővédő
        if (display.mode() == SCREENSAVER || display.mode() == SCREENBLANK) {
          config.screensaverTicks = 0;
          config.screensaverPlayingTicks = 0;
          display.putRequest(NEWMODE, PLAYER);
        }
        display.wakeup();

        break;
      }
      #ifdef USE_SD
      case PR_CHECKSD:
      {
        if (config.getMode() == PM_SDCARD) {
          if (!sdman.cardPresent()) {
            sdman.stop();
            config.changeMode(PM_WEB);
          }
        }
        break;
      }
#endif
      case PR_VUTONUS:  // 2 másodpercenként hívja a timekeeper.
      {
        if (config.vuRefLevel > 10) {
          config.vuRefLevel -= 10;  // A tárolt VU csúcs csökkentése, hogy ne ragadjon fenn.
        }
        break;
      }
      case PR_BURL:
      {
#ifdef MQTT_ROOT_TOPIC
        if (strlen(burl) > 0) {
          browseUrl();
        }
#endif
        break;
      }
      case PR_URL:
      {
        // Play arbitrary URL (presets)
        _hasError = false;
        remoteStationName = false;
        config.setDspOn(1);

        // DLNA / távoli URL indítás is számítson user-aktivitásnak:
        // ébredjen a kijelzővédőből és ne maradjon amp/spk OFF állapotban.
        config.screensaverTicks = 0;
        config.screensaverPlayingTicks = 0;
        if (display.mode() == SCREENSAVER || display.mode() == SCREENBLANK) {
          display.putRequest(NEWMODE, PLAYER);
        }
        display.wakeup();


        if (_status == PLAYING) {
          _stop();
        }

        // Set station label for UI
        if (_nameBuf[0] != '\0') {
          strlcpy(config.station.name, _nameBuf, sizeof(config.station.name));
        } else {
          strlcpy(config.station.name, "URL", sizeof(config.station.name));
        }
        strlcpy(config.station.url, _urlBuf, sizeof(config.station.url));
        config.station.title[0] = '\0';

        // Always WEB mode
        config.saveValue(&config.store.play_mode, static_cast<uint8_t>(PM_WEB));

        display.putRequest(PSTOP);
        setOutputPins(false);
        config.setTitle(LANG::const_PlConnect);

        log_i("[URL] connecttohost('%.196s')...", config.station.url);
        if (connecttohost(config.station.url)) {
          log_i("[URL] connecttohost OK");
          _status = PLAYING;
          config.setTitle("");
          netserver.requestOnChange(MODE, 0);
          setOutputPins(true);
          display.putRequest(PSTART);
          if (player_on_start_play) {
            player_on_start_play();
          }
          pm.on_start_play();
        } else {
          log_w("[URL] connecttohost FAILED");
          telnet.printf("##ERROR#:	Error connecting to %.128s\n", config.station.url);
          snprintf(config.tmpBuf, sizeof(config.tmpBuf), "Error connecting to %.128s", config.station.url);
          setError();
          _stop(true);
        }
        break;
      }
      default: break;
    }
  }
  Audio::loop();

  // ---- DLNA/HTTP diagnosztika (timeout okaihoz) ----
  // Nem nyúlunk az audio feldolgozáshoz, csak akkor logolunk,
  // ha PLAYING közben tartósan nincs bejövő adat (buffer üres).
  static uint32_t s_lastDataTick = 0;
  static uint32_t s_lastWarnTick = 0;
  const uint32_t now = millis();
  const int bufFill = inBufferFilled();
  if (_status == PLAYING && bufFill > 0) {
    s_lastDataTick = now;
  }
  if (_status == PLAYING) {
    if (s_lastDataTick == 0) s_lastDataTick = now;
    const uint32_t noDataMs = now - s_lastDataTick;
    if (bufFill == 0 && noDataMs > 1500 && (now - s_lastWarnTick) > 2000) {
      s_lastWarnTick = now;
      log_w("[NET] no data for %lu ms (buf=%d) url=%.96s", (unsigned long)noDataMs, bufFill, config.station.url);
    }
  } else {
    s_lastDataTick = 0;
    s_lastWarnTick = 0;
  }


#ifdef USE_SD
if (
  config.getMode() == PM_SDCARD &&
  !isRunning() &&
  _status == PLAYING &&
  player.getAudioFilePosition() == 0
) {
  log_i("%s", String("[SD] EOF -> next()").c_str());
  next();
  return;
}
#endif

  if (_volTimer) {
    if ((millis() - _volTicks) > 3000) {
      config.saveVolume();
      _volTimer = false;
    }
  }
  /*
#ifdef MQTT_ROOT_TOPIC
  if(strlen(burl)>0){
    browseUrl();
  }
#endif*/
  {
    bool muteLock = false;
  #ifdef MUTE_LOCK
    muteLock = MUTE_LOCK;
  #endif
    ampguard::updatePlayer(_status == PLAYING, (uint8_t)config.store.volume, muteLock);
  }
}

void Player::setOutputPins(bool isPlaying) {
  if (REAL_LEDBUILTIN != 255) {
    digitalWrite(REAL_LEDBUILTIN, LED_INVERT ? !isPlaying : isPlaying);
  }
  bool muteLock = false;
#ifdef MUTE_LOCK
  muteLock = MUTE_LOCK;
#endif
  ampguard::updatePlayer(isPlaying, (uint8_t)config.store.volume, muteLock);
}

void Player::playUrl(const char *url, const char *name) {
  log_i("[URL] playUrl: name='%s' url='%.196s'", (name && name[0]) ? name : "", url ? url : "");
  if (!url || url[0] == '\0') {
    return;
  }
  // Copy into buffers (used by PR_URL in player task)
  strlcpy(_urlBuf, url, sizeof(_urlBuf));
  if (name && name[0] != '\0') {
    strlcpy(_nameBuf, name, sizeof(_nameBuf));
  } else {
    _nameBuf[0] = '\0';
  }
  sendCommand({PR_URL, 0});
}

#ifdef USE_DLNA
bool Player::startDlnaFromButton() {
  // 1) playlist file must exist and contain at least one playable URL
  String firstUrl;
  if (!dlnaPlaylistFirstUrl(firstUrl)) {
    netserver.notify("DLNA: nincs lejátszható playlist. A webes felületen válaszd ki a szervert és a mappát (DLNA böngésző).\n");
    config.setTitle("DLNA: válaszd ki weben");
    display.putRequest(NEWTITLE);
    return false;
  }

  // 2) best-effort server reachability (quick TCP connect)
  if (WiFi.status() != WL_CONNECTED) {
    netserver.notify("DLNA: nincs WiFi kapcsolat.\n");
    config.setTitle("DLNA: nincs WiFi");
    display.putRequest(NEWTITLE);
    return false;
  }
  String host;
  uint16_t port = 0;
  if (!parseHttpUrl(firstUrl, host, port)) {
    netserver.notify("DLNA: hibás URL a playlistben. Készítsd újra a playlistet a webes DLNA böngészőben.\n");
    config.setTitle("DLNA: hibás URL");
    display.putRequest(NEWTITLE);
    return false;
  }

  WiFiClient c;
  c.setTimeout(1);
  uint32_t t0 = millis();
  bool ok = c.connect(host.c_str(), port, 800);
  c.stop();
  (void)t0;
  if (!ok) {
    netserver.notify("DLNA: a szerver nem elérhető. A webes felületen válaszd ki újra a szervert és a mappát.\n");
    config.setTitle("DLNA: nincs szerver");
    display.putRequest(NEWTITLE);
    return false;
  }

  // 3) Switch to DLNA playlist source (WEB mode engine)
  if (config.getMode() != PM_WEB) {
    config.changeMode(PM_WEB);
  }
  config.store.playlistSource = PL_SRC_DLNA;
  config.saveValue(&config.store.playlistSource, (uint8_t)PL_SRC_DLNA, true, true);
  config.indexDLNAPlaylist();
  config.initDLNAPlaylist();

  // 4) Pick station to start
  uint16_t st = config.store.lastDlnaStation;
  uint16_t len = config.playlistLength();
  if (len == 0) {
    netserver.notify("DLNA: a playlist üres. A webes felületen válaszd ki a szervert és a mappát.\n");
    config.setTitle("DLNA: üres playlist");
    display.putRequest(NEWTITLE);
    netserver.requestOnChange(GETINDEX, 0);
    netserver.requestOnChange(GETPLAYERMODE, 0);
    return false;
  }
  if (st < 1 || st > len) st = 1;
  config.lastStation(st);
  config.loadStation(st);
  if (player_on_station_change) player_on_station_change();

  // 5) Update Web UI (playlist)
  netserver.requestOnChange(GETINDEX, 0);
  netserver.requestOnChange(GETPLAYERMODE, 0);
  netserver.requestOnChange(PLAYLIST, 0);

  // 6) Start playback
  sendCommand({PR_PLAY, (int)st});
  return true;
}
#endif

void Player::_play(uint16_t stationId) {
  log_i("%s called, stationId=%d", __func__, stationId);
  _hasError = false;
  _status = STOPPED;
  setOutputPins(false);
  remoteStationName = false;
  // Kijelző + metaadat alaphelyzet
  if (!config.prepareForPlaying(stationId)) {
    return;
  }
  _loadVol(config.store.volume);
  bool isConnected = false;
  // ----- SD MODE -----
  if (config.getMode() == PM_SDCARD && SDC_CS != 255) {
    // A connecttoFS NEM támogat start offsetet SD-n → -1, indítás pozícionálás nélkül.
    isConnected = connecttoFS(sdman, config.station.url, -1);
  } else {
#ifdef USE_DLNA //DLNA mod
  // DLNA is WEB engine, de nem írjuk felül a mode-ot
    if (config.store.playlistSource != PL_SRC_DLNA)
#endif
    {
      config.saveValue(&config.store.play_mode, static_cast<uint8_t>(PM_WEB));
    }
  }
  //connproc = false;
  if (config.getMode() == PM_WEB) {
    isConnected = connecttohost(config.station.url);
  }
  connproc = true;
  // ----- START PLAYING -----
  if (isConnected) {
  _status = PLAYING;
  config.configPostPlaying(stationId);

  // PLAY indul: az ampguard intézi a hangfalrelé késleltetett felengedését
  setOutputPins(true);

  if (player_on_start_play) player_on_start_play();
  pm.on_start_play();
}
  else {
    telnet.printf("##ERROR#:\tError connecting to %.128s\n", config.station.url);
    snprintf(config.tmpBuf, sizeof(config.tmpBuf), "Error connecting to %.128s", config.station.url);
    setError();
    _stop(true);
  }
}

#ifdef MQTT_ROOT_TOPIC
void Player::browseUrl() {
  _hasError = false;
  remoteStationName = true;
  config.setDspOn(1);
  resumeAfterUrl = _status == PLAYING;
  display.putRequest(PSTOP);
  setOutputPins(false);
  config.setTitle(LANG::const_PlConnect);
  if (connecttohost(burl)) {
    _status = PLAYING;
    config.setTitle("");
    netserver.requestOnChange(MODE, 0);
    setOutputPins(true);
    display.putRequest(PSTART);
    if (player_on_start_play) {
      player_on_start_play();
    }
    pm.on_start_play();
  } else {
    telnet.printf("##ERROR#:\tError connecting to %.128s\r\n", burl);
    snprintf(config.tmpBuf, sizeof(config.tmpBuf), "Error connecting to %.128s", burl);
    setError();
    _stop(true);
  }
  //memset(burl, 0, MQTT_BURL_SIZE);
}
#endif

void Player::prev() {
  uint16_t lastStation = config.lastStation();
  if (config.getMode() != PM_SDCARD) {
    // WEB + DLNA: always sequential wrap
    if (lastStation <= 1) config.lastStation(config.playlistLength());
    else config.lastStation(lastStation - 1);
  } else {
    // SD: sequential unless snuffle enabled (SD-only feature)
    if (!config.store.sdsnuffle) {
      if (lastStation <= 1) config.lastStation(config.playlistLength());
      else config.lastStation(lastStation - 1);
    } else {
      config.lastStation(random(1, config.playlistLength() + 1));
    }
  }
  config.stopedSdStationId = -1;  // Reseteli a seek hez mentett SD fájl sorszámát.
  sendCommand({PR_PLAY, config.lastStation()});
}

void Player::next() {
  uint16_t lastStation = config.lastStation();
  if (config.getMode() != PM_SDCARD) {
    // WEB + DLNA: always sequential wrap
    if (lastStation >= config.playlistLength()) config.lastStation(1);
    else config.lastStation(lastStation + 1);
  } else {
    // SD: sequential unless snuffle enabled
    if (!config.store.sdsnuffle) {
      if (lastStation >= config.playlistLength()) config.lastStation(1);
      else config.lastStation(lastStation + 1);
    } else {
      config.lastStation(random(1, config.playlistLength() + 1));
    }
  }
  config.stopedSdStationId = -1;  // Reseteli a seek hez mentett SD fájl sorszámát.
  sendCommand({PR_PLAY, config.lastStation()});
}

void Player::toggle() {
  if (_status == PLAYING) {
    sendCommand({PR_STOP, 0});
  } else {
    sendCommand({PR_PLAY, config.lastStation()});
  }
}

void Player::stepVol(bool up) {
  if (up) {
    if (config.store.volume <= 100 - config.store.volsteps) {
      setVol(config.store.volume + config.store.volsteps);
    } else {
      setVol(100);
    }
  } else {
    if (config.store.volume >= config.store.volsteps) {
      setVol(config.store.volume - config.store.volsteps);
    } else {
      setVol(0);
    }
  }
}

uint8_t Player::volToI2S(uint8_t volume) {
  int vol = map(volume, 0, 100 - config.station.ovol, 0, 100);  // Módosítás "vol_step"
  if (vol > 100) {
    vol = 100;
  }
  if (vol < 0) {
    vol = 0;
  }
  return vol;
}

void Player::_loadVol(uint8_t volume) {
  setVolume(volToI2S(volume));
}

void Player::setVol(uint8_t volume) {
  _volTicks = millis();
  _volTimer = true;
  player.sendCommand({PR_VOL, volume});
}

// A WEB UI a hangszínt -16 - +16 között adja, de az Audio osztály setTone()
// függvénye -40 és +6 (dB) közötti értéket kér, ezért mepelni kell.
int8_t Player::uiToDb(int8_t uiVal) {
  if (uiVal == 0) {
    return 0;
  }
  if (uiVal > 0) {
    // 0..+16  →  0..+6 dB
    float db = (uiVal / 16.0f) * 6.0f;
    return (int8_t)roundf(db);
  } else {
    // -16..0  →  -20..0 dB
    float db = (uiVal / 16.0f) * 20.0f;  // uiVal negatív!
    return (int8_t)roundf(db);
  }
}

void Player::setTone(int8_t bass, int8_t mid, int8_t treble) {
  // Serial.printf("EQ UI: %d %d %d  →  DSP: %d %d %d\n", bass, mid, treble, uiToDb(bass), uiToDb(mid), uiToDb(treble));
  Audio::setTone(uiToDb(bass), uiToDb(mid), uiToDb(treble));
}
