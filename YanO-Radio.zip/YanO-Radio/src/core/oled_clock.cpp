#include "core/oled_clock.h"

#include <math.h>

// Small 12x12 monochrome weather icons (drawn with primitives)
// We keep it simple and robust: SUN / CLOUD / RAIN / SNOW / STORM / FOG / CLEAR-NIGHT
static void drawWeatherIcon(U8G2 &u8g2, int16_t x, int16_t y, const char* desc) {
  // 10x10 weather icons: still compact, but more recognizable than 8x8.
  // Keyword match on OpenWeather "description" (localized), plus HU/EN.
  auto has = [&](const char* kw) -> bool {
    if (!desc || !*desc) return false;
    return (strstr(desc, kw) != nullptr);
  };

  const bool rain  = has("rain") || has("es") || has("zápor") || has("zapor") || has("szit") || has("drizzle");
  const bool snow  = has("snow") || has("hó") || has("ho") || has("havaz");
  const bool fog   = has("fog")  || has("mist") || has("köd") || has("kod") || has("haze");
  const bool storm = has("thunder") || has("zivatar") || has("vihar");
  const bool cloud = has("cloud") || has("felh") || has("overcast") || has("borult");
  const bool clear = has("clear") || has("derült") || has("derult") || has("sun") || has("nap");

  // XBM format: bytes per row = (w+7)/8 => for 10px width it's 2 bytes per row.
  // These are intentionally bold/simple so they remain readable on 128x64 OLED.
  static const uint8_t I_SUN[20] = {
    0x10,0x00, 0x10,0x00, 0x28,0x00, 0x7C,0x00, 0x38,0x00,
    0x38,0x00, 0x7C,0x00, 0x28,0x00, 0x10,0x00, 0x10,0x00
  };
  static const uint8_t I_CLOUD[20] = {
    0x00,0x00, 0x30,0x00, 0x48,0x00, 0x84,0x00, 0xFC,0x00,
    0xFE,0x00, 0xFC,0x00, 0x00,0x00, 0x00,0x00, 0x00,0x00
  };
  static const uint8_t I_RAIN[20] = {
    0x30,0x00, 0x48,0x00, 0x84,0x00, 0xFC,0x00, 0xFE,0x00,
    0xFC,0x00, 0x28,0x00, 0x10,0x00, 0x28,0x00, 0x00,0x00
  };
  static const uint8_t I_SNOW[20] = {
    0x10,0x00, 0x28,0x00, 0x10,0x00, 0x44,0x00, 0x28,0x00,
    0x10,0x00, 0x28,0x00, 0x44,0x00, 0x00,0x00, 0x00,0x00
  };
  static const uint8_t I_FOG[20] = {
    0xFE,0x00, 0x00,0x00, 0x7C,0x00, 0x00,0x00, 0xFE,0x00,
    0x00,0x00, 0x7C,0x00, 0x00,0x00, 0xFE,0x00, 0x00,0x00
  };
  static const uint8_t I_STORM[20] = {
    0x30,0x00, 0x48,0x00, 0x84,0x00, 0xFC,0x00, 0xFE,0x00,
    0xFC,0x00, 0x20,0x00, 0x10,0x00, 0x38,0x00, 0x00,0x00
  };

  const uint8_t* bmp = I_CLOUD;
  if (storm) bmp = I_STORM;
  else if (snow) bmp = I_SNOW;
  else if (rain) bmp = I_RAIN;
  else if (fog)  bmp = I_FOG;
  else if (clear) bmp = I_SUN;
  else if (cloud) bmp = I_CLOUD;

  // clear icon area (optional)
  u8g2.setDrawColor(0);
  u8g2.drawBox(x, y, 10, 10);
  u8g2.setDrawColor(1);

  u8g2.drawXBMP(x, y, 10, 10, bmp);
}

static bool extractTempC(const char* weatherBuf, char* out, size_t outLen) {
  if (!weatherBuf || !*weatherBuf) return false;
  // expected: "desc  12.3°C ..." (desc may contain spaces)
  const char* p = strstr(weatherBuf, "°C");
  if (!p) return false;
  // walk back to find start of number
  const char* s = p;
  while (s > weatherBuf && (isdigit((unsigned char)s[-1]) || s[-1] == '.' || s[-1] == '-' )) s--;
  if (s == p) return false;
  // copy number part
  char num[10] = {0};
  size_t n = (size_t)(p - s);
  if (n >= sizeof(num)) n = sizeof(num)-1;
  memcpy(num, s, n);
  num[n] = 0;
  // round to integer for OLED readability
  float tf = 0.0f;
  if (sscanf(num, "%f", &tf) != 1) return false;
  int ti = (int)lroundf(tf);
  snprintf(out, outLen, "%d°C", ti);
  return true;
}

void OledClock::begin() {
  Wire.begin(17, 18);   // SDA, SCL
  display.begin();
  display.clearBuffer();
  display.sendBuffer();
}

void OledClock::update() {
  // OLED redraw doesn't flicker (framebuffer), but keep it light.
  if (millis() - lastUpdate < 250) return;
  lastUpdate = millis();

  struct tm timeinfo;
  if (!getLocalTime(&timeinfo)) return;

  char dateStr[11];
  strftime(dateStr, sizeof(dateStr), "%Y-%m-%d", &timeinfo);

  char hourStr[3];
  char minStr[3];
  strftime(hourStr, sizeof(hourStr), "%H", &timeinfo);
  strftime(minStr, sizeof(minStr), "%M", &timeinfo);
  char hhmm[6];
  snprintf(hhmm, sizeof(hhmm), "%s:%s", hourStr, minStr);
  const bool colonOn = (timeinfo.tm_sec % 2 == 0);

  // Névnap
  const char* nd = "";
  #ifdef NAMEDAYS_FILE
    nd = getNameDay(timeinfo.tm_mon + 1, timeinfo.tm_mday);
  #endif

  // Weather
  char tempC[12] = "";
  const char* wxDesc = nullptr;
  const bool haveWxBuf = (timekeeper.weatherBuf && timekeeper.weatherBuf[0]);
  if (haveWxBuf) {
    wxDesc = timekeeper.weatherBuf;
    // If parsing fails (format differs, missing °C), we will still show an icon + fallback text.
    (void)extractTempC(timekeeper.weatherBuf, tempC, sizeof(tempC));
  }

  // Change detection
  bool changed = false;
  if (strcmp(lastDate, dateStr) != 0) { strncpy(lastDate, dateStr, sizeof(lastDate)); changed = true; }
  if (strcmp(lastTimeHHMM, hhmm) != 0) { strncpy(lastTimeHHMM, hhmm, sizeof(lastTimeHHMM)); changed = true; }
  if (lastColonOn != colonOn) { lastColonOn = colonOn; changed = true; }
  if (strncmp(lastNameday, nd ? nd : "", sizeof(lastNameday)) != 0) { strncpy(lastNameday, nd ? nd : "", sizeof(lastNameday)); changed = true; }
  if (strcmp(lastTemp, tempC) != 0) { strncpy(lastTemp, tempC, sizeof(lastTemp)); changed = true; }
  // Keep a short cache of desc (for icon heuristics)
  const char* wxShort = (wxDesc ? wxDesc : "");
  if (strncmp(lastWxDesc, wxShort, sizeof(lastWxDesc)) != 0) { strncpy(lastWxDesc, wxShort, sizeof(lastWxDesc)); changed = true; }

  if (!changed) return;

  display.clearBuffer();

  // --- Top: date ---
  display.setFont(u8g2_font_6x10_tf);
  {
    const int W = 128;
    int dw = display.getStrWidth(dateStr);
    int dx = (W - dw) / 2;
    if (dx < 0) dx = 0;
    // Slightly higher baseline so there is visible gap between date and big time.
    display.drawStr(dx, 8, dateStr);
  }

  // --- Middle: big time "00 : 00" with blinking ':' ---
  display.setFont(u8g2_font_logisoso26_tn);
  const int W = 128;
  // Lower the time a bit to avoid touching the date line.
  const int yTime = 40; // baseline for big font (smaller to leave room for nameday/weather)
  // compute width like "88:88" then center
  int fullW = display.getStrWidth("88:88");
  int startX = (W - fullW) / 2;
  display.drawStr(startX, yTime, hourStr);
  int colonX = startX + display.getStrWidth("88");
  if (colonOn) {
    display.drawStr(colonX, yTime, ":");
  }
  int minX = colonX + display.getStrWidth(":");
  display.drawStr(minX, yTime, minStr);

  // --- Bottom line 1: Nameday ---
  // Requirements:
  // - Center aligned
  // - NO "Névnap:" prefix, only the name
  // - If too long: scroll (marquee)
  display.setFont(u8g2_font_6x10_tf);
  // Use the already-defined screen width constant (W)
  const int yNameday = 52; // baseline, keeps a small gap above the weather row

  // Build nameday text (single name).
  char ndLine[64];
  if (nd && *nd) {
    strlcpy(ndLine, nd, sizeof(ndLine));
  } else {
    strlcpy(ndLine, "-", sizeof(ndLine));
  }

  // Marquee state (only active when text doesn't fit).
  static int ndScroll = 0;
  static uint32_t lastNdScrollMs = 0;

  const int ndW = display.getUTF8Width(ndLine);
  const int gapPx = 12;            // spacing after the text before it repeats
  const uint32_t stepMs = 160;     // scroll speed

  if (ndW <= W) {
    // Fits: draw centered, reset scrolling.
    ndScroll = 0;
    lastNdScrollMs = 0;
    int x = (W - ndW) / 2;
    if (x < 0) x = 0;
    display.drawUTF8(x, yNameday, ndLine);
  } else {
    // Doesn't fit: scroll from right to left.
    uint32_t now = millis();
    if (now - lastNdScrollMs >= stepMs) {
      lastNdScrollMs = now;
      ndScroll++;
      // Total travel: fully pass the screen, then a small gap.
      const int total = ndW + W + gapPx;
      if (ndScroll > total) ndScroll = 0;
      // Force redraw while scrolling even if content/time didn't change.
      changed = true;
    }
    const int x = W - ndScroll;
    display.drawUTF8(x, yNameday, ndLine);
  }

// --- Bottom line 2: Weather ---
  // Goal: ALWAYS show something when weather data exists.
  // If temperature can't be parsed, fall back to a short text extracted from the buffer.
  if (haveWxBuf || config.store.showweather) {
    display.setFont(u8g2_font_5x7_tf);
    const int W = 128;
    const int iconW = 10;
    const int gap = 2;

    char wxText[22] = "";
    if (tempC[0]) {
      strlcpy(wxText, tempC, sizeof(wxText));
    } else if (haveWxBuf) {
      // Take the first word (usually the description) or up to 20 chars.
      // This keeps the OLED readable even if EXT_WEATHER is enabled.
      const char* src = timekeeper.weatherBuf;
      size_t i = 0;
      while (src[i] && src[i] != ' ' && i < sizeof(wxText)-1) {
        wxText[i] = src[i];
        i++;
      }
      wxText[i] = 0;
      if (!wxText[0]) strlcpy(wxText, "WX", sizeof(wxText));
    } else {
      // Weather is enabled but there is no data yet (no key / no sync / no WiFi)
      strlcpy(wxText, "--", sizeof(wxText));
    }

    // Center icon + text as a group
    int tw = display.getUTF8Width(wxText);
    int groupW = tw + gap + iconW;
    int gx = (W - groupW) / 2;
    if (gx < 0) gx = 0;

    const int yBaseline = 63;
    const int iconY = yBaseline - 10 + 1;
    display.drawUTF8(gx, yBaseline, wxText);
    drawWeatherIcon(display, gx + tw + gap, iconY, wxDesc);
  }

  display.sendBuffer();
}