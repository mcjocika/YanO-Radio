#pragma once

// DLNA MediaRenderer integration ("cast" target)
// Uses Phil Schatzmann's arduino-dlna library (DLNA.h)
//
// Goal: allow phones / DLNA controllers to send a URL to yoRadio
// and control basic transport (Play/Stop) + Volume.

#include <Arduino.h>

// Enable with build flag: -DUSE_DLNA_RENDERER

namespace dlna_renderer {

  // Starts the renderer (non-blocking). Safe to call multiple times.
  void begin();

  // Stops the renderer task (best-effort).
  void end();

  // Restarts the renderer to apply config changes (e.g. friendly name).
  // Safe to call even if not running.
  void restart();

  bool isRunning();


  // Exposes the current stable UDN (uuid:...) used by the renderer.
  // Returned pointer is valid for the lifetime of the program.
  const char* udn();

  // Exposes the current friendly name used by the renderer (sanitized).
  const char* friendlyName();

  // TCP port where the renderer HTTP services are served (e.g. 9000).
  int httpPort();

} // namespace dlna_renderer
