// Egyesített verzió: Stall Watchdog + Direct Channel Change + PWM Dimming + Relay (Pin 38)
// VU némítás: Lekérdezés gátlásával (nincs külső VUMETER hivatkozás)
#include "options.h"
#include "Arduino.h"
#include "timekeeper.h"
#include "config.h"
#include "network.h"
#include "display.h"
#include "player.h"
#include "netserver.h"
#include "rtcsupport.h"
#include "ampguard.h"
#include "../displays/tools/l10n.h"
#include "../pluginsManager/pluginsManager.h"

#ifdef USE_NEXTION
    #include "../displays/nextion.h"
#endif

#if DSP_MODEL == DSP_DUMMY
    #define DUMMYDISPLAY
#endif

#if RTCSUPPORTED
    #define TIME_SYNC_INTERVAL config.store.timeSyncIntervalRTC * 60 * 60 * 1000
#else
    #define TIME_SYNC_INTERVAL config.store.timeSyncInterval * 60 * 1000
#endif
#define WEATHER_SYNC_INTERVAL config.store.weatherSyncInterval * 60 * 1000

#define SYNC_STACK_SIZE    1024 * 4
#define SYNC_TASK_CORE      0
#define SYNC_TASK_PRIORITY 3
#define WEATHER_STRING_L   254

TimeKeeper timekeeper;

void _syncTask(void* pvParameters) {
    if (timekeeper.forceWeather && timekeeper.forceTimeSync) {
        timekeeper.timeTask();
        timekeeper.weatherTask();
    } else if (timekeeper.forceWeather) {
        timekeeper.weatherTask();
    } else if (timekeeper.forceTimeSync) {
        timekeeper.timeTask();
    }
    timekeeper.busy = false;
    vTaskDelete(NULL);
}

TimeKeeper::TimeKeeper() {
    busy = false;
    forceWeather = true;
    forceTimeSync = true;
    _returnPlayerTime = _doAfterTime = 0;
    weatherBuf = NULL;

    // Erősítő/hangfal védelem init (a GPIO-kat kizárólag az ampguard kezeli)
    ampguard::begin();

    #if BRIGHTNESS_PIN != 255
        ledcAttach(BRIGHTNESS_PIN, 5000, 8);
        ledcWrite(BRIGHTNESS_PIN, 255);
    #endif

#if (DSP_MODEL != DSP_DUMMY || defined(USE_NEXTION)) && !defined(HIDE_WEATHER)
    weatherBuf = (char*)malloc(sizeof(char) * WEATHER_STRING_L);
    memset(weatherBuf, 0, WEATHER_STRING_L);
    memset(weatherIcon, 0, sizeof(weatherIcon));
#endif
}

////////////////////////////
bool TimeKeeper::loop0() {
    if (network.status != CONNECTED) { return true; }

    uint32_t currentTime = millis();
    static uint32_t _last1s = 0;
    static uint32_t _last2s = 0;

    if (currentTime - _last1s >= 1000) {
        _last1s = currentTime;
#if !defined(DUMMYDISPLAY) || defined(USE_NEXTION)
    #ifndef UPCLOCK_CORE1
        _upClock();
    #endif
#endif
    }

    if (currentTime - _last2s >= 2000) {
        _last2s = currentTime;
        _upRSSI();
    }

    return true;
}
/////////////////////

bool TimeKeeper::loop1() {
    // Egységes időalap: MOSTANTÓL minden (watchdog/sync/relé) ezt használja.
    const uint32_t now = millis();
    static uint32_t last1s = 0;

    // ============================================================
    //  KÉPERNYŐFÉNY (PWM) + RELÉ SZEKVENCIA (AMP + SPKRS_RELAY)
    //
    //  Cél: a képernyővédő (SCREENSAVER / SCREENBLANK) állapotától
    //  függően kapcsoljuk a reléket *ütésmentesen*.
    //
    //  SZABÁLYOK (ahogy kérted):
    //   - Ha képernyővédő aktív:
    //        1) SPKRS_RELAY = KI (azonnal)
    //        2) 2 mp múlva PWR_AMP = KI
    //   - Ha képernyővédő felébred:
    //        1) PWR_AMP = BE (azonnal)
    //        2) 2 mp múlva SPKRS_RELAY = BE
    //   - Ha a hangszóró relé már aktív (HIGH), akkor nem "piszkáljuk".
    //     (pl. web/sd/dlna váltásoknál lehet, hogy már ON állapotban van)
    //
    //  FONTOS:
    //   - A relé-szekvencia NEM a waitAndDo()-t használja (az csak 1 időzítőt tud),
    //     hanem saját millis()-időzítőt → nem fog összeakadni más logikákkal.
    // ============================================================

    // --- 1) Screensaver állapot meghatározása ---
    const bool ssActive = (display.mode() == SCREENSAVER || display.mode() == SCREENBLANK);

    // --- 2) PWM dimmelés (ha van BRIGHTNESS_PIN) ---
    // Kérés: screensaver belépéskor ~5 mp alatt dim 0-ra, feloldáskor 0->cél fényerő szépen.
#if BRIGHTNESS_PIN != 255
    static int      s_curPwm = -1;
    static int      s_fromPwm = 0;
    static int      s_toPwm = 0;
    static uint32_t s_fadeStartMs = 0;
    static bool     s_lastSsActive = false;

    const int normalPwm = map(config.store.brightness, 0, 100, 0, 255);
    const int targetPwm = ssActive ? 0 : normalPwm;

    if (s_curPwm < 0) {
        s_curPwm = normalPwm;
        analogWrite(BRIGHTNESS_PIN, s_curPwm);
    }

    // új fade indítása állapotváltáskor vagy cél változáskor
    if (ssActive != s_lastSsActive || s_toPwm != targetPwm) {
        s_lastSsActive = ssActive;
        s_fromPwm = s_curPwm;
        s_toPwm = targetPwm;
        s_fadeStartMs = now;
    }

    if (s_fadeStartMs) {
        constexpr uint32_t FADE_MS = 5000;
        uint32_t elapsed = now - s_fadeStartMs;
        if (elapsed >= FADE_MS) {
            s_curPwm = s_toPwm;
            s_fadeStartMs = 0;
        } else {
            // lineáris interpoláció
            const float t = (float)elapsed / (float)FADE_MS;
            s_curPwm = (int)(s_fromPwm + (float)(s_toPwm - s_fromPwm) * t);
        }
        analogWrite(BRIGHTNESS_PIN, s_curPwm);
    }
#endif

    // --- 3) Erősítő + hangfal védelem (kiszervezve ampguard.*-be) ---
    ampguard::updateUi(ssActive, player.isRunning());

    // --- 1 MÁSODPERCES RENDSZERCIKLUS ---
    if (now - last1s >= 1000) {
        last1s = now;
        pm.on_ticker();

#if !defined(DUMMYDISPLAY) || defined(USE_NEXTION)
#ifdef UPCLOCK_CORE1
        _upClock();
#endif
#endif
        // A képernyővédő logikát mindig futtatjuk (nem kötjük a fényerőhöz),
        // különben bizonyos eseményeknél "beragadhat" a módváltás.
        _upScreensaver();

        _upSDPos();
        _returnPlayer();
        _doAfterWait();
    }

    // --- STALL WATCHDOG (Fagyás elleni védelem WEB módban) ---
#ifdef ENABLE_STALL_WATCHDOG
    static uint32_t _lastStallCheck = 0;
    static uint32_t _stallSince = 0;
    static uint32_t _lastRestart = 0;
    static uint32_t _restartBackoffMs = 5000;

    if (now - _lastStallCheck >= 1000) {
        _lastStallCheck = now;

        // Ha fut a lejátszás WEB módban, de üres a puffer és nincs zárolva a kimenet
        if (player.isRunning() && config.getMode() == PM_WEB && network.status == CONNECTED && !player.lockOutput) {
            if (player.inBufferFilled() == 0) {
                if (_stallSince == 0) _stallSince = now;
            } else {
                _stallSince = 0;
                _restartBackoffMs = 5000;
            }

            // Ha 12 másodperce üres a puffer, újraindítjuk az állomást
            if (_stallSince > 0 && (now - _stallSince) >= 12000) {
                if (now - _lastRestart >= _restartBackoffMs) {
                    _lastRestart = now;

                    // Exponenciális várakozás (max 60mp) két újraindítás között
                    _restartBackoffMs = (uint32_t)min((int)(_restartBackoffMs * 2), 60000);

                    player.sendCommand({PR_STOP, 0});
                    player.sendCommand({PR_PLAY, config.lastStation()});
                    _stallSince = 0;
                }
            }
        } else {
            _stallSince = 0;
            _restartBackoffMs = 5000;
        }
    }
#endif

    // --- IDŐ ÉS IDŐJÁRÁS SZINKRONIZÁCIÓ ---
    static uint32_t lastWeatherTime = 0;
    if (now - lastWeatherTime >= (uint32_t)WEATHER_SYNC_INTERVAL) {
        lastWeatherTime = now;
        forceWeather = true;
    }

    static uint32_t lastTimeTime = 0;
    if (now - lastTimeTime >= (uint32_t)TIME_SYNC_INTERVAL) {
        lastTimeTime = now;
        forceTimeSync = true;
    }

    // Szinkronizációs taszk indítása külön magon, ha szükséges
    if (!busy && (forceWeather || forceTimeSync) && network.status == CONNECTED) {
        busy = true;
        xTaskCreatePinnedToCore(_syncTask, "syncTask", SYNC_STACK_SIZE, NULL, SYNC_TASK_PRIORITY, NULL, SYNC_TASK_CORE);
    }

    return true;
}

///////////////////////////

void TimeKeeper::waitAndReturnPlayer(uint8_t time_s) {
    _returnPlayerTime = millis() + time_s * 1000;
}

void TimeKeeper::_returnPlayer() {
    if (_returnPlayerTime > 0 && millis() >= _returnPlayerTime) {
        _returnPlayerTime = 0;
#ifdef DIRECT_CHANNEL_CHANGE
        if (display.mode() == STATIONS) {
            config.lastStation(display.currentPlItem);
            player.sendCommand({PR_PLAY, config.lastStation()});
        }
#endif
        display.putRequest(NEWMODE, PLAYER);
    }
}

void TimeKeeper::waitAndDo(uint8_t time_s, void (*callback)()) {
    _doAfterTime = millis() + time_s * 1000;
    _aftercallback = callback;
}

void TimeKeeper::_doAfterWait() {
    if (_doAfterTime > 0 && millis() >= _doAfterTime) {
        _doAfterTime = 0;
        _aftercallback();
    }
}

void TimeKeeper::_upClock() {
#if RTCSUPPORTED
    if (config.isRTCFound()) { rtc.getTime(&network.timeinfo); }
#else
    if (network.timeinfo.tm_year > 100 || network.status == SDREADY) {
        network.timeinfo.tm_sec++;
        mktime(&network.timeinfo);
    }
#endif
    if (display.ready()) { display.putRequest(CLOCK); }
}
////////////
void TimeKeeper::_upScreensaver() {
#ifndef DSP_LCD
    if (!display.ready()) { return; }

    // ------------------------------------------------------------
    // Screensaver (ha nem megy zene / vagy 0 a hangerő)
    // ------------------------------------------------------------
    const bool ssModeAllowed = (display.mode() == PLAYER || display.mode() == DLNAUI);
    if (!config.screensaverInhibit && config.store.screensaverEnabled && ssModeAllowed && (!player.isRunning() || config.store.volume == 0)) {
        config.screensaverTicks++;

        if (config.screensaverTicks > config.store.screensaverTimeout + SCREENSAVERSTARTUPDELAY) {

#if BRIGHTNESS_PIN != 255
            // PWM dimmelésnél ne kérjünk SCREENBLANK-et (sok kijelző azonnal lekapcsol),
            // a loop1 majd szépen 0-ra dimmeli a fényt.
            display.putRequest(NEWMODE, SCREENSAVER);
#else
            if (config.store.screensaverBlank) display.putRequest(NEWMODE, SCREENBLANK);
            else display.putRequest(NEWMODE, SCREENSAVER);
#endif

            config.screensaverTicks = SCREENSAVERSTARTUPDELAY + 1;
        }
    } else {
        config.screensaverTicks = 0;
    }

    // ------------------------------------------------------------
    // Screensaver "playing" (ha megy zene és van hangerő)
    // ------------------------------------------------------------
    if (!config.screensaverInhibit && config.store.screensaverPlayingEnabled && ssModeAllowed && player.isRunning() && config.store.volume > 0) {
        config.screensaverPlayingTicks++;

        if (config.screensaverPlayingTicks > config.store.screensaverPlayingTimeout * 60 + SCREENSAVERSTARTUPDELAY) {

#if BRIGHTNESS_PIN != 255
            display.putRequest(NEWMODE, SCREENSAVER);
#else
            if (config.store.screensaverPlayingBlank) display.putRequest(NEWMODE, SCREENBLANK);
            else display.putRequest(NEWMODE, SCREENSAVER);
#endif

            config.screensaverPlayingTicks = SCREENSAVERSTARTUPDELAY + 1;
        }
    } else {
        config.screensaverPlayingTicks = 0;
    }
#endif
}
///////
void TimeKeeper::_upRSSI() {
    if (network.status == CONNECTED) {
        netserver.setRSSI(WiFi.RSSI());
        netserver.requestOnChange(NRSSI, 0);
        if (display.ready()) { display.putRequest(DSPRSSI, netserver.getRSSI()); }
    }
#ifdef USE_SD
    if (display.mode() != SDCHANGE) { player.sendCommand({PR_CHECKSD, 0}); }
#endif

    // VU METER: Csak akkor kérünk adatot, ha van hangerő.
    // Ezzel elkerüljük a nulla hangerő melletti "befagyott" kijelzést.
    if (player.isRunning() && config.store.volume > 0) {
        player.sendCommand({PR_VUTONUS, 0});
    }
}

void TimeKeeper::_upSDPos() {
    if (player.isRunning() && config.getMode() == PM_SDCARD) { netserver.requestOnChange(SDPOS, 0); }
}

void TimeKeeper::timeTask() {
    static uint8_t tsFailCnt = 0;
    config.waitConnection();
    if (getLocalTime(&network.timeinfo)) {
        tsFailCnt = 0;
        forceTimeSync = false;
        mktime(&network.timeinfo);
        display.putRequest(CLOCK, 1);
        network.requestTimeSync(true);
#if RTCSUPPORTED
        if (config.isRTCFound()) { rtc.setTime(&network.timeinfo); }
#endif
    } else {
        if (tsFailCnt < 4) { forceTimeSync = true; tsFailCnt++; }
        else { forceTimeSync = false; tsFailCnt = 0; }
    }
}

void TimeKeeper::weatherTask() {
    forceWeather = false;
    if (!weatherBuf || strlen(config.store.weatherkey) == 0 || !config.store.showweather) { return; }
    _getWeather();
}

bool _getWeather() {
#if (DSP_MODEL != DSP_DUMMY || defined(USE_NEXTION)) && !defined(HIDE_WEATHER)
    static AsyncClient* weatherClient = NULL;
    static const char* host = "api.openweathermap.org";
    if (weatherClient) { return false; }
    weatherClient = new AsyncClient();
    if (!weatherClient) { return false; }

    weatherClient->onError([](void* arg, AsyncClient* client, int error) {
        weatherClient = NULL;
        delete client;
    }, NULL);

    weatherClient->onConnect([](void* arg, AsyncClient* client) {
        weatherClient->onDisconnect([](void* arg, AsyncClient* c) {
            weatherClient = NULL;
            delete c;
        }, NULL);

        char httpget[300];
        sprintf(httpget, "GET /data/2.5/weather?lat=%s&lon=%s&units=%s&lang=%s&appid=%s HTTP/1.1\r\nHost: %s\r\nConnection: close\r\n\r\n",
                config.store.weatherlat, config.store.weatherlon, LANG::weatherUnits, LANG::weatherLang, config.store.weatherkey, host);
        client->write(httpget);

        client->onData([](void* arg, AsyncClient* c, void* data, size_t len) {
            uint8_t* d = (uint8_t*)data;
            const char* bodyStart = strstr((const char*)d, "\r\n\r\n");
            if (bodyStart != NULL) {
                bodyStart += 4;
                char line[len + 1];
                memcpy(line, bodyStart, len - (bodyStart - (const char*)d));
                line[len - (bodyStart - (const char*)d)] = '\0';

                char desc[120], *cursor;
                float tempf, tempfl, wind_speed;
                int hum, press, wind_deg;

                if ((cursor = strstr(line, "\"description\":\""))) sscanf(cursor, "\"description\":\"%119[^\"]", desc);
                if ((cursor = strstr(line, "\"temp\":"))) sscanf(cursor, "\"temp\":%f", &tempf);
                if ((cursor = strstr(line, "\"pressure\":"))) sscanf(cursor, "\"pressure\":%d", &press);
                if ((cursor = strstr(line, "\"humidity\":"))) sscanf(cursor, "\"humidity\":%d", &hum);
                if ((cursor = strstr(line, "\"feels_like\":"))) sscanf(cursor, "\"feels_like\":%f", &tempfl);
                if ((cursor = strstr(line, "\"speed\":"))) sscanf(cursor, "\"speed\":%f", &wind_speed);
                if ((cursor = strstr(line, "\"deg\":"))) sscanf(cursor, "\"deg\":%d", &wind_deg);

                #ifdef WIND_SPEED_IN_KMH
                    wind_speed *= 3.6f;
                #endif

                // --------- FORMÁTUM BIZTOS JAVÍTÁSA ----------
                // A LANG::weatherFmt több nyelvnél eltérhet (típus/sorrend), ezért a sprintf warningokat úgy
                // szüntetjük meg, hogy fix, típushelyes snprintf-et használunk.
                // Így nem fog char*/double mismatch lenni, és nem írunk túl a pufferen sem.
                #if EXT_WEATHER
                    snprintf(
                        timekeeper.weatherBuf, WEATHER_STRING_L,
                        "%s  %.1f°C (%.1f°C)  %d hPa  %d%%  %.1f %s  %s",
                        desc,
                        (double)tempf,
                        (double)tempfl,
                        (int)press,
                        (int)hum,
                        (double)wind_speed,
                        #ifdef WIND_SPEED_IN_KMH
                            "km/h"
                        #else
                            "m/s"
                        #endif
                        ,
                        LANG::wind[(int)(wind_deg / 22.5)]
                    );
                #else
                    snprintf(
                        timekeeper.weatherBuf, WEATHER_STRING_L,
                        "%s  %.1f°C  %d hPa  %d%%",
                        desc,
                        (double)tempf,
                        (int)press,
                        (int)hum
                    );
                #endif

                display.putRequest(NEWWEATHER);
            }
        }, NULL);
    }, NULL);

    config.waitConnection();
    if (!weatherClient->connect(host, 80)) {
        AsyncClient* client = weatherClient;
        weatherClient = NULL;
        delete client;
        return false;
    }
    return true;
#else
    return false;
#endif
}