#ifndef _my_theme_h
#define _my_theme_h

#define ENABLE_THEME
#ifdef  ENABLE_THEME
// clang-format off
/* R    G    B  */
/*----- SCREEN -----*/
#define COLOR_BACKGROUND          10,  10,  10   // Sötétszürke háttér

/*----- META -----*/
#define COLOR_STATION_NAME      0,   0,   0   // Fekete fejléc szöveg
#define COLOR_STATION_BG          0, 140,  60   // Zöld fejléc háttér
#define COLOR_STATION_FILL      0, 110,  50   // Sötétebb zöld kitöltés
#define COLOR_SNG_TITLE_1       255, 255, 255 // Fehér dalcím
#define COLOR_SNG_TITLE_2       0, 200, 120   // Zöldes kiemelés
#define COLOR_BITRATE           0, 200, 120   // Zöld bitrate

/*----- WEATHER -----*/
#define COLOR_WEATHER           255, 150,   0

/*---- VOLUME SCREEN -----*/
#define COLOR_DIGITS            255, 255, 255

/*----- NAMEDAY -----*/
#define COLOR_NAMEDAY           0, 200, 120   // Zöld névnap

/*----- CLOCK, DATE -----*/
#define COLOR_CLOCK             0, 200, 120   // Zöld óra
#define COLOR_CLOCK_BG           28,  28,  28
#define COLOR_SECONDS           0, 140,  60   // Sötétebb zöld mp
#define COLOR_DIVIDER            60,  60,  60   // Szürke elválasztó
#define COLOR_DATE              220, 220, 220   // Világosszürke dátum

/*----- VU WIDGET (EREDETI SZÍNEK MEGTARTVA) ----*/
#define COLOR_VU_MAX            255,  14,  14 // Piros csúcs
#define COLOR_VU_MID            255, 255,   0 // Sárga közép
#define COLOR_VU_MIN             44, 212,  32 // Zöld alj

/*----- FOOTER -----*/
#define COLOR_VOLBAR_OUT         51,  51,  51   // Sötétszürke keret
#define COLOR_VOLBAR_IN         0, 200, 120   // Zöld hangerő csík
#define COLOR_VOLUME_VALUE      255, 255, 255 // Fehér hangerő szám
#define COLOR_IP                150, 150, 150 // Szürke IP
#define COLOR_CH                0, 200, 120   // Zöld csatorna
#define COLOR_RSSI              0, 200, 120   // Zöld WiFi jel
#define COLOR_HEAP               41,  40,  41
#define COLOR_BUFFER             0, 140,  60   // Sötétzöld puffer

/*----- PLAYLIST -----*/
#ifdef PLAYLIST_SCROLL_MOVING_CURSOR
    #define COLOR_PL_CURRENT        255, 255, 255
    #define COLOR_PL_CURRENT_BG       0, 110,  50   // Zöld kijelölt sor
    #define COLOR_PL_CURRENT_FILL     0, 119, 204
    #define COLOR_PLAYLIST_0        165, 165, 165
    #define COLOR_PLAYLIST_1        130, 130, 130
    #define COLOR_PLAYLIST_2        100, 100, 100
    #define COLOR_PLAYLIST_3         70,  70,  70
    #define COLOR_PLAYLIST_4         40,  40,  40
#else
    #define COLOR_PL_CURRENT          255, 255, 255
    #define COLOR_PL_CURRENT_BG        0, 119, 204
    #define COLOR_PL_CURRENT_FILL      0, 119, 204
    #define COLOR_PLAYLIST_0          115, 115, 115
    #define COLOR_PLAYLIST_1           89,  89,  89
    #define COLOR_PLAYLIST_2           56,  56,  56
    #define COLOR_PLAYLIST_3           35,  35,  35
    #define COLOR_PLAYLIST_4           25,  25,  25
#endif

/*----- PRESETS -----*/
#define COLOR_PRST_BUTTON            14,  21,  30 
#define COLOR_PRST_CARD              10,  10,  10 
#define COLOR_PRST_ACCENT             0, 119, 204 // Kék kiemelés
#define COLOR_PRST_FAV              255,  51,  51 // Piros kedvenc
#define COLOR_PRST_TITLE_1          255, 255, 255
#define COLOR_PRST_TITLE_2          200, 200, 200
#define COLOR_PRST_TITLE_3          120, 120, 120
#define COLOR_PRST_LINE              40,  40,  40

#endif  /* #ifdef  ENABLE_THEME */
#endif  /* #define _my_theme_h  */