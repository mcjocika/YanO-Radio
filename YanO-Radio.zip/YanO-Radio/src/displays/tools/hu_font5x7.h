#pragma once
#include <Arduino.h>

extern const unsigned char hu_font5x7[] PROGMEM;

// UTF-8 → font index mapping for Hungarian accented letters.
// Returns the font code (0..255). Sets *consumed to 1 or 2 bytes.
// Unknown multi-byte sequences -> '?'
uint8_t hu_map_utf8(const char* s, uint8_t* consumed);
